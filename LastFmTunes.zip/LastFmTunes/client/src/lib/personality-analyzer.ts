// Kullanıcının kişiliğini analiz edip ona göre iletişim stratejisi belirleyen modül

// Kişilik tipleri
export enum PersonalityType {
  CASUAL = 'casual',         // Samimi, gayri resmi
  FORMAL = 'formal',         // Resmi, nazik
  ENTHUSIASTIC = 'enthusiastic', // Heyecanlı, enerjik
  THOUGHTFUL = 'thoughtful',    // Düşünceli, bilgilendirici
  FUNNY = 'funny'            // Esprili, eğlenceli
}

// Konuşma tonu ayarları
export interface ToneSettings {
  greeting: string;
  songSuggestionIntro: string;
  questionResponse: string;
  acknowledgment: string;
  farewell: string;
  emoji: boolean;
  questionFrequency: number; // 0-10 arası, ne sıklıkla soru sorulacağı
  casualWords: string[];  // "Kanka", "dostum" gibi kelimeler
}

// Kişilik tipine göre ton ayarları
export const personalityTones: Record<PersonalityType, ToneSettings> = {
  [PersonalityType.CASUAL]: {
    greeting: "Selam! Ne haber? Bugün nasıl bi müzik keyfin var?",
    songSuggestionIntro: "Bak bunlar tam senlik, dinlesen iyi olur bence:",
    questionResponse: "Anladım kanka, hemen bakıyorum",
    acknowledgment: "Tamamdır dostum",
    farewell: "Görüşürüz, yine takılırız",
    emoji: true,
    questionFrequency: 8,
    casualWords: ["kanka", "dostum", "moruk", "ya", "bak", "valla", "hacı", "reis"]
  },
  [PersonalityType.FORMAL]: {
    greeting: "Merhaba! Size nasıl yardımcı olabilirim?",
    songSuggestionIntro: "İşte sizin için tavsiye edebileceğim eserler:",
    questionResponse: "Anlıyorum efendim, hemen araştırıyorum",
    acknowledgment: "Elbette, anlaşıldı",
    farewell: "İyi günler dilerim, başka bir konuda yardıma ihtiyacınız olursa buradayım",
    emoji: false,
    questionFrequency: 4,
    casualWords: ["efendim", "rica ederim", "buyurun", "tabii ki"]
  },
  [PersonalityType.ENTHUSIASTIC]: {
    greeting: "Heyy! Müzik dünyasına dalmaya hazır mısın?! 🎵✨",
    songSuggestionIntro: "Vay canına! Bunları kesinlikle dinlemelisin, çok seveceksin!:",
    questionResponse: "Tabii ki! Hemen senin için en iyilerini buluyorum!",
    acknowledgment: "Müthiş! Anladım!",
    farewell: "Harika bir müzik yolculuğunda görüşürüz! ✌️",
    emoji: true,
    questionFrequency: 9,
    casualWords: ["vay!", "harika!", "muhteşem!", "inanılmaz!", "süper!"]
  },
  [PersonalityType.THOUGHTFUL]: {
    greeting: "Merhaba, müzik tercihlerin hakkında biraz düşünüyordum. Sana nasıl yardımcı olabilirim?",
    songSuggestionIntro: "Müzikal tercihlerini inceledim ve şunları önerebilirim:",
    questionResponse: "İlginç bir soru. Bunu analiz edeyim",
    acknowledgment: "Bu önemli bir nokta, değerlendireceğim",
    farewell: "Müzik yolculuğunda yeni keşifler dilerim",
    emoji: false,
    questionFrequency: 6,
    casualWords: ["düşünüyorum", "analiz", "ilginç", "fark ettim", "belki"]
  },
  [PersonalityType.FUNNY]: {
    greeting: "Hey! Müzik listende delik açmaya hazır mısın? 🤪🎸",
    songSuggestionIntro: "Kulakların bayram etsin diye özel seçtiklerim:",
    questionResponse: "Hmmm, bunu arşivlerimde kazmam lazım, bir saniye kulaklığımı düzelteyim! 🎧",
    acknowledgment: "Aynen öyle, kafan almış yine 👌",
    farewell: "Kulakların çınlasın! Müzik tanrıları korusun! 🤘",
    emoji: true,
    questionFrequency: 7,
    casualWords: ["yok artık", "komik olan", "gülsene", "esprili", "çok iyi"]
  }
};

// Kişilik analizi için anahtar kelimeler
const personalityKeywords: Record<PersonalityType, string[]> = {
  [PersonalityType.CASUAL]: [
    "kanka", "dostum", "abi", "ya", "bak", "moruk", "hacı", "olur", "tamam", "iyi", "selam",
    "naber", "napıyon", "napcaz", "nasılsın", "nabıyon", "kral", "reis"
  ],
  [PersonalityType.FORMAL]: [
    "merhaba", "iyi günler", "teşekkür ederim", "rica ederim", "lütfen", "saygılar", "sayın",
    "efendim", "buyurun", "müsaadenizle", "uygun", "yardımcı olur musunuz", "acaba", "mümkün"
  ],
  [PersonalityType.ENTHUSIASTIC]: [
    "harika", "süper", "mükemmel", "muhteşem", "inanılmaz", "çok iyi", "efsane", "bayıldım",
    "seviyorum", "aşığım", "heyecanlı", "enerji", "vay", "yaşasın", "coşku", "harikaydı"
  ],
  [PersonalityType.THOUGHTFUL]: [
    "düşünüyorum", "sanırım", "belki", "olabilir", "acaba", "merak ediyorum", "ilginç",
    "analiz", "değerlendirme", "detaylı", "incelemek", "derinlemesine", "fark ettim", "anlamak"
  ],
  [PersonalityType.FUNNY]: [
    "komik", "espri", "gülmek", "eğlenceli", "şaka", "dalga", "gıcık", "caps", "saçma",
    "absürt", "geyik", "kahkaha", "güldüm", "matrak", "hahaha", "mizah"
  ]
};

/**
 * Kullanıcının mesajlarına göre kişilik analizi yapar
 * @param messages Son konuşmalardaki kullanıcı mesajları
 * @returns En uygun kişilik tipi ve güven derecesi
 */
export function analyzePersonality(messages: string[]): { 
  type: PersonalityType, 
  confidence: number 
} {
  // Başlangıçta tüm kişilik tipleri için 0 puan
  const scores: Record<PersonalityType, number> = {
    [PersonalityType.CASUAL]: 0,
    [PersonalityType.FORMAL]: 0,
    [PersonalityType.ENTHUSIASTIC]: 0,
    [PersonalityType.THOUGHTFUL]: 0,
    [PersonalityType.FUNNY]: 0
  };
  
  let totalWords = 0;
  
  // Tüm mesajları analiz et
  messages.forEach(message => {
    const lowerMessage = message.toLowerCase();
    const words = lowerMessage.split(/\s+/);
    totalWords += words.length;
    
    // Her kişilik tipi için mesajı kontrol et
    Object.keys(personalityKeywords).forEach(type => {
      const typeKeywords = personalityKeywords[type as PersonalityType];
      
      typeKeywords.forEach(keyword => {
        // Anahtar kelime mesajda geçiyorsa puan ekle
        if (lowerMessage.includes(keyword.toLowerCase())) {
          scores[type as PersonalityType] += 1;
        }
      });
    });
    
    // Ek kontroller:
    
    // Resmi ifadeler
    if (/lütfen|teşekkür|rica|saygı|ederim/.test(lowerMessage)) {
      scores[PersonalityType.FORMAL] += 1;
    }
    
    // Samimi ifadeler
    if (/ya+|kanka|abi|reis|mor[uo]k|hacı/.test(lowerMessage)) {
      scores[PersonalityType.CASUAL] += 2;
    }
    
    // Heyecanlı ifadeler ve ünlem işaretleri
    const exclamationCount = (lowerMessage.match(/!/g) || []).length;
    scores[PersonalityType.ENTHUSIASTIC] += exclamationCount;
    
    // Emoji kullanımı
    const emojiCount = (lowerMessage.match(/[\u{1F600}-\u{1F64F}]|[\u{1F300}-\u{1F5FF}]|[\u{1F680}-\u{1F6FF}]|[\u{1F700}-\u{1F77F}]|[\u{1F780}-\u{1F7FF}]|[\u{1F800}-\u{1F8FF}]|[\u{1F900}-\u{1F9FF}]|[\u{1FA00}-\u{1FA6F}]|[\u{1FA70}-\u{1FAFF}]|[\u{2600}-\u{26FF}]|[\u{2700}-\u{27BF}]/gu) || []).length;
    
    if (emojiCount > 0) {
      scores[PersonalityType.ENTHUSIASTIC] += emojiCount;
      scores[PersonalityType.FUNNY] += emojiCount / 2;
    }
    
    // Soru işaretleri (düşünceli kişiliği gösterebilir)
    const questionCount = (lowerMessage.match(/\?/g) || []).length;
    scores[PersonalityType.THOUGHTFUL] += questionCount;
    
    // "haha" ve benzeri ifadeler (esprili kişiliği gösterebilir)
    if (/haha|hehe|:D|komik|gül/.test(lowerMessage)) {
      scores[PersonalityType.FUNNY] += 2;
    }
  });
  
  // En yüksek skora sahip kişilik tipini bul
  let maxScore = 0;
  let dominantType = PersonalityType.CASUAL; // Varsayılan olarak samimi
  
  Object.keys(scores).forEach(type => {
    if (scores[type as PersonalityType] > maxScore) {
      maxScore = scores[type as PersonalityType];
      dominantType = type as PersonalityType;
    }
  });
  
  // Güven derecesini hesapla (0 ile 1 arasında)
  let totalScore = Object.values(scores).reduce((sum, score) => sum + score, 0);
  const confidence = totalScore > 0 ? maxScore / totalScore : 0.5;
  
  // Yeterli veri yoksa (çok az mesaj) güveni düşür
  const confidenceAdjusted = totalWords < 10 ? 
    Math.min(confidence, 0.6) : // Az veri varsa güven max 0.6
    confidence;
  
  return {
    type: dominantType,
    confidence: confidenceAdjusted
  };
}

/**
 * Kullanıcının kişiliğine göre dinamik cevap oluşturur
 * @param personalityType Kullanıcının kişilik tipi
 * @param messageType Mesaj tipi (greeting, suggestion, vs.)
 * @param customMessage Özel mesaj içeriği (isteğe bağlı)
 * @returns Kişiliğe uyarlanmış mesaj
 */
export function generatePersonalizedResponse(
  personalityType: PersonalityType, 
  messageType: 'greeting' | 'songSuggestion' | 'response' | 'acknowledgment' | 'farewell',
  customMessage?: string
): string {
  const toneSettings = personalityTones[personalityType];
  
  let baseMessage = '';
  
  switch(messageType) {
    case 'greeting':
      baseMessage = toneSettings.greeting;
      break;
    case 'songSuggestion':
      baseMessage = toneSettings.songSuggestionIntro;
      break;
    case 'response':
      baseMessage = toneSettings.questionResponse;
      break;
    case 'acknowledgment':
      baseMessage = toneSettings.acknowledgment;
      break;
    case 'farewell':
      baseMessage = toneSettings.farewell;
      break;
  }
  
  // Özel mesaj varsa, bunu temel mesaja ekle
  if (customMessage) {
    baseMessage = baseMessage + ' ' + customMessage;
  }
  
  // Kişiliğe göre rastgele samimi kelime ekle (düşük olasılıkla)
  if (Math.random() < 0.3 && toneSettings.casualWords.length > 0) {
    const randomWord = toneSettings.casualWords[Math.floor(Math.random() * toneSettings.casualWords.length)];
    baseMessage = baseMessage.replace(/\.$/, ` ${randomWord}.`);
  }
  
  // Emoji kullanımı
  if (toneSettings.emoji && Math.random() < 0.4) {
    const emojis = ['😊', '👍', '🎵', '🎧', '🎸', '🎹', '🎶', '🔥', '⭐', '✨', '💯'];
    const randomEmoji = emojis[Math.floor(Math.random() * emojis.length)];
    baseMessage += ` ${randomEmoji}`;
  }
  
  return baseMessage;
}

// Sohbetin akışını kişiliğe göre ayarla
export function adaptConversationFlow(personalityType: PersonalityType, userMessage: string): {
  shouldAskFollowUp: boolean;
  shouldSuggestSongs: boolean;
  responseStyle: 'detailed' | 'concise' | 'enthusiastic';
} {
  const toneSettings = personalityTones[personalityType];
  
  // Cevap verme stratejisi belirle
  return {
    // Kişiliğe göre takip sorusu sorma olasılığı
    shouldAskFollowUp: Math.random() < (toneSettings.questionFrequency / 10),
    
    // Şarkı önerisi yapma olasılığı (müzikle ilgili mesajlarda daha yüksek)
    shouldSuggestSongs: /müzik|şarkı|dinle|öneri|çal|liste/i.test(userMessage) || Math.random() < 0.4,
    
    // Yanıt stili
    responseStyle: personalityType === PersonalityType.ENTHUSIASTIC ? 'enthusiastic' :
                  personalityType === PersonalityType.THOUGHTFUL ? 'detailed' : 'concise'
  };
}