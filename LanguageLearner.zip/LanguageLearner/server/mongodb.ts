import mongoose from 'mongoose';
import { log } from './vite';
import { User, Track, Playlist, ChatMessage } from '../shared/schema';
import bcrypt from 'bcryptjs';

// Şema tanımlamaları
const userSchema = new mongoose.Schema({
  username: { type: String, required: true, unique: true },
  password: { type: String, required: true },
  fullName: { type: String, required: true },
  email: { type: String, required: true, unique: true },
  profilePicture: { type: String, default: null },
  createdAt: { type: Date, default: Date.now }
});

const trackSchema = new mongoose.Schema({
  title: { type: String, required: true },
  artist: { type: String, required: true },
  album: { type: String, default: null },
  duration: { type: Number, default: null },
  coverImage: { type: String, default: null },
  lastfmId: { type: String, default: null },
  youtubeId: { type: String, default: null }
});

const playlistSchema = new mongoose.Schema({
  name: { type: String, required: true },
  userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  description: { type: String, default: null },
  coverImage: { type: String, default: null },
  trackCount: { type: Number, default: 0 },
  duration: { type: Number, default: 0 },
  createdAt: { type: Date, default: Date.now }
});

const playlistTrackSchema = new mongoose.Schema({
  playlistId: { type: mongoose.Schema.Types.ObjectId, ref: 'Playlist', required: true },
  trackId: { type: mongoose.Schema.Types.ObjectId, ref: 'Track', required: true },
  position: { type: Number, required: true }
});

const likedTrackSchema = new mongoose.Schema({
  userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  trackId: { type: mongoose.Schema.Types.ObjectId, ref: 'Track', required: true },
  likedAt: { type: Date, default: Date.now }
});

const recentlyPlayedSchema = new mongoose.Schema({
  userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  trackId: { type: mongoose.Schema.Types.ObjectId, ref: 'Track', required: true },
  playedAt: { type: Date, default: Date.now }
});

const chatMessageSchema = new mongoose.Schema({
  userId: { type: String, required: true },
  content: { type: String, required: true },
  isUser: { type: Boolean, required: true },
  timestamp: { type: Date, default: Date.now }
});

// Model oluşturma
const UserModel = mongoose.model('User', userSchema);
const TrackModel = mongoose.model('Track', trackSchema);
const PlaylistModel = mongoose.model('Playlist', playlistSchema);
const PlaylistTrackModel = mongoose.model('PlaylistTrack', playlistTrackSchema);
const LikedTrackModel = mongoose.model('LikedTrack', likedTrackSchema);
const RecentlyPlayedModel = mongoose.model('RecentlyPlayed', recentlyPlayedSchema);
const ChatMessageModel = mongoose.model('ChatMessage', chatMessageSchema);

// MongoDB bağlantı fonksiyonu
export async function connectToMongoDB() {
  try {
    // MongoDB URI burada olmalı - lokal geliştirme için varsayılan URI kullanılıyor
    const mongoURI = process.env.MONGODB_URI || 'mongodb://localhost:27017/muzikai';
    await mongoose.connect(mongoURI);
    log('MongoDB bağlantısı başarılı', 'mongodb');
    
    // Demo kullanıcı oluşturma
    await initDemoData();
    
    return true;
  } catch (error) {
    log(`MongoDB bağlantı hatası: ${error}`, 'mongodb');
    return false;
  }
}

// Demo veri fonksiyonu
async function initDemoData() {
  try {
    // Demo kullanıcı sayısı kontrolü
    const userCount = await UserModel.countDocuments();
    
    if (userCount === 0) {
      // Şifre hashleme
      const salt = await bcrypt.genSalt(10);
      const hashedPassword = await bcrypt.hash('password123', salt);
      
      // Demo kullanıcı oluşturma
      const demoUser = new UserModel({
        username: 'osmanxsmurf',
        password: hashedPassword,
        fullName: 'Osman Özdoğan',
        email: 'osman@example.com',
        profilePicture: null
      });
      
      await demoUser.save();
      log('Demo kullanıcı oluşturuldu', 'mongodb');
    }
  } catch (error) {
    log(`Demo veri oluşturma hatası: ${error}`, 'mongodb');
  }
}

// MongoDB depolama sınıfı
export class MongoDBStorage {
  
  // Kullanıcı metodları
  async getUser(id: string): Promise<any> {
    try {
      return await UserModel.findById(id).lean();
    } catch (error) {
      log(`Kullanıcı getirme hatası: ${error}`, 'mongodb');
      return undefined;
    }
  }
  
  async getUserByUsername(username: string): Promise<any> {
    try {
      return await UserModel.findOne({ username }).lean();
    } catch (error) {
      log(`Kullanıcı adına göre getirme hatası: ${error}`, 'mongodb');
      return undefined;
    }
  }
  
  async getUserByEmail(email: string): Promise<any> {
    try {
      return await UserModel.findOne({ email }).lean();
    } catch (error) {
      log(`Email'e göre kullanıcı getirme hatası: ${error}`, 'mongodb');
      return undefined;
    }
  }
  
  async createUser(userData: any): Promise<any> {
    try {
      const user = new UserModel(userData);
      return await user.save();
    } catch (error) {
      log(`Kullanıcı oluşturma hatası: ${error}`, 'mongodb');
      throw error;
    }
  }
  
  // Şarkı metodları
  async getTrack(id: string): Promise<any> {
    try {
      return await TrackModel.findById(id).lean();
    } catch (error) {
      log(`Şarkı getirme hatası: ${error}`, 'mongodb');
      return undefined;
    }
  }
  
  async getTrackByLastFMId(lastfmId: string): Promise<any> {
    try {
      return await TrackModel.findOne({ lastfmId }).lean();
    } catch (error) {
      log(`LastFM ID'sine göre şarkı getirme hatası: ${error}`, 'mongodb');
      return undefined;
    }
  }
  
  async createTrack(trackData: any): Promise<any> {
    try {
      // Önce LastFM ID'sine göre sorgula, varsa güncelle
      if (trackData.lastfmId) {
        const existingTrack = await this.getTrackByLastFMId(trackData.lastfmId);
        if (existingTrack) {
          return existingTrack;
        }
      }
      
      const track = new TrackModel(trackData);
      return await track.save();
    } catch (error) {
      log(`Şarkı oluşturma hatası: ${error}`, 'mongodb');
      throw error;
    }
  }
  
  async searchTracks(query: string): Promise<any[]> {
    try {
      // Başlık veya sanatçı adına göre arama
      return await TrackModel.find({
        $or: [
          { title: { $regex: query, $options: 'i' } },
          { artist: { $regex: query, $options: 'i' } },
          { album: { $regex: query, $options: 'i' } }
        ]
      }).limit(20).lean();
    } catch (error) {
      log(`Şarkı arama hatası: ${error}`, 'mongodb');
      return [];
    }
  }
  
  // Çalma listesi metodları
  async getPlaylist(id: string): Promise<any> {
    try {
      return await PlaylistModel.findById(id).lean();
    } catch (error) {
      log(`Çalma listesi getirme hatası: ${error}`, 'mongodb');
      return undefined;
    }
  }
  
  async getUserPlaylists(userId: string): Promise<any[]> {
    try {
      return await PlaylistModel.find({ userId }).lean();
    } catch (error) {
      log(`Kullanıcı çalma listeleri getirme hatası: ${error}`, 'mongodb');
      return [];
    }
  }
  
  async createPlaylist(playlistData: any): Promise<any> {
    try {
      const playlist = new PlaylistModel(playlistData);
      return await playlist.save();
    } catch (error) {
      log(`Çalma listesi oluşturma hatası: ${error}`, 'mongodb');
      throw error;
    }
  }
  
  async updatePlaylist(id: string, playlistData: any): Promise<any> {
    try {
      return await PlaylistModel.findByIdAndUpdate(
        id, 
        { $set: playlistData }, 
        { new: true }
      ).lean();
    } catch (error) {
      log(`Çalma listesi güncelleme hatası: ${error}`, 'mongodb');
      return undefined;
    }
  }
  
  async deletePlaylist(id: string): Promise<boolean> {
    try {
      const result = await PlaylistModel.findByIdAndDelete(id);
      if (result) {
        // İlgili playlistTrack kayıtlarını da sil
        await PlaylistTrackModel.deleteMany({ playlistId: id });
        return true;
      }
      return false;
    } catch (error) {
      log(`Çalma listesi silme hatası: ${error}`, 'mongodb');
      return false;
    }
  }
  
  // Çalma listesi şarkı metodları
  async getPlaylistTracks(playlistId: string): Promise<any[]> {
    try {
      // Sıralı olarak çalma listesindeki şarkıları getir
      const playlistTracks = await PlaylistTrackModel.find({ playlistId })
        .sort({ position: 1 })
        .lean();
      
      // Şarkı ID'lerini al
      const trackIds = playlistTracks.map(pt => pt.trackId);
      
      // Şarkı detaylarını getir
      const tracks = await TrackModel.find({ _id: { $in: trackIds } }).lean();
      
      // Orijinal sıralamayı koru
      return playlistTracks.map(pt => {
        const track = tracks.find(t => t._id.toString() === pt.trackId.toString());
        return track;
      }).filter(Boolean);
    } catch (error) {
      log(`Çalma listesi şarkıları getirme hatası: ${error}`, 'mongodb');
      return [];
    }
  }
  
  async addTrackToPlaylist(playlistTrackData: any): Promise<any> {
    try {
      // Önce çalma listesini al
      const playlist = await this.getPlaylist(playlistTrackData.playlistId);
      if (!playlist) {
        throw new Error('Çalma listesi bulunamadı');
      }
      
      // Şarkıyı al
      const track = await this.getTrack(playlistTrackData.trackId);
      if (!track) {
        throw new Error('Şarkı bulunamadı');
      }
      
      // Şarkının zaten listede olup olmadığını kontrol et
      const existingTrack = await PlaylistTrackModel.findOne({
        playlistId: playlistTrackData.playlistId,
        trackId: playlistTrackData.trackId
      });
      
      if (existingTrack) {
        return existingTrack;
      }
      
      // Yeni PlaylistTrack oluştur
      const playlistTrack = new PlaylistTrackModel(playlistTrackData);
      const savedPlaylistTrack = await playlistTrack.save();
      
      // Çalma listesi bilgilerini güncelle
      await PlaylistModel.findByIdAndUpdate(
        playlistTrackData.playlistId,
        { 
          $inc: { 
            trackCount: 1,
            duration: track.duration || 0
          } 
        }
      );
      
      return savedPlaylistTrack;
    } catch (error) {
      log(`Çalma listesine şarkı ekleme hatası: ${error}`, 'mongodb');
      throw error;
    }
  }
  
  async removeTrackFromPlaylist(playlistId: string, trackId: string): Promise<boolean> {
    try {
      // Şarkıyı ve pozisyonunu bul
      const playlistTrack = await PlaylistTrackModel.findOne({ playlistId, trackId });
      
      if (!playlistTrack) {
        return false;
      }
      
      // Şarkıyı sil
      await PlaylistTrackModel.findByIdAndDelete(playlistTrack._id);
      
      // Şarkı detaylarını al
      const track = await this.getTrack(trackId);
      
      // Çalma listesi bilgilerini güncelle
      if (track) {
        await PlaylistModel.findByIdAndUpdate(
          playlistId,
          { 
            $inc: { 
              trackCount: -1,
              duration: -(track.duration || 0)
            } 
          }
        );
      }
      
      // Diğer şarkıların pozisyonlarını güncelle
      await PlaylistTrackModel.updateMany(
        { playlistId, position: { $gt: playlistTrack.position } },
        { $inc: { position: -1 } }
      );
      
      return true;
    } catch (error) {
      log(`Çalma listesinden şarkı silme hatası: ${error}`, 'mongodb');
      return false;
    }
  }
  
  // Beğenilen şarkı metodları
  async getLikedTracks(userId: string): Promise<any[]> {
    try {
      // Kullanıcının beğendiği şarkı kayıtlarını al
      const likedTracks = await LikedTrackModel.find({ userId })
        .sort({ likedAt: -1 })
        .lean();
      
      // Şarkı ID'lerini al
      const trackIds = likedTracks.map(lt => lt.trackId);
      
      // Şarkı detaylarını getir
      const tracks = await TrackModel.find({ _id: { $in: trackIds } }).lean();
      
      return tracks;
    } catch (error) {
      log(`Beğenilen şarkıları getirme hatası: ${error}`, 'mongodb');
      return [];
    }
  }
  
  async isTrackLiked(userId: string, trackId: string): Promise<boolean> {
    try {
      const likedTrack = await LikedTrackModel.findOne({ userId, trackId });
      return !!likedTrack;
    } catch (error) {
      log(`Şarkı beğeni durumu kontrol hatası: ${error}`, 'mongodb');
      return false;
    }
  }
  
  async likeTrack(likedTrackData: any): Promise<any> {
    try {
      // Şarkının zaten beğenilip beğenilmediğini kontrol et
      const existingLike = await LikedTrackModel.findOne({
        userId: likedTrackData.userId,
        trackId: likedTrackData.trackId
      });
      
      if (existingLike) {
        return existingLike;
      }
      
      // Yeni beğeni oluştur
      const likedTrack = new LikedTrackModel(likedTrackData);
      return await likedTrack.save();
    } catch (error) {
      log(`Şarkı beğenme hatası: ${error}`, 'mongodb');
      throw error;
    }
  }
  
  async unlikeTrack(userId: string, trackId: string): Promise<boolean> {
    try {
      const result = await LikedTrackModel.findOneAndDelete({ userId, trackId });
      return !!result;
    } catch (error) {
      log(`Şarkı beğeni kaldırma hatası: ${error}`, 'mongodb');
      return false;
    }
  }
  
  // Son çalınan şarkı metodları
  async getRecentlyPlayed(userId: string, limit: number = 10): Promise<any[]> {
    try {
      // Kullanıcının son çaldığı şarkı kayıtlarını al
      const recentlyPlayed = await RecentlyPlayedModel.find({ userId })
        .sort({ playedAt: -1 })
        .limit(limit)
        .lean();
      
      // Şarkı ID'lerini al
      const trackIds = recentlyPlayed.map(rp => rp.trackId);
      
      // Şarkı detaylarını getir
      const tracks = await TrackModel.find({ _id: { $in: trackIds } }).lean();
      
      // Orijinal sıralamayı koru
      return recentlyPlayed.map(rp => {
        const track = tracks.find(t => t._id.toString() === rp.trackId.toString());
        return track;
      }).filter(Boolean);
    } catch (error) {
      log(`Son çalınan şarkıları getirme hatası: ${error}`, 'mongodb');
      return [];
    }
  }
  
  async addRecentlyPlayed(recentlyPlayedData: any): Promise<any> {
    try {
      // Şarkının zaten son çalınanlarda olup olmadığını kontrol et
      await RecentlyPlayedModel.findOneAndDelete({
        userId: recentlyPlayedData.userId,
        trackId: recentlyPlayedData.trackId
      });
      
      // Yeni kayıt oluştur (en son oynatılan olarak)
      const recentlyPlayed = new RecentlyPlayedModel(recentlyPlayedData);
      return await recentlyPlayed.save();
    } catch (error) {
      log(`Son çalınan şarkı ekleme hatası: ${error}`, 'mongodb');
      throw error;
    }
  }
  
  // Sohbet mesajı metodları
  async getUserChatMessages(userId: string): Promise<any[]> {
    try {
      return await ChatMessageModel.find({ userId })
        .sort({ timestamp: 1 })
        .lean();
    } catch (error) {
      log(`Kullanıcı sohbet mesajları getirme hatası: ${error}`, 'mongodb');
      return [];
    }
  }
  
  async addChatMessage(chatMessageData: any): Promise<any> {
    try {
      const chatMessage = new ChatMessageModel(chatMessageData);
      return await chatMessage.save();
    } catch (error) {
      log(`Sohbet mesajı ekleme hatası: ${error}`, 'mongodb');
      throw error;
    }
  }
}

// MongoDB depolama örneği
export const mongoStorage = new MongoDBStorage();