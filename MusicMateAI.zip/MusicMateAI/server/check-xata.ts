import { checkAndValidateData } from './xata-client';

// Xata veritabanındaki verileri kontrol et
async function main() {
  console.log("Xata veritabanı veri kontrolü başlatılıyor...");
  const result = await checkAndValidateData();
  
  if (result.success) {
    console.log("✅ Veri doğrulama başarılı");
    console.log(`Toplam sanatçı sayısı: ${result.artistCount}`);
    console.log(`Toplam şarkı sayısı: ${result.songCount}`);
  } else {
    console.error("❌ Veri doğrulama başarısız:", result.error);
  }
}

main().catch(error => {
  console.error("Hata oluştu:", error);
  process.exit(1);
});