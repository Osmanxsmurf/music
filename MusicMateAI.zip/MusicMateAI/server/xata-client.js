// Xata istemcisi için basit bir API modülü

// Xata API Key ve Database URL kullanarak direkt fetch istekleri yapacak bir API
const XATA_API_KEY = process.env.XATA_API_KEY || 'au_BJzzy94NsG0clOMuEXDC6747Qi2r07mJ0';
const XATA_DATABASE_URL = process.env.XATA_DATABASE_URL || 'https://Osman-zdo-an-s-workspace-rbheop.eu-central-1.xata.sh/db/music_assistant:main';

// Basit bir Xata istemcisi
const xataClient = {
  // Temel fetch işlemi
  async _fetch(path, options = {}) {
    const url = `${XATA_DATABASE_URL}${path}`;
    const headers = {
      'Authorization': `Bearer ${XATA_API_KEY}`,
      'Content-Type': 'application/json',
      'Accept': 'application/json',
      ...options.headers
    };

    try {
      const response = await fetch(url, {
        ...options,
        headers
      });

      if (!response.ok) {
        const error = await response.json();
        throw new Error(`Xata API error: ${error.message || response.statusText}`);
      }

      return await response.json();
    } catch (error) {
      console.error('Xata API request failed:', error);
      throw error;
    }
  },

  // Tablodaki tüm verileri getir
  async getAll(table) {
    return this._fetch(`/tables/${table}/query`, {
      method: 'POST',
      body: JSON.stringify({
        page: { size: 50 }
      })
    });
  },

  // ID'ye göre tek kayıt getir
  async getById(table, id) {
    return this._fetch(`/tables/${table}/data/${id}`);
  },

  // Filtreleme ile verileri getir
  async filter(table, filter, options = {}) {
    return this._fetch(`/tables/${table}/query`, {
      method: 'POST',
      body: JSON.stringify({
        filter,
        ...options
      })
    });
  },

  // Metin araması yap
  async search(table, query, options = {}) {
    return this._fetch(`/tables/${table}/search`, {
      method: 'POST',
      body: JSON.stringify({
        query,
        fuzziness: 1,
        ...options
      })
    });
  },

  // Yeni kayıt oluştur
  async create(table, data) {
    return this._fetch(`/tables/${table}/data`, {
      method: 'POST',
      body: JSON.stringify(data)
    });
  },

  // Kayıt güncelle
  async update(table, id, data) {
    return this._fetch(`/tables/${table}/data/${id}`, {
      method: 'PATCH',
      body: JSON.stringify(data)
    });
  },

  // Kayıt sil
  async delete(table, id) {
    return this._fetch(`/tables/${table}/data/${id}`, {
      method: 'DELETE'
    });
  }
};

// Veritabanının ve verilerin doğru olup olmadığını kontrol et
async function checkAndValidateData() {
  try {
    console.log("Veritabanı bağlantısı ve veri kontrolü başlatılıyor...");
    
    // Sanatçıları getir
    const artistsResponse = await xataClient.getAll('artists');
    const artists = artistsResponse.records || [];
    
    // Şarkıları getir
    const songsResponse = await xataClient.getAll('songs');
    const songs = songsResponse.records || [];
    
    console.log(`Veritabanında ${artists.length} sanatçı ve ${songs.length} şarkı bulundu.`);
    
    // Örnek verileri göster
    if (artists.length > 0) {
      console.log("\nÖrnek Sanatçılar:");
      artists.slice(0, 5).forEach(artist => {
        console.log(`- ${artist.name} (${artist.genre})`);
      });
    }
    
    if (songs.length > 0) {
      console.log("\nÖrnek Şarkılar:");
      songs.slice(0, 5).forEach(song => {
        console.log(`- "${song.title}" - ${song.artist} (${song.genre})`);
      });
      
      // Sanatçı ve şarkı eşleşme kontrolü
      console.log("\nSanatçı-Şarkı Eşleşme Kontrolü:");
      for (let i = 0; i < Math.min(5, songs.length); i++) {
        const song = songs[i];
        const matchingArtist = artists.find(a => a.name === song.artist);
        
        if (matchingArtist) {
          console.log(`✓ "${song.title}" şarkısı "${song.artist}" sanatçısına doğru şekilde eşleştirilmiş.`);
        } else {
          console.log(`✗ "${song.title}" şarkısı için "${song.artist}" sanatçısı bulunamadı.`);
        }
      }
      
      // Albüm kapak linklerini kontrol et
      console.log("\nAlbüm Kapağı Link Kontrolü:");
      const songsWithArt = songs.filter(s => s.albumArt);
      for (let i = 0; i < Math.min(5, songsWithArt.length); i++) {
        const song = songsWithArt[i];
        console.log(`- "${song.title}": ${song.albumArt}`);
      }
    }
    
    return {
      success: true,
      artistCount: artists.length,
      songCount: songs.length,
      artists: artists.slice(0, 10),
      songs: songs.slice(0, 10)
    };
  } catch (error) {
    console.error("Veri doğrulama hatası:", error);
    return {
      success: false,
      error: error.message
    };
  }
}

// Türe göre müzik önerileri getir
async function getMusicRecommendations(genre, limit = 5) {
  try {
    const response = await xataClient.filter('songs', {
      genre: { $contains: genre }
    }, { page: { size: 30 } });
    
    const songs = response.records || [];
    
    // Eğer yeterli şarkı yoksa tüm şarkıları getir
    if (songs.length < limit) {
      const allSongs = await xataClient.getAll('songs');
      return (allSongs.records || []).slice(0, limit);
    }
    
    // Rastgele şarkıları seç
    const shuffled = songs.sort(() => 0.5 - Math.random());
    return shuffled.slice(0, limit);
  } catch (error) {
    console.error("Müzik önerisi hatası:", error);
    // Varsayılan demo öneriler
    return [];
  }
}

// Sanatçı bilgisi getir
async function getArtistInfo(artistName) {
  try {
    const response = await xataClient.search('artists', artistName);
    const artists = response.records || [];
    
    if (artists.length > 0) {
      return artists[0];
    }
    
    return null;
  } catch (error) {
    console.error("Sanatçı bilgisi getirme hatası:", error);
    return null;
  }
}

// Şarkı ara
async function searchSongs(query, limit = 10) {
  try {
    const response = await xataClient.search('songs', query);
    const songs = response.records || [];
    return songs.slice(0, limit);
  } catch (error) {
    console.error("Şarkı arama hatası:", error);
    return [];
  }
}

// Varsayılan müzik türleri
const defaultMusicGenres = [
  { name: "Pop", description: "Türk ve yabancı pop müzik" },
  { name: "Rock", description: "Türk ve yabancı rock müzik" },
  { name: "Elektronik", description: "Elektronik dans müziği" },
  { name: "Klasik", description: "Klasik Türk ve Batı müziği" },
  { name: "Jazz", description: "Jazz ve füzyon türleri" },
  { name: "Halk", description: "Türk halk müziği ve türküler" },
  { name: "Rap", description: "Türkçe ve yabancı rap müzik" },
  { name: "Metal", description: "Heavy metal ve alt türleri" },
  { name: "Arabesk", description: "Arabesk müzik" }
];

// Müzik türlerini getir
async function getMusicGenres() {
  try {
    const response = await xataClient.getAll('genres');
    const genres = response.records || [];
    
    if (genres.length > 0) {
      return genres;
    }
    
    return defaultMusicGenres;
  } catch (error) {
    console.error("Müzik türleri getirme hatası:", error);
    return defaultMusicGenres;
  }
}

// Dışa aktarılan fonksiyonlar
export {
  xataClient,
  checkAndValidateData,
  getMusicRecommendations,
  getArtistInfo,
  searchSongs,
  getMusicGenres
};