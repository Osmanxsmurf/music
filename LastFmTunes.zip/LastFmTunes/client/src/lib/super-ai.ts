import { AiMessage } from "@shared/schema";
import { LASTFM_MOOD_MAPPING } from "./constants";

interface TopicRelevance {
  name: string;
  relevance: number; // 0-1 scale
}

interface UserPreference {
  artist?: string;
  genre?: string;
  mood?: string;
  era?: string;
  source: 'explicit' | 'inferred';
  confidence: number; // 0-1 scale
}

interface Feeling {
  primary: string;
  secondary?: string;
  intensity: number; // 0-1 scale
  confidence: number; // 0-1 scale
}

export interface BrainState {
  activeTopics: TopicRelevance[];
  userPreferences: UserPreference[];
  currentFeeling?: Feeling;
  processingSteps: string[];
  recommendationContext: string[];
}

// Music-related keywords and patterns for analysis
const GENRES = [
  'pop', 'rock', 'jazz', 'blues', 'classical', 'electronic', 'dance', 'hip hop', 'rap', 
  'r&b', 'reggae', 'country', 'folk', 'metal', 'punk', 'indie', 'alternative'
];

const ERAS = [
  '50s', '60s', '70s', '80s', '90s', '2000s', '2010s', '2020s',
  'fifties', 'sixties', 'seventies', 'eighties', 'nineties'
];

const MOOD_KEYWORDS: Record<string, string[]> = {
  'happy': ['happy', 'cheerful', 'upbeat', 'uplifting', 'joy', 'positive', 'fun'],
  'sad': ['sad', 'depressed', 'melancholy', 'heartbroken', 'tearful', 'sorrow', 'blue'],
  'energetic': ['energetic', 'energy', 'powerful', 'pump', 'workout', 'exercise', 'gym'],
  'calm': ['calm', 'peace', 'peaceful', 'relaxing', 'relax', 'chill', 'quiet', 'tranquil'],
  'romantic': ['romantic', 'love', 'passion', 'intimate', 'sensual', 'loving'],
  'angry': ['angry', 'rage', 'furious', 'mad', 'aggression', 'rebellious'],
  'nostalgic': ['nostalgic', 'nostalgia', 'memories', 'memory', 'remember', 'reminisce'],
  'focused': ['focused', 'focus', 'study', 'concentrate', 'concentration', 'deep work'],
  'party': ['party', 'club', 'dance', 'dancing', 'celebration', 'celebrate', 'festive']
};

// Topic identification patterns
const TOPIC_PATTERNS = [
  { name: 'artist recommendation', patterns: ['suggest artist', 'recommend artist', 'like the artist', 'similar to'] },
  { name: 'genre exploration', patterns: [...GENRES.map(g => g), 'genre'] },
  { name: 'mood based music', patterns: Object.values(MOOD_KEYWORDS).flat() },
  { name: 'music discovery', patterns: ['discover', 'new music', 'recommendations', 'never heard', 'suggest'] },
  { name: 'era specific', patterns: [...ERAS] },
  { name: 'playlist creation', patterns: ['playlist', 'collection', 'compile', 'make a list', 'curate'] },
  { name: 'song information', patterns: ['who sang', 'what album', 'when was', 'lyrics', 'meaning'] },
  { name: 'technical help', patterns: ['how to', 'not working', 'problem with', 'help with', 'trouble'] }
];

// Generate an AI analysis of the message
export function analyzeMessage(message: string, history: AiMessage[]): BrainState {
  const lowerMessage = message.toLowerCase();
  
  // Initialize brain state
  const brainState: BrainState = {
    activeTopics: [],
    userPreferences: [],
    processingSteps: [],
    recommendationContext: []
  };
  
  // Step 1: Identify topics from the message
  brainState.processingSteps.push('Analyzing message content for topics');
  TOPIC_PATTERNS.forEach(topic => {
    let matchCount = 0;
    let relevanceScore = 0;
    
    topic.patterns.forEach(pattern => {
      if (lowerMessage.includes(pattern)) {
        matchCount++;
      }
    });
    
    if (matchCount > 0) {
      relevanceScore = Math.min(matchCount / 3, 1); // Cap at 1
      brainState.activeTopics.push({
        name: topic.name,
        relevance: relevanceScore
      });
    }
  });
  
  // Sort topics by relevance
  brainState.activeTopics.sort((a, b) => b.relevance - a.relevance);
  
  // Step 2: Extract music preferences
  brainState.processingSteps.push('Extracting music preferences');
  
  // Check for genre preferences
  GENRES.forEach(genre => {
    const genrePattern = new RegExp(`\\b${genre}\\b`, 'i');
    if (genrePattern.test(lowerMessage)) {
      brainState.userPreferences.push({
        genre,
        source: 'explicit',
        confidence: 0.9
      });
      brainState.recommendationContext.push(`User explicitly mentioned ${genre} genre`);
    }
  });
  
  // Check for era preferences
  ERAS.forEach(era => {
    const eraPattern = new RegExp(`\\b${era}\\b`, 'i');
    if (eraPattern.test(lowerMessage)) {
      brainState.userPreferences.push({
        era,
        source: 'explicit',
        confidence: 0.9
      });
      brainState.recommendationContext.push(`User explicitly mentioned ${era} era`);
    }
  });
  
  // Check for mood preferences
  Object.entries(MOOD_KEYWORDS).forEach(([mood, keywords]) => {
    for (const keyword of keywords) {
      if (lowerMessage.includes(keyword)) {
        brainState.userPreferences.push({
          mood,
          source: 'explicit',
          confidence: 0.9
        });
        brainState.recommendationContext.push(`User expressed interest in ${mood} mood`);
        break;
      }
    }
  });
  
  // Step 3: Analyze artist mentions
  brainState.processingSteps.push('Identifying mentioned artists');
  
  // Very simple artist detection - in a real app would use a knowledge base or API
  const artistPatterns = [
    /(?:like|love|enjoy|fan of|similar to|by)\s+([A-Z][a-z]+(?: [A-Z][a-z]+)*)/g,
    /([A-Z][a-z]+(?: [A-Z][a-z]+)*)\s+(?:songs|music|tracks|albums)/g
  ];
  
  artistPatterns.forEach(pattern => {
    const matches = lowerMessage.matchAll(pattern);
    for (const match of matches) {
      if (match[1]) {
        const potentialArtist = match[1].trim();
        // Filter out common words that might be caught
        if (potentialArtist.length > 3 && !['the', 'and', 'but', 'like'].includes(potentialArtist)) {
          brainState.userPreferences.push({
            artist: potentialArtist,
            source: 'inferred',
            confidence: 0.7
          });
          brainState.recommendationContext.push(`Detected potential artist mention: ${potentialArtist}`);
        }
      }
    }
  });
  
  // Step 4: Sentiment analysis for mood detection
  brainState.processingSteps.push('Analyzing sentiment and mood');
  
  // Simple keyword-based sentiment analysis
  const moodKeywordMatches: Record<string, number> = {};
  Object.entries(MOOD_KEYWORDS).forEach(([mood, keywords]) => {
    moodKeywordMatches[mood] = 0;
    keywords.forEach(keyword => {
      if (lowerMessage.includes(keyword)) {
        moodKeywordMatches[mood]++;
      }
    });
  });
  
  // Determine primary mood from keywords
  const moodEntries = Object.entries(moodKeywordMatches);
  if (moodEntries.some(([_, count]) => count > 0)) {
    moodEntries.sort((a, b) => b[1] - a[1]);
    const [primaryMood, primaryCount] = moodEntries[0];
    
    const totalMatches = moodEntries.reduce((sum, [_, count]) => sum + count, 0);
    const confidence = Math.min(primaryCount / totalMatches, 0.95);
    
    let secondaryMood = undefined;
    if (moodEntries.length > 1 && moodEntries[1][1] > 0) {
      secondaryMood = moodEntries[1][0];
    }
    
    // Calculate intensity based on language
    const intensityKeywords = {
      high: ['very', 'really', 'extremely', 'so', 'super', 'incredibly', 'highly'],
      low: ['slightly', 'somewhat', 'a bit', 'kind of', 'a little']
    };
    
    let intensity = 0.5; // Default to middle intensity
    intensityKeywords.high.forEach(word => {
      if (lowerMessage.includes(word)) intensity = Math.min(intensity + 0.15, 1);
    });
    intensityKeywords.low.forEach(word => {
      if (lowerMessage.includes(word)) intensity = Math.max(intensity - 0.15, 0);
    });
    
    brainState.currentFeeling = {
      primary: primaryMood,
      secondary: secondaryMood,
      intensity,
      confidence
    };
    
    brainState.recommendationContext.push(`Detected ${primaryMood} mood with ${Math.round(confidence * 100)}% confidence`);
    if (secondaryMood) {
      brainState.recommendationContext.push(`Secondary mood detected: ${secondaryMood}`);
    }
  }
  
  // Step 5: Analyze context from previous messages (basic)
  if (history.length > 0) {
    brainState.processingSteps.push('Analyzing conversation history for context');
    
    // Get the last few messages for context
    const recentHistory = history.slice(-5);
    
    // Look for unanswered questions or follow-ups
    const userMessages = recentHistory.filter(msg => msg.role === 'user');
    const assistantMessages = recentHistory.filter(msg => msg.role === 'assistant');
    
    if (userMessages.length > 0 && lowerMessage.length < 20) {
      // Short reply might be a follow-up to previous topic
      brainState.recommendationContext.push('User message is short, likely a follow-up to previous conversation');
      
      // Try to carry over context from last substantial message
      for (let i = userMessages.length - 1; i >= 0; i--) {
        const prevMsg = userMessages[i].content.toLowerCase();
        if (prevMsg.length > 30) {
          // Check for genre context
          GENRES.forEach(genre => {
            if (prevMsg.includes(genre.toLowerCase())) {
              brainState.userPreferences.push({
                genre,
                source: 'inferred',
                confidence: 0.6
              });
              brainState.recommendationContext.push(`Carrying genre context (${genre}) from previous message`);
            }
          });
          
          // Check for mood context
          Object.entries(MOOD_KEYWORDS).forEach(([mood, keywords]) => {
            for (const keyword of keywords) {
              if (prevMsg.includes(keyword)) {
                brainState.userPreferences.push({
                  mood,
                  source: 'inferred',
                  confidence: 0.6
                });
                brainState.recommendationContext.push(`Carrying mood context (${mood}) from previous message`);
                break;
              }
            }
          });
          
          break;
        }
      }
    }
  }
  
  return brainState;
}

// Generate AI response (simplified implementation)
export function generateResponse(message: string, brainState: BrainState): string {
  // This is a simplified implementation - a real one would likely use an external AI service
  const { activeTopics, userPreferences, currentFeeling } = brainState;
  
  // Start with a greeting if needed
  let response = '';
  
  // Determine the most relevant topic
  if (activeTopics.length > 0) {
    const primaryTopic = activeTopics[0].name;
    
    switch (primaryTopic) {
      case 'artist recommendation':
        response = generateArtistRecommendationResponse(userPreferences);
        break;
      case 'genre exploration':
        response = generateGenreExplorationResponse(userPreferences);
        break;
      case 'mood based music':
        response = generateMoodBasedResponse(currentFeeling, userPreferences);
        break;
      case 'music discovery':
        response = generateDiscoveryResponse(userPreferences);
        break;
      case 'era specific':
        response = generateEraResponse(userPreferences);
        break;
      case 'playlist creation':
        response = generatePlaylistResponse(userPreferences, currentFeeling);
        break;
      case 'song information':
        response = "I'd be happy to help you find information about that song. Could you provide the title or some lyrics?";
        break;
      case 'technical help':
        response = "I can help you troubleshoot technical issues with the app. What specific problem are you experiencing?";
        break;
      default:
        response = "I'm here to help with music recommendations and discovery. What would you like to listen to today?";
    }
  } else {
    // Default response if no clear topic
    response = "I'd be happy to help you discover new music or find something that matches your mood. What kinds of songs are you interested in?";
  }
  
  return response;
}

// Helper for artist recommendation responses
function generateArtistRecommendationResponse(preferences: UserPreference[]): string {
  const artistPrefs = preferences.filter(p => p.artist);
  
  if (artistPrefs.length > 0) {
    const artist = artistPrefs[0].artist;
    return `If you enjoy ${artist}, I'd recommend checking out similar artists like [Similar Artist 1], [Similar Artist 2], and [Similar Artist 3]. Would you like me to create a playlist based on this style?`;
  }
  
  return "I'd be happy to recommend some artists. Could you tell me about some musicians or bands you currently enjoy?";
}

// Helper for genre exploration responses
function generateGenreExplorationResponse(preferences: UserPreference[]): string {
  const genrePrefs = preferences.filter(p => p.genre);
  
  if (genrePrefs.length > 0) {
    const genre = genrePrefs[0].genre;
    return `${genre} is a great genre! Some notable ${genre} artists include [Artist 1], [Artist 2], and [Artist 3]. Would you like recommendations for classic or contemporary ${genre} tracks?`;
  }
  
  return "I can help you explore different music genres. Is there a particular style you're interested in, like rock, pop, jazz, or electronic?";
}

// Helper for mood-based responses
function generateMoodBasedResponse(feeling: Feeling | undefined, preferences: UserPreference[]): string {
  if (feeling) {
    const mood = feeling.primary;
    const intensity = feeling.intensity > 0.7 ? 'very ' : feeling.intensity < 0.3 ? 'slightly ' : '';
    
    return `I understand you're feeling ${intensity}${mood}. Music can be a great companion for this mood. I'd recommend some ${mood} tracks like [Song 1] by [Artist 1], [Song 2] by [Artist 2], and [Song 3] by [Artist 3]. Would you like me to create a playlist for this mood?`;
  }
  
  const moodPrefs = preferences.filter(p => p.mood);
  if (moodPrefs.length > 0) {
    const mood = moodPrefs[0].mood;
    return `For ${mood} music, I'd recommend tracks like [Song 1] by [Artist 1], [Song 2] by [Artist 2], and [Song 3] by [Artist 3]. These songs are perfect for ${mood} moments.`;
  }
  
  return "I can suggest music based on your mood. Are you feeling energetic, relaxed, happy, melancholic, or something else?";
}

// Helper for discovery responses
function generateDiscoveryResponse(preferences: UserPreference[]): string {
  let context = '';
  
  // Try to use user preferences for context
  if (preferences.length > 0) {
    // Prioritize preferences by confidence
    preferences.sort((a, b) => b.confidence - a.confidence);
    const pref = preferences[0];
    
    if (pref.genre) {
      context = ` based on your interest in ${pref.genre}`;
    } else if (pref.mood) {
      context = ` that match a ${pref.mood} mood`;
    } else if (pref.artist) {
      context = ` similar to ${pref.artist}`;
    } else if (pref.era) {
      context = ` from the ${pref.era}`;
    }
  }
  
  return `I'd love to help you discover new music${context}! Here are some tracks that you might not have heard before: [Song 1] by [Artist 1], [Song 2] by [Artist 2], and [Song 3] by [Artist 3]. Would you like more recommendations?`;
}

// Helper for era-specific responses
function generateEraResponse(preferences: UserPreference[]): string {
  const eraPrefs = preferences.filter(p => p.era);
  
  if (eraPrefs.length > 0) {
    const era = eraPrefs[0].era;
    return `Music from the ${era} has such a distinctive sound! Some iconic tracks from that era include [Song 1] by [Artist 1], [Song 2] by [Artist 2], and [Song 3] by [Artist 3]. Would you like me to create a ${era} playlist for you?`;
  }
  
  return "I can recommend music from specific time periods. Which era are you interested in - the 60s, 70s, 80s, 90s, 2000s, or something more recent?";
}

// Helper for playlist responses
function generatePlaylistResponse(preferences: UserPreference[], feeling: Feeling | undefined): string {
  let theme = '';
  
  // Try to determine playlist theme from preferences or feeling
  if (preferences.length > 0) {
    if (preferences.some(p => p.genre)) {
      const genre = preferences.find(p => p.genre)?.genre;
      theme = `${genre} `;
    } else if (preferences.some(p => p.mood)) {
      const mood = preferences.find(p => p.mood)?.mood;
      theme = `${mood} `;
    } else if (preferences.some(p => p.era)) {
      const era = preferences.find(p => p.era)?.era;
      theme = `${era} `;
    } else if (preferences.some(p => p.artist)) {
      const artist = preferences.find(p => p.artist)?.artist;
      theme = `${artist}-inspired `;
    }
  } else if (feeling) {
    theme = `${feeling.primary} `;
  }
  
  return `I'd be happy to create a ${theme}playlist for you! It would include tracks like [Song 1] by [Artist 1], [Song 2] by [Artist 2], and [Song 3] by [Artist 3]. Would you like me to save this playlist for you?`;
}

// String similarity helper (for matching user inputs with catalog items)
export function similarity(a: string, b: string): number {
  const aWords = a.toLowerCase().split(/\s+/);
  const bWords = b.toLowerCase().split(/\s+/);
  
  let matches = 0;
  for (const word of aWords) {
    if (word.length > 2 && bWords.some(w => w.includes(word) || word.includes(w))) {
      matches++;
    }
  }
  
  const totalWords = Math.max(aWords.length, bWords.length);
  return totalWords > 0 ? matches / totalWords : 0;
}

// Helper to shuffle an array (for randomized recommendations)
export function shuffleArray<T>(array: T[]): T[] {
  const newArray = [...array];
  for (let i = newArray.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [newArray[i], newArray[j]] = [newArray[j], newArray[i]];
  }
  return newArray;
}
