/**
 * Kapsamlı Müzik AI Eğitim Veri Seti (Bölüm 1)
 * Bu veri seti, müzik yapay zekası için eğitim verisi sağlamaktadır.
 */

// Türkçe müzik sohbet yapay zekası için eğitim veri seti
const musicAITrainingData = {
  // =====================================================================
  // TEMEL MÜZİK BİLGİSİ VE TERMİNOLOJİ
  // =====================================================================
  
  musicBasics: [
    // Müzik teorisi ve temel kavramlar - Notalar, akorlar, tonlar ve daha fazlası
    {
      question: "Nota nedir?",
      answer: "Nota, belirli bir perdeye (frekansa) sahip olan bir ses birimidir. Batı müziğinde yedi temel nota vardır: Do (C), Re (D), Mi (E), Fa (F), Sol (G), La (A) ve Si (B). Bu notalar farklı oktavlarda tekrarlanır."
    },
    {
      question: "Akor nedir?",
      answer: "Akor, aynı anda çalınan üç veya daha fazla notanın oluşturduğu armoni birimidir. Temel akorlar majör ve minör akorlar olarak ikiye ayrılır. Örneğin, Do majör akoru Do, Mi ve Sol notalarından oluşur."
    },
    {
      question: "Oktav ne demektir?",
      answer: "Oktav, bir notanın frekansının iki katı veya yarısı olan aynı isimli nota arasındaki mesafedir. Örneğin, bir La notasının 440 Hz frekansı varsa, bir oktav yukarıdaki La notasının frekansı 880 Hz'dir."
    },
    {
      question: "Tonalite nedir?",
      answer: "Tonalite, bir müzik parçasının hangi ton etrafında düzenlendiğini belirten müzikal bir kavramdır. Do majör, La minör gibi farklı tonaliteler vardır. Her tonalitenin kendine özgü bir dizi ve armonik yapısı bulunur."
    },
    {
      question: "Ritim nedir?",
      answer: "Ritim, müziğin zamansal organizasyonudur. Vuruşların, vurguların ve sürelerin düzenlenmesiyle oluşur. 4/4, 3/4, 6/8 gibi farklı ritim kalıpları vardır."
    },
    {
      question: "Melodi nedir?",
      answer: "Melodi, müzikte art arda gelen ve anlam bütünlüğü oluşturan notalar dizisidir. Bir şarkının akılda kalan ve genellikle söylenen kısmını oluşturur."
    },
    {
      question: "Armoni nedir?",
      answer: "Armoni, farklı notaların aynı anda çalınması sonucu oluşan ses bütünlüğüdür. Müzikte derinlik ve dokuyu sağlar. Akorlar ve akor ilerlemeleri armoniyi oluşturur."
    },
    {
      question: "Tempo nedir?",
      answer: "Tempo, müziğin çalınma hızıdır. Genellikle dakikadaki vuruş sayısı (BPM - Beats Per Minute) ile ifade edilir. Allegro (hızlı), Andante (orta hızda), Adagio (yavaş) gibi terimlerle de belirtilir."
    },
    {
      question: "Dinamik nedir?",
      answer: "Dinamik, müziğin ses şiddetindeki değişimleri ifade eder. Piano (hafif), forte (güçlü), crescendo (giderek güçlenen), diminuendo (giderek hafifleyen) gibi terimlerle gösterilir."
    },
    {
      question: "Tını nedir?",
      answer: "Tını (timbre), aynı notayı çalan farklı enstrümanların veya seslerin ayırt edilmesini sağlayan ses rengidir. Bir kemanın, bir piyanonun veya bir insan sesinin kendine özgü tınısı vardır."
    },
    
    // Enstrümanlar ve ses kategorileri
    {
      question: "Yaylı çalgılar nelerdir?",
      answer: "Yaylı çalgılar, ses üretmek için telleri yay ile çekilen enstrümanlardır. Keman, viyola, viyolonsel ve kontrbas temel yaylı çalgılardır. Türk müziğinde kemençe de bir yaylı çalgıdır."
    },
    {
      question: "Üflemeli çalgılar nelerdir?",
      answer: "Üflemeli çalgılar, ses üretmek için içlerine hava üflenen enstrümanlardır. Tahta üflemeliler (flüt, klarnet, obua, fagot) ve bakır üflemeliler (trompet, trombon, korno, tuba) olarak ikiye ayrılır. Türk müziğinde ney, zurna, kaval gibi üflemeli çalgılar vardır."
    },
    {
      question: "Vurmalı çalgılar nelerdir?",
      answer: "Vurmalı çalgılar, vurarak, çarparak veya sallayarak ses çıkarılan enstrümanlardır. Davul, darbuka, zil, timpani, ksilofon gibi çeşitleri vardır. Ritim sağlamada önemli rol oynarlar."
    },
    {
      question: "Telli çalgılar nelerdir?",
      answer: "Telli çalgılar, teller titreştirilerek ses çıkarılan enstrümanlardır. Gitar, bağlama, ud, kanun, piyano (aslında hem telli hem de vurmalı bir çalgıdır) gibi çeşitleri vardır."
    },
    {
      question: "Ses aralıkları nasıl sınıflandırılır?",
      answer: "İnsan sesleri genellikle soprano, alto, tenor ve bas olarak sınıflandırılır. Soprano en tiz kadın sesi, alto daha pest kadın sesi, tenor tiz erkek sesi, bas ise pest erkek sesidir. Bunların arasında mezzo-soprano ve bariton gibi ara kategoriler de vardır."
    },
    
    // Müzik türleri ve stilleri
    {
      question: "Klasik müzik nedir?",
      answer: "Klasik müzik, Batı müzik geleneğinde gelişen ve genellikle karmaşık müzikal yapılar içeren bir türdür. Barok, Klasik, Romantik ve Çağdaş gibi dönemlere ayrılır. Bach, Mozart, Beethoven gibi besteciler bu türün önemli temsilcileridir."
    },
    {
      question: "Pop müzik nedir?",
      answer: "Pop müzik, popüler müzik olarak da bilinen, geniş kitlelere hitap eden ve genellikle kolay hatırlanabilir melodiler, tekrarlayan ritimlere sahip müzik türüdür. Dünya çapında Michael Jackson, Madonna; Türkiye'de ise Tarkan, Sezen Aksu gibi sanatçılar pop müziğin temsilcileridir."
    },
    {
      question: "Rock müzik nedir?",
      answer: "Rock müzik, elektro gitar, bas gitar ve davul üzerine kurulu, genellikle güçlü ritimler ve vokaller içeren bir türdür. The Beatles, Queen, Pink Floyd gibi gruplar dünyada; Duman, Mor ve Ötesi, Manga gibi gruplar Türkiye'de rock müziğin önemli temsilcileridir."
    },
    {
      question: "Jazz nedir?",
      answer: "Jazz, 20. yüzyılın başlarında ABD'de doğan, doğaçlama ve swing ritimlere dayanan bir müzik türüdür. Louis Armstrong, Miles Davis, John Coltrane gibi müzisyenler jazz'ın gelişiminde önemli rol oynamıştır. Türkiye'de Kerem Görsev, İlhan Erşahin gibi sanatçılar jazz müziği icra etmektedir."
    },
    {
      question: "Elektronik müzik nedir?",
      answer: "Elektronik müzik, elektronik cihazlar ve bilgisayarlarla üretilen müzik türüdür. House, techno, dubstep, trance gibi alt türleri vardır. Daft Punk, Avicii, Skrillex gibi sanatçılar dünyada; Mercan Dede, Ah! Kosmos gibi sanatçılar Türkiye'de elektronik müziğin temsilcileridir."
    },
    {
      question: "Türk Halk Müziği nedir?",
      answer: "Türk Halk Müziği, Anadolu'nun çeşitli bölgelerinde gelişen, yerel kültürleri ve yaşanmışlıkları yansıtan geleneksel müzik türüdür. Türkü formunda olan bu müzik, bağlama, kaval, zurna gibi enstrümanlarla icra edilir. Neşet Ertaş, Aşık Veysel, Arif Sağ gibi sanatçılar bu türün önemli temsilcileridir."
    },
    {
      question: "Türk Sanat Müziği nedir?",
      answer: "Türk Sanat Müziği, Osmanlı saray müziğinden gelişen, makam sistemi üzerine kurulu, ince detaylar içeren bir müzik türüdür. Ud, kanun, ney, tanbur gibi enstrümanlarla icra edilir. Münir Nurettin Selçuk, Zeki Müren, Müzeyyen Senar gibi sanatçılar bu türün önemli temsilcileridir."
    },
    {
      question: "Arabesk müzik nedir?",
      answer: "Arabesk, 1960'larda Türkiye'de gelişen, Arap müziğinden etkilenen, genellikle hüzün ve acı temalarını işleyen bir müzik türüdür. Orhan Gencebay, Müslüm Gürses, Bergen gibi sanatçılar arabesk müziğin önemli temsilcileridir."
    },
    {
      question: "Rap/Hip-Hop nedir?",
      answer: "Rap müzik, ritmik ve kafiyeli sözlerin bir beat üzerine söylendiği, hip-hop kültürünün bir parçası olan müzik türüdür. ABD'de doğmuş olsa da dünya çapında yaygınlaşmıştır. Türkiye'de Ceza, Sagopa Kajmer, Ezhel gibi sanatçılar Türkçe rap'in önemli temsilcileridir."
    },
    {
      question: "Metal müzik nedir?",
      answer: "Metal müzik, güçlü distorsiyonlu gitarlar, yoğun davul ritimleri ve genellikle güçlü vokaller içeren bir rock alt türüdür. Black Sabbath, Metallica, Iron Maiden gibi gruplar dünyada; Pentagram (Mezarkabul), Murder King gibi gruplar Türkiye'de metal müziğin temsilcileridir."
    },
    
    // Müzikal ekipmanlar ve teknoloji
    {
      question: "DAW nedir?",
      answer: "DAW (Digital Audio Workstation), müzik üretimi, kayıt, düzenleme ve miksleme için kullanılan dijital yazılımlardır. Ableton Live, FL Studio, Logic Pro, Pro Tools gibi popüler DAW'lar vardır."
    },
    {
      question: "MIDI nedir?",
      answer: "MIDI (Musical Instrument Digital Interface), elektronik müzik aletleri ve bilgisayarlar arasında müzikal verilerin iletilmesini sağlayan standart bir protokoldür. Bir MIDI dosyası, hangi notanın ne zaman, hangi şiddette ve hangi enstrümanla çalınacağı bilgisini içerir."
    },
    {
      question: "Amplifikatör nedir?",
      answer: "Amplifikatör (amfi), elektrikli veya elektronik müzik aletlerinden gelen sinyalleri güçlendirerek daha yüksek sesle duyulmasını sağlayan cihazdır. Elektro gitarlar, bas gitarlar ve bazı klavyeler için amfiler yaygın olarak kullanılır."
    },
    {
      question: "Mikrofon türleri nelerdir?",
      answer: "Mikrofon türleri arasında dinamik, kondansatör ve şerit mikrofonlar bulunur. Dinamik mikrofonlar dayanıklıdır ve yüksek ses basıncıyla başa çıkabilir (canlı performanslarda kullanılır). Kondansatör mikrofonlar daha hassastır ve stüdyo kayıtlarında tercih edilir. Şerit mikrofonlar ise klasik bir ses karakteri sunar ve özellikle vokaller ve akustik enstrümanlar için kullanılır."
    },
    {
      question: "Ekolayzer nedir?",
      answer: "Ekolayzer (EQ), bir ses sinyalindeki farklı frekans aralıklarının seviyelerini ayarlamaya yarayan ses işleme aracıdır. Bas, mid ve tiz frekansları dengelemek, belirli frekansları öne çıkarmak veya bastırmak için kullanılır."
    },
    {
      question: "Kompresör nedir?",
      answer: "Kompresör, bir ses sinyalinin dinamik aralığını (en yüksek ve en düşük ses seviyeleri arasındaki fark) azaltan ses işleme aracıdır. Sesin daha dengeli ve kontrollü olmasını sağlar. Vokal kayıtlarında, davul seslerinde ve genel mikste yaygın olarak kullanılır."
    },
    {
      question: "Reverberation (reverb) nedir?",
      answer: "Reverb, ses dalgalarının bir mekânda yüzeylerden yansıması sonucu oluşan akustik etkidir. Dijital ortamda eklemeli olarak kullanılan reverb efekti, sese derinlik ve hacim katar. Farklı mekan akustiklerini (salon, oda, kilise vb.) simüle etmek için kullanılır."
    },
    {
      question: "Ses formatları nelerdir?",
      answer: "Yaygın dijital ses formatları arasında WAV (kayıpsız, yüksek kalite), MP3 (kayıplı sıkıştırma, daha küçük dosya boyutu), FLAC (kayıpsız sıkıştırma), AAC (gelişmiş kayıplı sıkıştırma) bulunur. Profesyonel müzik üretiminde genellikle kayıpsız formatlar tercih edilir."
    },
    {
      question: "Autotune nedir?",
      answer: "Autotune, vokallerdeki perde (pitch) hatalarını düzeltmek veya özel bir efekt olarak kullanmak için geliştirilen bir ses işleme yazılımıdır. T-Pain, Cher gibi sanatçılar belirgin autotune efektiyle tanınır."
    },
    {
      question: "Sample nedir?",
      answer: "Sample, mevcut bir ses kaydından alınan ve yeni bir müzik parçasında kullanılan ses kesitidir. Hip-hop'ta, elektronik müzikte ve modern müzik üretiminde yaygın olarak kullanılır. Sampling yaparken telif hakları konusuna dikkat edilmelidir."
    }
  ],
  
  // =====================================================================
  // MÜZİK TÜRLERİ VE ALT TÜRLERİ HAKKINDA DETAYLI BİLGİLER
  // =====================================================================
  
  musicGenresDetailed: [
    // Türk Müzik Türleri
    {
      genre: "Türk Halk Müziği",
      description: "Türk Halk Müziği, Anadolu'nun farklı bölgelerinde gelişmiş, yerel halkın duygularını, yaşanmışlıklarını yansıtan geleneksel müzik türüdür. Genellikle türkü formunda olan bu müzik türü, yörelere göre farklı karakteristik özellikler gösterir.",
      subgenres: [
        {
          name: "Bozlak",
          description: "Orta Anadolu'ya özgü, uzun havalar grubunda yer alan, genellikle acı, keder, hasret gibi duyguları anlatan, tiz perdeden başlayıp pest seslere inen bir türkü türüdür."
        },
        {
          name: "Halay",
          description: "Doğu ve Güneydoğu Anadolu bölgelerine özgü, toplu olarak oynanan oyunlar eşliğinde söylenen, canlı ritimli türkülerdir."
        },
        {
          name: "Zeybek",
          description: "Ege bölgesine özgü, genellikle 9/8'lik ölçüde, zeybek oyunu eşliğinde söylenen türkülerdir."
        },
        {
          name: "Horon",
          description: "Karadeniz bölgesine özgü, hızlı tempolu, kemençe eşliğinde söylenen ve oynanan türkülerdir."
        },
        {
          name: "Karşılama",
          description: "Marmara ve Trakya bölgelerine özgü, 9/8'lik ölçüde, karşılıklı oynanan oyunlar eşliğinde söylenen türkülerdir."
        }
      ],
      instruments: ["Bağlama", "Zurna", "Davul", "Kaval", "Kemençe", "Sipsi", "Kabak Kemane", "Tulum", "Def", "Darbuka"],
      notable_artists: ["Neşet Ertaş", "Aşık Veysel", "Arif Sağ", "Belkıs Akkale", "Mahmut Tuncer", "Selda Bağcan", "İbrahim Tatlıses", "Özgür Akdemir", "Musa Eroğlu", "Şükriye Tutkun"],
      characteristics: "Genellikle yerel ağızlarla söylenir, bölgeden bölgeye değişen ritimler ve melodik yapılar içerir. Konuları arasında aşk, gurbet, doğa, kahramanlık, toplumsal olaylar yer alır."
    },
    {
      genre: "Türk Sanat Müziği",
      description: "Türk Sanat Müziği, Osmanlı saray müziğinden gelişen, geleneksel Türk makam sistemine dayalı, ince ve zarif detaylar içeren klasik Türk müziğidir. Genellikle eğitimli müzisyenler tarafından icra edilir.",
      subgenres: [
        {
          name: "Klasik Türk Müziği",
          description: "Geleneksel makam sistemini kullanan, 16-19. yüzyıllarda gelişen formları içeren (peşrev, saz semaisi, beste, ağır semai, yürük semai vb.) klasik eserlerdir."
        },
        {
          name: "Türk Tasavvuf Müziği",
          description: "Dini içerikli, tasavvuf felsefesini yansıtan, ilahi, nefes, Mevlevi ayini gibi formları içeren müzik türüdür."
        },
        {
          name: "Şarkı",
          description: "19. yüzyıldan itibaren yaygınlaşan, daha sade ve zemin-nakarat-meyan bölümlerinden oluşan modern bir formdur."
        }
      ],
      instruments: ["Ud", "Kanun", "Ney", "Tanbur", "Kemençe", "Kudüm", "Bendir", "Rebab", "Keman", "Viyolonsel"],
      notable_artists: ["Münir Nurettin Selçuk", "Zeki Müren", "Müzeyyen Senar", "Bekir Sıdkı Sezgin", "Ahmet Özhan", "Melihat Gülses", "Emel Sayın", "Bülent Ersoy", "Mustafa Keser", "Alâeddin Yavaşça"],
      characteristics: "Makam sistemi üzerine kuruludur, zengin süslemeler ve nüanslar içerir, genellikle şiirsel ve edebi metinleri kullanır, çoğunlukla aşk, hasret, doğa güzellikleri gibi temaları işler."
    },
    {
      genre: "Arabesk",
      description: "Arabesk, 1960'larda Türkiye'de gelişen, Arap müziğinden etkilenen, genellikle kader, acı, ayrılık gibi temaları işleyen, melismatik vokal teknikleri içeren bir müzik türüdür.",
      subgenres: [
        {
          name: "Klasik Arabesk",
          description: "1960-80 arası gelişen, Orhan Gencebay, Ferdi Tayfur gibi sanatçıların öncülük ettiği, orkestrasyonunda Arap müziği etkilerinin belirgin olduğu dönem."
        },
        {
          name: "Taverna Müziği",
          description: "1980'lerde popülerleşen, gece kulüplerinde, tavernalarda icra edilen, arabesk ve Türk sanat müziği karışımı bir tür."
        },
        {
          name: "Fantezi Müzik",
          description: "Arabesk ile pop müziğin sentezi, daha modern aranjmanlar içeren bir alt tür."
        },
        {
          name: "Arabesk-Rap",
          description: "2000'lerde ortaya çıkan, arabesk melodileri ve temalarını rap müzikle birleştiren modern bir füzyon."
        }
      ],
      instruments: ["Elektro Bağlama", "Org", "Yaylı Çalgılar", "Kanun", "Ud", "Darbuka", "Def", "Elektro Gitar", "Synthesizer", "Klarnet"],
      notable_artists: ["Orhan Gencebay", "Müslüm Gürses", "Ferdi Tayfur", "Bergen", "İbrahim Tatlıses", "Gülden Karaböcek", "Hakan Altun", "Ebru Gündeş", "Alişan", "Serkan Kaya"],
      characteristics: "Hüzünlü, dramatik melodiler, melismatik vokal tekniği (uzun havalar), kaderci temalar, yoğun orkestrasyonlar, sıklıkla yaylı çalgıların kullanımı."
    },
    {
      genre: "Türk Pop Müziği",
      description: "Türk Pop Müziği, 1960'lardan itibaren gelişen, Batı pop müziğinden etkilenen ancak Türk müzik unsurlarını da içeren, geniş kitlelere hitap eden bir müzik türüdür.",
      subgenres: [
        {
          name: "Anadolu Pop",
          description: "1960-70'lerde gelişen, geleneksel Türk halk müziği ile Batı rock ve pop unsurlarını birleştiren bir tür. Barış Manço, Cem Karaca gibi sanatçılar öncülük etmiştir."
        },
        {
          name: "Türk Pop",
          description: "1990'lardan itibaren yaygınlaşan, modern prodüksiyon teknikleriyle üretilen, Batı pop müziğine daha yakın olan ana akım türü."
        },
        {
          name: "Alternatif Türkçe Pop",
          description: "Ana akım poptan farklılaşan, daha deneysel, indie veya alternatif unsurlara sahip modern Türkçe pop."
        }
      ],
      instruments: ["Elektronik Davul", "Elektro Gitar", "Bas Gitar", "Piyano", "Synthesizer", "Akustik Gitar", "Yaylı Çalgılar", "Bağlama", "Perküsyon", "Elektro Saz"],
      notable_artists: ["Sezen Aksu", "Tarkan", "Ajda Pekkan", "Barış Manço", "Mustafa Sandal", "Hande Yener", "Kenan Doğulu", "Gülşen", "Murat Boz", "Hadise"],
      characteristics: "Kolay hatırlanabilir melodiler, dans edilebilir ritimler, modern prodüksiyon teknikleri, geniş kitlelere hitap eden temalar, Batı ve Türk müziği unsurlarının sentezi."
    },
    {
      genre: "Türk Rock Müziği",
      description: "Türk Rock Müziği, 1960'lardan itibaren gelişen, Batı rock müziğinin etkilerini taşıyan, elektro gitar odaklı, Türkçe sözlü rock müziğidir.",
      subgenres: [
        {
          name: "Anadolu Rock",
          description: "1960-70'lerde ortaya çıkan, Türk halk müziği ile rock müziği birleştiren, psikeledik etkiler taşıyan türdür. Erkin Koray, Cem Karaca, Barış Manço öncülük etmiştir."
        },
        {
          name: "Türk Hard Rock",
          description: "1980'lerde gelişen, daha sert, davul ve gitarların baskın olduğu bir alt tür."
        },
        {
          name: "Alternatif Rock",
          description: "1990'larda gelişen, daha modern bir sound'a sahip, grunge ve alternatif rock etkili bir alt türdür. Duman, Mor ve Ötesi gibi gruplar temsilcisidir."
        },
        {
          name: "Pop-Rock",
          description: "Rock ve pop unsurlarını birleştiren, daha yumuşak ve geniş kitlelere hitap eden bir alt tür."
        }
      ],
      instruments: ["Elektro Gitar", "Bas Gitar", "Davul", "Keyboard", "Akustik Gitar", "Bağlama", "Elektro Bağlama", "Perküsyon", "Synthesizer", "Elektro Saz"],
      notable_artists: ["Barış Manço", "Erkin Koray", "Cem Karaca", "Duman", "Mor ve Ötesi", "Teoman", "maNga", "Şebnem Ferah", "Hayko Cepkin", "Athena"],
      characteristics: "Elektro gitar odaklı sound, güçlü ritim seksiyonu, sert veya melankolik vokal tarzı, toplumsal, felsefi veya kişisel temalar, çoğunlukla band/grup formatında icra."
    },
    {
      genre: "Türkçe Rap/Hip-Hop",
      description: "Türkçe Rap, 1990'larda Türkiye'de gelişen, ritmik sözlerin bir beat üzerine söylendiği, hip-hop kültürünün bir parçası olan müzik türüdür.",
      subgenres: [
        {
          name: "Old School Türkçe Rap",
          description: "1990'lar ve 2000'lerin başında gelişen, daha basit prodüksiyonlar ve sözlere dayalı rap stili."
        },
        {
          name: "Gangsta Rap",
          description: "Sokak hayatı, çete kültürü, zorluklar gibi temaları işleyen, sert bir söylem içeren alt tür."
        },
        {
          name: "Underground Rap",
          description: "Ana akım medyadan uzak, bağımsız olarak üretilen, genellikle daha politik veya deneysel içerikli rap."
        },
        {
          name: "Trap",
          description: "2010'larda popülerleşen, keskin hi-hat'ler, derin bas, slower tempo beat'ler ve Auto-Tune kullanımıyla karakterize modern bir alt tür."
        },
        {
          name: "Pop-Rap",
          description: "Pop müzikle rap'i birleştiren, daha geniş kitlelere hitap eden, yumuşak melodiler içeren bir alt tür."
        }
      ],
      instruments: ["Drum Machine", "Sampler", "Synthesizer", "Turntable", "Beatbox", "Digital Audio Workstation (DAW)", "Elektro Gitar", "Bas", "Piyano", "Geleneksel Türk Enstrümanları (sample olarak)"],
      notable_artists: ["Cartel", "Ceza", "Sagopa Kajmer", "Fuat Ergin", "Şanışer", "Ezhel", "Ben Fero", "Norm Ender", "Pit10", "Khontkar"],
      characteristics: "Güçlü ritimler (beat), ritmik ve kafiyeli sözler, sosyal mesajlar veya kişisel deneyimler, sampling tekniği, flow (söz söyleme akışı) ve doğaçlama yeteneği önemli."
    },
    
    // Uluslararası Müzik Türleri
    {
      genre: "Klasik Batı Müziği",
      description: "Ortaçağ'dan günümüze Avrupa'da gelişen, notasyon sistemi kullanılarak yazılan, genellikle orkestra, oda müziği grupları veya solo enstrümanlar için bestelenmiş müzik geleneğidir.",
      subgenres: [
        {
          name: "Barok Müzik (1600-1750)",
          description: "Bach, Vivaldi, Handel gibi bestecilerle anılan, süslemeli melodik çizgiler, karmaşık kontrpuan ve sürekli bas kullanımı ile karakterize dönem."
        },
        {
          name: "Klasik Dönem (1750-1820)",
          description: "Mozart, Haydn, Beethoven (erken dönem) gibi bestecilerle anılan, denge, netlik, şeffaflık, simetri gibi özelliklere sahip dönem."
        },
        {
          name: "Romantik Dönem (1820-1900)",
          description: "Beethoven (geç dönem), Chopin, Tchaikovsky, Wagner gibi bestecilerle anılan, duygusal yoğunluk, bireysellik, milliyetçilik, doğa sevgisi gibi temaların öne çıktığı dönem."
        },
        {
          name: "Modern Klasik Müzik (1900-)",
          description: "Debussy, Stravinsky, Schoenberg, Bartók gibi bestecilerle başlayan, geleneksel tonaliteden uzaklaşan, yeni teknikler ve tınılar arayan dönem."
        },
        {
          name: "Çağdaş Klasik Müzik (1975-)",
          description: "Philip Glass, Steve Reich, Arvo Pärt gibi bestecilerin temsil ettiği, minimalizm, elektroniğin kullanımı, dünya müziği etkileşimleri gibi özelliklere sahip günümüz klasik müziği."
        }
      ],
      instruments: ["Keman", "Viyola", "Viyolonsel", "Kontrbas", "Flüt", "Obua", "Klarnet", "Fagot", "Trompet", "Trombon", "Korno", "Tuba", "Piyano", "Arp", "Org", "Çembalo", "Timpani", "Perküsyon"],
      notable_artists: ["Johann Sebastian Bach", "Wolfgang Amadeus Mozart", "Ludwig van Beethoven", "Richard Wagner", "Frédéric Chopin", "Pyotr Ilyich Tchaikovsky", "Claude Debussy", "Igor Stravinsky", "Sergei Rachmaninoff", "Gustav Mahler"],
      characteristics: "Formal yapılar (sonat, senfoni, konçerto, vs.), gelişmiş notasyon, geniş dinamik aralık, armonik derinlik, çoklu melodik çizgiler (polifoni)."
    },
    {
      genre: "Jazz",
      description: "20. yüzyılın başlarında ABD'de Afrika kökenli Amerikalılar tarafından geliştirilen, doğaçlama, swing ve blues elementleri içeren bir müzik türüdür.",
      subgenres: [
        {
          name: "Dixieland (Traditional Jazz)",
          description: "1910'larda New Orleans'ta ortaya çıkan, kolektif doğaçlama, poliritmik yapı, marş etkilerinin görüldüğü erken dönem jazz."
        },
        {
          name: "Swing",
          description: "1930-40'larda popülerleşen, dans müziği olarak yaygınlaşan, big band orkestrasyon ve düzenlemeleriyle öne çıkan alt tür."
        },
        {
          name: "Bebop",
          description: "1940'larda gelişen, daha hızlı tempo, karmaşık armoniler, virtüözite gerektiren bir alt tür. Charlie Parker, Dizzy Gillespie öncülük etmiştir."
        },
        {
          name: "Cool Jazz",
          description: "1950'lerde popülerleşen, daha sakin, düşük tonlu, kontrollü bir sound'a sahip alt tür. Miles Davis, Chet Baker temsilcileridir."
        },
        {
          name: "Hard Bop",
          description: "1950'lerde bebop'un blues ve gospel etkilerini içeren, daha sert ve ritmik versiyonu. Art Blakey, Horace Silver öne çıkar."
        },
        {
          name: "Modal Jazz",
          description: "1950'lerde gelişen, akor ilerlemelerinden ziyade modlar üzerine doğaçlamaya dayanan alt tür. Miles Davis'in 'Kind of Blue' albümü örnektir."
        },
        {
          name: "Free Jazz",
          description: "1960'larda ortaya çıkan, geleneksel yapılar ve kısıtlamalardan uzaklaşan, özgür doğaçlamaya dayalı deneysel bir alt tür."
        },
        {
          name: "Fusion",
          description: "1970'lerde gelişen, jazz'ı rock, funk ve elektronik müzikle birleştiren bir alt tür. Weather Report, Herbie Hancock temsilcileridir."
        }
      ],
      instruments: ["Saksofon", "Trompet", "Trombon", "Piyano", "Kontrbas", "Davul", "Gitar", "Vibrafon", "Klarnet", "Flüt", "Elektrik Bas", "Elektrik Piyano/Klavye", "Synthesizer"],
      notable_artists: ["Louis Armstrong", "Duke Ellington", "Charlie Parker", "Miles Davis", "John Coltrane", "Thelonious Monk", "Ella Fitzgerald", "Billie Holiday", "Herbie Hancock", "Wynton Marsalis"],
      characteristics: "Doğaçlama, swing ritmi, blue notlar, call-and-response (çağrı-cevap) yapısı, senkopasyon, özgün sound arayışı, virtüözite."
    },
    {
      genre: "Blues",
      description: "19. yüzyılın sonlarında ABD'nin güney eyaletlerinde, Afrika kökenli Amerikalılar tarafından geliştirilen, hüzün ve zorlukları ifade eden bir müzik türüdür.",
      subgenres: [
        {
          name: "Delta Blues",
          description: "Mississippi Delta bölgesinde gelişen, genellikle solo akustik gitar ve vokal ile icra edilen, ham ve yoğun duygusal bir alt tür."
        },
        {
          name: "Chicago Blues",
          description: "1940-50'lerde Chicago'da gelişen, elektro gitar, mızıka, bas ve davulun bir arada kullanıldığı, daha kentsel bir sound'a sahip alt tür."
        },
        {
          name: "Texas Blues",
          description: "T-Bone Walker, Stevie Ray Vaughan gibi gitaristlerce geliştirilen, swing etkili, virtüöz gitar tekniklerinin öne çıktığı bir alt tür."
        },
        {
          name: "Jump Blues",
          description: "1940'larda gelişen, swing ve boogie-woogie elementleri içeren, tempolu, dans edilebilir bir alt tür."
        },
        {
          name: "Electric Blues",
          description: "Elektrikli enstrümanların, özellikle elektro gitarın baskın olduğu, 1950'lerden itibaren yaygınlaşan modern blues."
        }
      ],
      instruments: ["Gitar (Akustik ve Elektro)", "Mızıka (Harmonika)", "Piyano", "Bas", "Davul", "Slide Guitar", "Saksofon", "Trompet", "Vokal"],
      notable_artists: ["Robert Johnson", "Muddy Waters", "B.B. King", "Howlin' Wolf", "John Lee Hooker", "Buddy Guy", "Stevie Ray Vaughan", "Etta James", "Albert King", "Eric Clapton"],
      characteristics: "12-bar blues yapısı, blue notlar, call-and-response (çağrı-cevap) yapısı, melankoli ve duygusal ifade, bend ve slide teknikleri, emprovizasyon."
    },
    {
      genre: "Rock",
      description: "1950'lerde rock and roll'dan gelişen, elektro gitar, bas ve davul üzerine kurulu, geniş bir müzik türüdür.",
      subgenres: [
        {
          name: "Rock and Roll",
          description: "1950'lerde ortaya çıkan, blues ve country etkili, dans edilebilir tempoda, erken dönem rock müziği. Elvis Presley, Chuck Berry temsilcileridir."
        },
        {
          name: "Classic Rock",
          description: "1960-70'lerde gelişen, gitarların baskın olduğu, blues kökenli, popüler rock stili. Led Zeppelin, The Rolling Stones örnek verilebilir."
        },
        {
          name: "Progressive Rock",
          description: "1970'lerde gelişen, klasik müzik etkileri taşıyan, karmaşık yapılar ve uzun parçalar içeren deneysel bir alt tür. Pink Floyd, Yes, Genesis temsilcileridir."
        },
        {
          name: "Punk Rock",
          description: "1970'lerde karşı kültür olarak ortaya çıkan, hızlı, sade, ham ve sert bir sound'a sahip, DIY (kendin yap) etiğini benimseyen alt tür."
        },
        {
          name: "Heavy Metal",
          description: "1970'lerde gelişen, distorsiyonlu gitarlar, güçlü davul, yoğun bas ve vokaller içeren, sert bir alt tür. Black Sabbath, Iron Maiden temsilcileridir."
        },
        {
          name: "Alternative Rock",
          description: "1980'lerde ana akım rocktan farklılaşan, çeşitli etkileri içeren, daha deneysel bir alt tür. R.E.M., Pixies, Nirvana gibi gruplar temsilcisidir."
        },
        {
          name: "Grunge",
          description: "1990'larda Seattle'da ortaya çıkan, distorsiyonlu gitar, karamsar temalar ve alternatif rock-punk-metal karışımı sound'a sahip alt tür."
        },
        {
          name: "Indie Rock",
          description: "Bağımsız (independent) plak şirketleriyle ilişkilendirilen, ana akımdan farklı, özgün sound arayışında olan geniş bir alt tür kategorisi."
        }
      ],
      instruments: ["Elektro Gitar", "Bas Gitar", "Davul", "Vokal", "Klavye/Synthesizer", "Akustik Gitar", "Elektro-Akustik Gitar", "Hammond Org", "Perküsyon"],
      notable_artists: ["The Beatles", "The Rolling Stones", "Led Zeppelin", "Pink Floyd", "Queen", "The Who", "David Bowie", "Nirvana", "Radiohead", "U2"],
      characteristics: "Elektro gitar odaklı sound, genellikle 4/4'lük ölçü, verse-chorus form yapısı, güçlü ritim seksiyonu, çeşitli alt türlerde farklı karakteristikler."
    },
    {
      genre: "Pop",
      description: "Popüler müzik olarak da bilinen, geniş kitlelere hitap etmek üzere üretilen, kolay erişilebilir ve hatırlanabilir yapıya sahip ticari müzik türüdür.",
      subgenres: [
        {
          name: "Bubblegum Pop",
          description: "1960-70'lerde popülerleşen, genç kitlelere yönelik, basit, neşeli ve kolay hatırlanır melodilerle karakterize alt tür."
        },
        {
          name: "Dance-Pop",
          description: "Dans müziği elementleri içeren, kulüplerde çalınmak üzere üretilen ritmik pop müziği."
        },
        {
          name: "Synth-Pop",
          description: "1980'lerde synthesizer'ların baskın olduğu, elektronik sound'a sahip pop müziği."
        },
        {
          name: "Teen Pop",
          description: "Ergen kitleye hitap eden, genellikle genç şarkıcıların icra ettiği, temiz ve erişilebilir pop müziği."
        },
        {
          name: "Indie Pop",
          description: "Bağımsız (independent) müzik geleneğinden gelen, ana akım poptan farklılaşan, daha özgün ve alternatif sound'a sahip pop müziği."
        },
        {
          name: "Art Pop",
          description: "Deneysel, sanatsal yaklaşım içeren, avangard elementler taşıyan pop müziği."
        },
        {
          name: "K-Pop",
          description: "Güney Kore'de gelişen, sofistike prodüksiyon, koreografi ve görsel estetikle öne çıkan global pop fenomeni."
        }
      ],
      instruments: ["Synthesizer", "Drum Machine", "Vokal", "Akustik/Elektro Gitar", "Piyano", "Bas", "Programlanmış Ritimler", "Dijital Audio Workstation (DAW)", "Yaylı Çalgılar", "Elektro Davul"],
      notable_artists: ["Madonna", "Michael Jackson", "Prince", "Whitney Houston", "Britney Spears", "Lady Gaga", "Justin Timberlake", "Beyoncé", "Taylor Swift", "Ariana Grande"],
      characteristics: "Kolay hatırlanabilir melodiler, nakaratlara vurgu, genellikle 3-4 dakikalık şarkı uzunluğu, profesyonel prodüksiyon, çekici vokaller, güncel konularla ilgili sözler."
    },
    {
      genre: "Elektronik Müzik",
      description: "Elektronik cihazlar ve bilgisayarlarla üretilen geniş bir müzik kategorisidir. 20. yüzyılın ortalarında deneysel olarak başlayıp günümüzde dans müziğinin büyük bir kısmını kapsar.",
      subgenres: [
        {
          name: "House",
          description: "1980'lerde Chicago'da doğan, 4/4'lük ritim, kick davul, hi-hat, snare, bas ve piyano/synthesi elementleriyle karakterize, 120-130 BPM hızında dans müziği."
        },
        {
          name: "Techno",
          description: "1980'lerde Detroit'te ortaya çıkan, mekanik ritimler, synthesizerlar ve futuristik sound'la karakterize, genellikle 130-150 BPM hızında sert dans müziği."
        },
        {
          name: "Trance",
          description: "1990'larda gelişen, hipnotik, armonili melodik gelişim, build-up ve drop yapısı içeren, genellikle 130-140 BPM hızında elektronik dans müziği."
        },
        {
          name: "Drum and Bass",
          description: "1990'larda İngiltere'de gelişen, hızlı breakbeat davul ritimleri (160-180 BPM) ve derin bas hattıyla karakterize alt tür."
        },
        {
          name: "Dubstep",
          description: "2000'lerde İngiltere'de gelişen, yarım tempolu ritimler, yoğun bas ve 'wobble' bas efektiyle karakterize, yaklaşık 140 BPM hızında alt tür."
        },
        {
          name: "Ambient",
          description: "Atmosferik, genellikle ritimsiz veya minimal ritimli, dinlendirici ve ortam sesi olarak tasarlanmış elektronik müzik türü."
        },
        {
          name: "EDM (Electronic Dance Music)",
          description: "2010'larda popülerleşen, ticari dans kulüpleri ve festivalleri için üretilen, güçlü drop'lar ve enerjik ritimlerle karakterize geniş bir elektronik müzik kategorisi."
        }
      ],
      instruments: ["Synthesizer", "Drum Machine", "Sampler", "Sequencer", "Digital Audio Workstation (DAW)", "MIDI Controller", "Vocoder", "Arpeggiator", "Laptop", "DJ Equipment (Turntables, Mixer)"],
      notable_artists: ["Kraftwerk", "Daft Punk", "Aphex Twin", "The Chemical Brothers", "Deadmau5", "Tiësto", "Skrillex", "Avicii", "Calvin Harris", "Brian Eno"],
      characteristics: "Elektronik olarak üretilmiş sesler, programlanmış ritimler, loop'lar (döngüler), remixler, sampling, DJ kültürü, dans odaklı yapı (birçok alt türde)."
    },
    {
      genre: "Hip-Hop",
      description: "1970'lerde New York'un Bronx bölgesinde gelişen, sample'lar, beat'ler üzerine ritmik konuşma (rap) içeren, geniş bir kültürel harekete dönüşen müzik türüdür.",
      subgenres: [
        {
          name: "Old School Hip-Hop",
          description: "1970'lerde ve 80'lerin başında gelişen, break-beat'ler, basit elektronik sound'lar ve eğlence odaklı rap içeren erken dönem hip-hop."
        },
        {
          name: "Golden Age Hip-Hop",
          description: "1980'lerin sonu ve 90'ların başında gelişen, zengin prodüksiyon, çeşitli sample'lar ve lirik derinlik içeren klasik dönem."
        },
        {
          name: "Gangsta Rap",
          description: "1980'lerin sonunda gelişen, sokak hayatı, çete kültürü ve sosyal gerçekliği işleyen, sert bir alt tür."
        },
        {
          name: "Alternative Hip-Hop",
          description: "Ana akım hip-hop'tan farklılaşan, deneysel prodüksiyon ve sıra dışı lirikler içeren alt tür."
        },
        {
          name: "Trap",
          description: "2000'lerde Güney ABD'de gelişen, hi-hat trilleri, 808 bas davul, karanlık melodi ve uyuşturucu/sokak hayatı temalı sözlerle karakterize modern alt tür."
        },
        {
          name: "Mumble Rap",
          description: "2010'larda gelişen, anlaşılması zor, mırıldanarak söylenen vokal stili, basit, tekrarlayan lirikleri olan alt tür."
        },
        {
          name: "Conscious Hip-Hop",
          description: "Sosyal ve politik konuları, toplumsal sorunları ele alan, mesaj odaklı hip-hop alt türü."
        }
      ],
      instruments: ["Turntables", "Sampler", "Drum Machine", "Digital Audio Workstation (DAW)", "MPC", "Synthesizer", "Beatbox (insan sesiyle)", "Bazen canlı enstrümanlar (bas, gitar, davul vb.)"],
      notable_artists: ["Grandmaster Flash", "Run-DMC", "Public Enemy", "Tupac Shakur", "The Notorious B.I.G.", "Jay-Z", "Nas", "Eminem", "Kendrick Lamar", "Drake"],
      characteristics: "Beat'ler (genellikle sample-based), ritmik söz söyleme (flow), kafiye yapıları, freestyle yeteneği, DJ teknikleri, bağlam ve hikaye anlatımı, sokak kültürü etkisi."
    },
    {
      genre: "R&B (Rhythm and Blues)",
      description: "1940'larda Afrika kökenli Amerikalılar arasında gelişen, blues, jazz ve gospel kökenli, ritmik ve duygusal vokal performanslarıyla öne çıkan bir müzik türüdür.",
      subgenres: [
        {
          name: "Classic R&B",
          description: "1940-50'lerde gelişen, blues ve jazz etkili, big band yapısı içeren erken dönem R&B."
        },
        {
          name: "Soul",
          description: "1950-60'larda gelişen, gospel kökenli vokaller, güçlü duygusal ifade ve ritmik yapıyla karakterize alt tür."
        },
        {
          name: "Funk",
          description: "1960'ların sonunda gelişen, güçlü bas hattı, sincopated ritimler ve groove odaklı dans müziği."
        },
        {
          name: "Contemporary R&B",
          description: "1980'lerden günümüze gelişen, modern prodüksiyon teknikleri, hip-hop etkileri ve sofistike vokal performanslarla karakterize modern R&B."
        },
        {
          name: "Neo-Soul",
          description: "1990'larda gelişen, klasik soul elementlerini modern R&B ile birleştiren, organik sound'a sahip alt tür."
        },
        {
          name: "Alternative R&B",
          description: "2010'larda popülerleşen, elektronik, indie ve deneysel etkileri içeren, geleneksel yapılardan uzaklaşan modern R&B."
        }
      ],
      instruments: ["Vokal", "Piyano", "Organ", "Elektro Gitar", "Bas Gitar", "Davul", "Trompet", "Saksofon", "Synthesizer", "Drum Machine", "Sampling"],
      notable_artists: ["Ray Charles", "James Brown", "Aretha Franklin", "Stevie Wonder", "Marvin Gaye", "Whitney Houston", "Michael Jackson", "Prince", "Beyoncé", "Frank Ocean"],
      characteristics: "Güçlü ve duygusal vokal performanslar, groove ve ritim odaklı yapı, soul etkisi, melismatik vokal teknikleri, genellikle aşk ve ilişki temaları."
    },
    {
      genre: "Reggae",
      description: "1960'ların sonunda Jamaika'da gelişen, karakteristik off-beat ritmi, bas-ağırlıklı sound'u ve genellikle Rastafaryan inancı, sosyal adalet temaları içeren müzik türüdür.",
      subgenres: [
        {
          name: "Roots Reggae",
          description: "Geleneksel reggae, Rastafaryan spiritüel temaları, Afrika diasporası ve sosyal mesajlar içerir."
        },
        {
          name: "Dub",
          description: "Reggae parçalarının remiksi olarak başlayan, vokalleri azaltıp enstrümantal kısımları, özellikle bas ve davulu öne çıkaran, eko ve reverb efektleri kullanan alt tür."
        },
        {
          name: "Dancehall",
          description: "1980'lerde gelişen, daha hızlı tempolu, elektronik ve dijital prodüksiyon, DJ vokallerini içeren, dans odaklı bir alt tür."
        },
        {
          name: "Reggae Fusion",
          description: "Reggae'yi hip-hop, R&B, pop, rock gibi diğer müzik türleriyle birleştiren modern füzyon."
        }
      ],
      instruments: ["Bas Gitar", "Davul", "Elektro Gitar", "Keyboard/Organ", "Perküsyon (özellikle Nyabinghi davulları)", "Brass Seksiyonu (Trompet, Trombon)", "Melodika"],
      notable_artists: ["Bob Marley & The Wailers", "Peter Tosh", "Jimmy Cliff", "Burning Spear", "Black Uhuru", "Steel Pulse", "Toots and the Maytals", "Gregory Isaacs", "Damian Marley", "Sean Paul"],
      characteristics: "Belirgin off-beat vurguları (skank), derin bas hattı, yavaş ile orta arası tempo, politik ve spiritüel temalar, Jamaika patois dili kullanımı, Rastafaryan etki."
    },
    {
      genre: "World Music",
      description: "Batı popüler müziği dışında kalan, dünyanın çeşitli bölgelerine ait geleneksel ve modern müzik türlerini kapsayan geniş bir kategoridir.",
      subgenres: [
        {
          name: "Afrobeat",
          description: "Nijeryalı müzisyen Fela Kuti tarafından geliştirilen, Yorùbá müziği, jazz, highlife ve funk elementlerini birleştiren, politik mesajlar içeren Afrika müziği."
        },
        {
          name: "Bossa Nova",
          description: "1950'lerde Brezilya'da gelişen, samba ve jazz karışımı, yumuşak bir ritme sahip sofistike müzik türü."
        },
        {
          name: "Flamenco",
          description: "İspanya'nın Endülüs bölgesinden gelen, gitarların, vokallerin, el çırpma (palmas) ve dans unsurlarının öne çıktığı tutkulu müzik türü."
        },
        {
          name: "Raga",
          description: "Hint klasik müziğinin melodik çerçevesi, belirli kurallara göre doğaçlama yapılan, zengin melismatik yapıya sahip müzikal gelenek."
        },
        {
          name: "Celtic Music",
          description: "İrlanda, İskoçya, Galler ve Brötanya gibi Kelt kültürüne sahip bölgelerin geleneksel müziği."
        },
        {
          name: "Mariachi",
          description: "Meksika'ya özgü, viyolin, trompet, vihuela, guitarrón ve vokal içeren geleneksel müzik türü."
        }
      ],
      instruments: ["Her kültüre özgü geleneksel enstrümanlar", "Geleneksel vurmalı çalgılar", "Yerel yaylı çalgılar", "Yerel üflemeli çalgılar", "Dünya çapında özgün enstrümanlar"],
      notable_artists: ["Miriam Makeba", "Fela Kuti", "Youssou N'Dour", "Ravi Shankar", "Ali Farka Touré", "Cesária Évora", "The Chieftains", "Caetano Veloso", "Gilberto Gil", "Manu Chao"],
      characteristics: "Her bölgeye ve kültüre özgü karakteristikler, yerel dil kullanımı, geleneksel enstrümanlar, kültürel kimliği yansıtan temalar, bazen geleneksel ile modern unsurların birleşimi."
    }
  ],
  
  // =====================================================================
  // TÜRK MÜZİĞİNDE ÖNDE GELEN SANATÇILAR VE ESERLERİ
  // =====================================================================
  
  turkishArtists: [
    {
      name: "Neşet Ertaş",
      genre: "Türk Halk Müziği",
      period: "1943-2012",
      region: "Orta Anadolu (Kırşehir)",
      bio: "Kırşehirli ünlü halk ozanı ve bağlama ustası Muharrem Ertaş'ın oğlu olan Neşet Ertaş, Orta Anadolu türkülerinin önemli temsilcisi ve Abdal geleneğinin büyük ustasıdır. 'Bozkırın Tezenesi' olarak anılır. Kendi yaşam deneyimlerinden yola çıkarak aşk, gurbet, doğa ve insan ilişkilerini türkülerinde işlemiştir. Bağlama çalma tekniği ve kendine özgü yorumuyla Türk halk müziğine büyük katkıda bulunmuştur.",
      significance: "Abdal müzik geleneğinin en önemli temsilcilerinden biri olarak kabul edilir. Bozlak türündeki eserleri ve kendine özgü bağlama çalma tekniğiyle Türk halk müziğine büyük katkılar sunmuştur. UNESCO tarafından 'Yaşayan İnsan Hazinesi' unvanına layık görülmüştür.",
      notable_works: [
        {
          title: "Neredesin Sen",
          year: "1970'ler",
          lyrics_excerpt: "Neredesin sen, neredesin sen / Gönül dağında, gönül bağında / Beni bıraktın yaban ellerde / Neredesin sen, neredesin sen",
          description: "Aşk ve hasret temalarının işlendiği, Neşet Ertaş'ın en bilinen eserlerinden biridir."
        },
        {
          title: "Zahidem",
          year: "1970'ler",
          lyrics_excerpt: "Zahidem kurban olam kaşlarına gözüne / Cehizin benim olsun gel gir koynuma / Zahidem asker oldum gideceğim tezinen / Kara gözlüm mektubun gönder bazinen",
          description: "Kırşehir yöresinden derlenen, aşk ve ayrılık temalı ünlü bir türküdür."
        },
        {
          title: "Gönül Dağı",
          year: "1980'ler",
          lyrics_excerpt: "Gönül dağı yağmur yağmur boran oldu / Ayrılıktır gönülleri viran oldu / Coşkun akan deli gönül ummana döndü / Ne sen beni unuttun ne ben seni",
          description: "Ayrılık acısını doğa benzetmeleriyle anlatan, duygusal bir eserdir."
        },
        {
          title: "Yazımı Kışa Çevirdin",
          year: "1970'ler",
          lyrics_excerpt: "Yazımı kışa çevirdin / Beni dağlara çevirdin / Sen benim neyim olursun / Beni sevdaya çevirdin",
          description: "Aşkın insanda yarattığı duygusal dönüşümü anlatan güçlü bir türküdür."
        },
        {
          title: "Mühür Gözlüm",
          year: "1970'ler",
          lyrics_excerpt: "Mühür gözlüm seni elden / Sakınırım kıskanırım / Sen benim canımdan içeri / Canısın kıskanırım",
          description: "Sevgiliye duyulan derin sevgi ve kıskançlığı anlatan, lirik bir türküdür."
        }
      ],
      influence: "Neşet Ertaş, yalnızca müziği ile değil, hümanist dünya görüşü ve tevazusuyla da birçok sanatçıyı etkilemiştir. Günümüz Türk halk müziği icracıları ve modern müzisyenler tarafından ilham kaynağı olarak görülmektedir. Onun tarzı, özellikle bağlama çalma tekniği, birçok müzisyen tarafından benimsenmiş ve devam ettirilmektedir."
    },
    {
      name: "Aşık Veysel",
      genre: "Türk Halk Müziği",
      period: "1894-1973",
      region: "İç Anadolu (Sivas)",
      bio: "Sivas'ın Şarkışla ilçesine bağlı Sivrialan köyünde dünyaya gelen Aşık Veysel Şatıroğlu, yedi yaşında çiçek hastalığı nedeniyle görme yetisini kaybetmiştir. Babasının hediye ettiği bağlama ile müziğe başlamış, geleneksel âşıklık geleneği içinde yetişmiştir. Sade, derin ve felsefi yaklaşımı ile Cumhuriyet dönemi Türk halk şiirinin en önemli temsilcilerinden biri olmuştur.",
      significance: "Anadolu âşıklık geleneğinin son büyük temsilcilerinden biri olarak kabul edilir. Köy Enstitüleri'nde halk sazı öğretmenliği yapmış, geleneksel Türk halk müziğinin ve âşıklık geleneğinin genç kuşaklara aktarılmasında önemli rol oynamıştır. Şiirleri, türküleri ve felsefesiyle Türk kültür tarihinin önemli figürlerinden biridir.",
      notable_works: [
        {
          title: "Uzun İnce Bir Yoldayım",
          year: "1950'ler",
          lyrics_excerpt: "Uzun ince bir yoldayım / Gidiyorum gündüz gece / Bilmiyorum ne haldeyim / Gidiyorum gündüz gece",
          description: "Hayat yolculuğunu metaforik bir dille anlatan, Aşık Veysel'in en ünlü eserlerinden biridir."
        },
        {
          title: "Kara Toprak",
          year: "1940'lar",
          lyrics_excerpt: "Dost dost diye nicesine sarıldım / Benim sadık yârim kara topraktır / Beyhude dolandım boşa yoruldum / Benim sadık yârim kara topraktır",
          description: "İnsanın toprakla olan ilişkisini, vefasız insanlarla karşılaştırarak anlatan felsefi bir eserdir."
        },
        {
          title: "Güzelliğin On Para Etmez",
          year: "1960'lar",
          lyrics_excerpt: "Güzelliğin on para etmez / Bu bendeki aşk olmasa / Eğer benim şu gönlümde / İlişecek göz olmasa",
          description: "Aşkın ve manevi güzelliğin, fiziksel güzellikten üstün olduğunu vurgulayan derin bir eserdir."
        },
        {
          title: "Benim Sadık Yârim Kara Topraktır",
          year: "1950'ler",
          lyrics_excerpt: "Koyun verdi, kuzu verdi, süt verdi / Yemek verdi, ekmek verdi, et verdi / Kazma ile döğmeyince kıt verdi / Benim sadık yârim kara topraktır",
          description: "Toprağa olan sevgisini ve bağlılığını anlatan, çiftçi felsefesini yansıtan güçlü bir eserdir."
        },
        {
          title: "Dostlar Beni Hatırlasın",
          year: "1960'lar",
          lyrics_excerpt: "Ben giderim adım kalır / Dostlar beni hatırlasın / Düğün olur kızlar gelin / Dostlar beni hatırlasın",
          description: "Ölümden sonra bile hatırlanma arzusunu dile getiren, yaşamın geçiciliğini vurgulayan bir eserdir."
        }
      ],
      influence: "Aşık Veysel, yalnızca geleneksel halk müziği üzerinde değil, modern Türk müziği üzerinde de büyük etki bırakmıştır. Onun eserleri, Anadolu rock müziğinin öncüleri tarafından yeniden yorumlanmış, birçok şair ve yazara ilham kaynağı olmuştur. Hümanist felsefesi ve yaşama bakışı, birçok sanatçı tarafından benimsenmiştir."
    },
    {
      name: "Zeki Müren",
      genre: "Türk Sanat Müziği",
      period: "1931-1996",
      region: "Ege (Bursa)",
      bio: "Bursa'da doğan Zeki Müren, Türk sanat müziğinin en önemli seslerinden biri olarak kabul edilir. İstanbul Güzel Sanatlar Akademisi'nde eğitim görmüş, hem müzik hem de görsel sanatlar alanında yetenekli bir sanatçıdır. Güçlü sesi, kusursuz diksiyonu ve sahne şovlarıyla 'Sanat Güneşi' olarak anılmıştır. Şarkıcılığının yanı sıra besteci, söz yazarı, film yıldızı ve tiyatro oyuncusu olarak da tanınmıştır.",
      significance: "Türk sanat müziğinin modernleşmesi ve popülerleşmesinde büyük rol oynamıştır. Klasik icra tekniklerini korurken sahne performanslarına getirdiği yeniliklerle geniş kitlelere ulaşmıştır. 600'den fazla şarkı kaydetmiş, birçok film ve sahne gösterisinde yer almıştır. Türk sanat müziğini yurt dışında da tanıtmış, birçok uluslararası konserde yer almıştır.",
      notable_works: [
        {
          title: "Bir Demet Yasemen",
          year: "1951",
          lyrics_excerpt: "Bir demet yasemen / Sarmış gerdanını / Razıyım ben çekmeye / Aşkın fermanını",
          description: "Zeki Müren'in ilk plak kaydı olan bu eser, onun müzik kariyerinin başlangıcını temsil eder."
        },
        {
          title: "Şimdi Uzaklardasın",
          year: "1960'lar",
          lyrics_excerpt: "Şimdi uzaklardasın / Gönül hicranla doldu / Unuttun demiyorum / Hatırlamak ne oldu",
          description: "Ayrılık acısını zarif bir dille anlatan, duygusal bir eserdir."
        },
        {
          title: "Elbet Bir Gün Buluşacağız",
          year: "1970'ler",
          lyrics_excerpt: "Elbet bir gün buluşacağız / O başka bahara kaldı / Senden ayrı yaşamaktansa / İnan yaşamamak yeğdir",
          description: "Kavuşma umudunu ve ayrılık acısını dramatik bir şekilde anlatan bir eserdir."
        },
        {
          title: "Gözlerinin İçine Başka Hayal Girmesine",
          year: "1980'ler",
          lyrics_excerpt: "Gözlerinin içine başka hayal girmesine / Engel olamazsın gönül kuşum sana kanarsa / Bir rüya bir masal dünyası yarattım / Hepsi yok olur bir küçük aşk rüzgarıyla",
          description: "Aşkın kırılganlığını ve gözlerin ifadesini anlatan, lirik bir eserdir."
        },
        {
          title: "Benim Hayatım",
          year: "1970'ler",
          lyrics_excerpt: "Benim hayatım bir hiçim / Başlar içimde isyan / Azap ve üzüntü içinde / Ömrüm geçiyor inan",
          description: "Kişisel yaşam mücadelesini ve iç dünyasını yansıtan, duygusal bir eserdir."
        }
      ],
      influence: "Zeki Müren, Türk sanat müziğini geniş kitlelere sevdirmiş, klasik repertuvar ile modern yaklaşımı birleştirmiştir. Sahne kostümleri ve performans tarzı ile Türk sahne sanatlarına yenilikler getirmiştir. Birçok genç sanatçıya ilham kaynağı olmuş, Türk sanat müziğinin gelişiminde önemli bir mihenk taşı olmuştur."
    },
    {
      name: "Orhan Gencebay",
      genre: "Arabesk / Türk Sanat Müziği Füzyonu",
      period: "1944-Günümüz",
      region: "Karadeniz (Samsun)",
      bio: "Samsun'da doğan Orhan Gencebay, küçük yaşta müziğe ilgi duymuş, bağlama, ud ve kanun gibi enstrümanları ustaca çalmayı öğrenmiştir. TRT'de çalıştığı dönemde klasik Türk müziği eğitimi almış, ancak daha sonra kendi müzikal tarzını geliştirerek 'arabesk' olarak anılacak türün öncüsü olmuştur. Hem besteci hem yorumcu olarak Türk müziğine büyük katkılar sunmuştur.",
      significance: "Arabesk müziğin kurucusu ve en önemli temsilcisi olarak kabul edilir. Geleneksel Türk müziği ile Batı müziği tekniklerini birleştirerek özgün bir tarz yaratmıştır. 1000'den fazla beste yapmış, 30'dan fazla albüm çıkarmıştır. Müziğinde felsefi derinliği ve toplumsal mesajları öne çıkarmıştır.",
      notable_works: [
        {
          title: "Bir Teselli Ver",
          year: "1972",
          lyrics_excerpt: "Bir teselli ver, yaşamak için / Bir teselli ver, yaşamak için / Ölmeden mezara koydun sen beni / Bir teselli ver, yaşamak için",
          description: "Aşk acısını ve teselli arayışını anlatan, Orhan Gencebay'ın en bilinen eserlerinden biridir."
        },
        {
          title: "Batsın Bu Dünya",
          year: "1975",
          lyrics_excerpt: "Batsın bu dünya, bitsin bu rüya / Ne Sen, ne de ben / Ne sevgi kalsa, ne de bir vefa / Batsın bu dünya, bitsin bu rüya",
          description: "Toplumsal eleştiri ve hayal kırıklığını yansıtan, güçlü bir eserdir."
        },
        {
          title: "Hatasız Kul Olmaz",
          year: "1970'ler",
          lyrics_excerpt: "Hatasız kul olmaz, hatasız kul olmaz / Dert gelmez mi sandın ömür boyunca / Hatasız kul olmaz, hatasız kul olmaz / Dert gelmez mi sandın ömür boyunca",
          description: "İnsanın kusurluluğunu ve hayatın zorluklarını felsefi bir yaklaşımla anlatan bir eserdir."
        },
        {
          title: "Dil Yarası",
          year: "1980'ler",
          lyrics_excerpt: "Dil yarası, dil yarası / Her yaradan çok acıtır / Nice zehirli okların / Yarasını saran gönül",
          description: "Sözlerin verdiği acıyı ve kırılan kalpleri anlatan, duygusal bir eserdir."
        },
        {
          title: "Müzisyen",
          year: "1990'lar",
          lyrics_excerpt: "Müzisyen, müzisyen / Sen nasıl sevdalı bir insansın / Müzisyen, müzisyen / Sen nasıl sevdalı bir insansın",
          description: "Müzisyenlerin duygusal dünyasını ve müziğe olan tutkusunu anlatan bir eserdir."
        }
      ],
      influence: "Orhan Gencebay, arabesk adı verilen müzik türünü sanatsal bir seviyeye taşımış, bu türün bir alt kültür olmaktan çıkıp müzikal bir akım haline gelmesini sağlamıştır. Birçok besteci ve yorumcuya ilham kaynağı olmuş, Türk müziğinde sentez yaklaşımının öncülerinden biri olmuştur."
    },
    {
      name: "Barış Manço",
      genre: "Anadolu Rock / Türk Halk Müziği Füzyonu",
      period: "1943-1999",
      region: "Marmara (İstanbul)",
      bio: "İstanbul'da doğan Barış Manço, Galatasaray Lisesi ve Belçika Kraliyet Güzel Sanatlar Akademisi'nde eğitim görmüştür. 1960'larda müzik kariyerine başlamış, Türk halk müziği ile rock müziği sentezleyen Anadolu Rock akımının öncülerinden olmuştur. Müzisyenliğinin yanı sıra TV programcısı, gezgin ve kültür elçisi kimlikleriyle de tanınmıştır. 'Adam Olacak Çocuk' ve '7'den 77'ye' gibi eğitici TV programlarıyla nesiller üzerinde etki bırakmıştır.",
      significance: "Türk rock müziğinin ve Anadolu Rock akımının en önemli temsilcilerinden biridir. Geleneksel Türk halk müziği motiflerini modern rock sound'u ile birleştirmiş, özgün bir müzik tarzı yaratmıştır. 200'den fazla beste yapmış, dünya çapında konserler vermiştir. Çocuklar için hazırladığı TV programları ve müzikleriyle kültürel değerlerin aktarılmasında önemli rol oynamıştır.",
      notable_works: [
        {
          title: "Dağlar Dağlar",
          year: "1970",
          lyrics_excerpt: "Dağlar dağlar, kurban olam yol ver geçem / Sevdiğimi son bir olsun yakından görem / Yar yar, yar yar, yar yar sevdalım / Yar yar, yar yar, nazlı yar vay aman",
          description: "Geleneksel bir Türk halk türküsünün rock aranjmanı olarak yeniden yorumlanmış halidir."
        },
        {
          title: "Gülpembe",
          year: "1981",
          lyrics_excerpt: "Allah'ım, bu ne güzel kader / Sevgili Gülpembe / Seni görünce titrer yüreğim / Elini tutunca ölürüm, Gülpembe",
          description: "Kızına ithafen yazdığı, baba sevgisini anlatan duygusal bir eserdir."
        },
        {
          title: "Domates Biber Patlıcan",
          year: "1981",
          lyrics_excerpt: "Domates, biber, patlıcan / Domates, biber, patlıcan / Haydi eller havaya / Eller şakşaka",
          description: "Tüketim kültürüne mizahi bir eleştiri getiren, çocuklar tarafından da çok sevilen eğlenceli bir eserdir."
        },
        {
          title: "Sarı Çizmeli Mehmet Ağa",
          year: "1976",
          lyrics_excerpt: "Sarı çizmeli Mehmet Ağa / Bir gün bakıp çeşmeden sulara / Bir gün batıdan bir yıldız kaydı / Duydun mu hey sarı çizmeli Mehmet Ağa",
          description: "Toplumsal değişimi ve modernleşme sürecini alegorik bir dille anlatan felsefi bir eserdir."
        },
        {
          title: "Hal Hal",
          year: "1981",
          lyrics_excerpt: "Hal hal, hal hal, hal hal / Yürü yavrum yürü, aslan yavrum yürü / Yağmur olsan yağsan, sel olup aksan / Vız gelir bana, vız gelir vız",
          description: "Hayatın zorlukları karşısında dik durma ve mücadele etme mesajını veren bir eserdir."
        }
      ],
      influence: "Barış Manço, yalnızca müziğiyle değil, kültür elçisi kimliğiyle de Türk kültürünü dünyaya tanıtmış, 'çocukların ve gençlerin Barış Ağabeyi' olarak nesiller üzerinde etki bırakmıştır. Anadolu Rock tarzının gelişiminde ve Türk rock müziğinin dünyaya açılmasında öncü rol oynamıştır."
    },
    {
      name: "Sezen Aksu",
      genre: "Türk Pop Müziği",
      period: "1954-Günümüz",
      region: "Ege (İzmir)",
      bio: "İzmir'de doğan Sezen Aksu, Türk pop müziğinin 'Minik Serçe'si olarak anılır. 1970'lerde müzik kariyerine başlamış, hem yorumcu hem de besteci olarak Türk müziğine damgasını vurmuştur. Şarkılarındaki duygusal derinlik, yaşamdan kesitler sunan sözleri ve kendine özgü vokal tarzıyla tanınır. Birçok genç sanatçının keşfedilmesinde ve yetiştirilmesinde önemli rol oynamıştır.",
      significance: "Modern Türk pop müziğinin kurucusu ve en etkili figürlerinden biri olarak kabul edilir. 40'tan fazla albüm çıkarmış, 500'den fazla şarkı bestelemiştir. Müziğinde geleneksel Türk müziği motifleri ile modern pop unsurlarını ustaca harmanlamıştır. Toplumsal konulara duyarlılığı ve cesur duruşuyla birçok sosyal meseleye dikkat çekmiştir.",
      notable_works: [
        {
          title: "Firuze",
          year: "1982",
          lyrics_excerpt: "Firuzeyi beline takmış gelin / Kimseler dokunmasın nazlı kıza / Rüzgarda savrulan telli duvaklı / Kimseler dokunmasın nazlı kıza",
          description: "Geleneksel motifleri modern bir yaklaşımla sunan, Sezen Aksu'nun ilk büyük hit parçalarından biridir."
        },
        {
          title: "Gülümse",
          year: "1991",
          lyrics_excerpt: "Gülümse, hadi gülümse / Bak yeni bir gün doğuyor yine / Gülümse, hadi gülümse / Bu gözyaşları son olsun ne olur gülümse",
          description: "Umut ve pozitif düşünce mesajı veren, motivasyonel bir eserdir."
        },
        {
          title: "İkinci Bahar",
          year: "1993",
          lyrics_excerpt: "Yıllar yılı aşk yolunu gözlerken / Tutulmuşum bir zalime bilmeden / Şimdilerde kalbim yine çarpıyor / Yeni bir aşk doğuyor içimde",
          description: "Aşkta yeni başlangıçları ve olgunlaşmayı anlatan, duygusal bir eserdir."
        },
        {
          title: "Beni Unutma",
          year: "1998",
          lyrics_excerpt: "Anısı içimizde en derin, en sıcak / Anısı içimizde en gerçek, en uzak / Bölüştük kaderi seninle / Ne bir eksik ne de bir fazla",
          description: "Hatırlanma arzusunu ve geçmiş aşkların izlerini anlatan, lirik bir eserdir."
        },
        {
          title: "Kutlama",
          year: "2008",
          lyrics_excerpt: "Kutlama, kutlama / Hayat bayram olsa / İnsanlar hep bir olsa / Uzansak sonsuza / Kutlama, kutlama",
          description: "Yaşamın her anını kutlama ve birlik olma mesajı veren, pozitif bir eserdir."
        }
      ],
      influence: "Sezen Aksu, Türk pop müziğinin gelişiminde ve uluslararası alanda tanınmasında büyük rol oynamıştır. Tarkan, Levent Yüksel, Aşkın Nur Yengi, Sertab Erener gibi birçok sanatçının kariyerinde mentor olmuş, Türk müziğinde kadının rolünü güçlendirmiştir. Müziği ve duruşuyla toplumsal değişimlere de öncülük etmiştir."
    },
    {
      name: "Müslüm Gürses",
      genre: "Arabesk",
      period: "1953-2013",
      region: "Güneydoğu Anadolu (Şanlıurfa)",
      bio: "Şanlıurfa'da doğan Müslüm Gürses (asıl adı Müslüm Akbaş), zorlu bir çocukluk geçirmiş, genç yaşta müzik dünyasına adım atmıştır. Kendine özgü yorumu, derin ve dokunaklı sesi ile 'Müslüm Baba' olarak anılır. Acılı yaşamı ve hayranlarıyla kurduğu duygusal bağ ile efsaneleşmiştir. Kariyeri boyunca 300'den fazla albüm çıkarmış, arabesk müziğin en önemli temsilcilerinden biri olmuştur.",
      significance: "Arabesk müziğin en önemli ve sevilen yorumcularından biridir. Müziğinde hüzün, acı ve yaşam mücadelesi temalarını işlemiş, milyonlarca insanın duygularına tercüman olmuştur. Klasik arabeskin yanı sıra farklı tarzlarda da eserler seslendirmiş, özellikle son döneminde rock, pop ve caz yorumlarıyla dikkat çekmiştir.",
      notable_works: [
        {
          title: "Nilüfer",
          year: "1980'ler",
          lyrics_excerpt: "Nilüfer, ciğerparem / Hastayım, hastayım / Nilüfer, ömrüm, hayatım / Yalnızım, yalnızım",
          description: "Aşk acısını ve ayrılık sonrası yaşanan yalnızlığı anlatan, Müslüm Gürses'in ikonik eserlerinden biridir."
        },
        {
          title: "Sevda Yüklü Kervanlar",
          year: "1970'ler",
          lyrics_excerpt: "Sevda yüklü kervanlar / Çöllerde kayboldu / Sensiz kaldım sevgilim / Dünyam zindan oldu",
          description: "Sevgiliye duyulan özlemi ve ayrılık acısını kervan metaforuyla anlatan bir eserdir."
        },
        {
          title: "Affet",
          year: "1980'ler",
          lyrics_excerpt: "Affet, ne olur affet / Sana karşı suçumu / Eksik etme yüzünden / O sevgi dolu gülüşünü",
          description: "Pişmanlık ve af dileme temalarını işleyen, duygusal bir eserdir."
        },
        {
          title: "Mutlu Ol Yeter",
          year: "1990'lar",
          lyrics_excerpt: "Mutlu ol, mutlu ol, mutlu ol yeter / Kaderimde senin aşkın var ise / Gelirsin bir gün ellerin elimde / Mutlu ol, mutlu ol, mutlu ol yeter",
          description: "Fedakâr aşkı ve sevgilinin mutluluğunu kendi mutluluğundan üstün tutmayı anlatan bir eserdir."
        },
        {
          title: "Bir Bilebilsen",
          year: "2000'ler",
          lyrics_excerpt: "Bir bilebilsen / Sensiz nasıl yaşadığımı / Bir bilebilsen / Nasıl özlediğimi her şeyini",
          description: "Modern bir aranjmanla sunulan, ayrılık sonrası yaşanan özlemi anlatan bir eserdir."
        }
      ],
      influence: "Müslüm Gürses, yalnızca arabesk müziğin değil, Türk popüler kültürünün de önemli bir figürü haline gelmiştir. Hayranlarıyla kurduğu bağ ve 'Müslümcüler' fenomeni, sosyolojik açıdan inceleme konusu olmuştur. Son döneminde farklı kuşaklardan ve sosyal gruplardan dinleyicilere ulaşmış, arabesk müziğin toplumsal algısının değişmesinde rol oynamıştır."
    },
    {
      name: "Tarkan",
      genre: "Türk Pop Müziği",
      period: "1972-Günümüz",
      region: "Marmara (Almanya doğumlu, İstanbul'da yetişti)",
      bio: "Almanya'nın Alzey kentinde doğan Tarkan Tevetoğlu, çocukluğunda Türkiye'ye dönmüş, İstanbul'da müzik eğitimi almıştır. 1992'de çıkardığı ilk albümüyle büyük çıkış yakalamış, kısa sürede Türkiye'nin ve sonrasında dünyanın tanıdığı bir pop yıldızı haline gelmiştir. 'Şımarık' şarkısı ile global bir başarı yakalayan Tarkan, 'Türk Pop Prensi' olarak anılır. Müziğinde doğu ve batı sentezini başarıyla gerçekleştirmiş, kendine özgü dans stili ve sahne performanslarıyla da tanınmıştır.",
      significance: "Türk pop müziğinin uluslararası alanda en tanınan ve başarılı temsilcisidir. Albümleri 20'den fazla ülkede yayınlanmış, şarkıları birçok dile çevrilmiştir. Modern Türk pop müziğinin gelişiminde önemli rol oynamış, dünya müzik endüstrisinde Türkiye'yi başarıyla temsil etmiştir. Çevre ve hayvan hakları konusundaki aktivizmiyle de tanınır.",
      notable_works: [
        {
          title: "Şımarık",
          year: "1997",
          lyrics_excerpt: "Şımarık, şıkıdım, şıkıdım / Hep senin aşkından / Kalbim şıkıdım, şıkıdım / Kaç kere yanıldım",
          description: "Uluslararası çapta büyük başarı yakalayan, 'şıkıdım' ritimleri ve 'dudak şapırdatma' efektiyle tanınan hit parçasıdır."
        },
        {
          title: "Kuzu Kuzu",
          year: "2001",
          lyrics_excerpt: "Dokunma, yanarsın / Yaklaşma, çarpılırsın / Ben sana göre değilim, kuzu kuzu / Bırak da seveyim, kuzu kuzu",
          description: "Kendine güven ve aşkta kararları sorgulama temalarını işleyen, dinamik bir eserdir."
        },
        {
          title: "Dudu",
          year: "2003",
          lyrics_excerpt: "Dudu, dudu, dudu-dudu, dudum / Dudu, dudu, dudu-dudu, dudu / Beni benden alıp götüren sensin / En deli sevdalar içinden",
          description: "Tutku dolu bir aşkı anlatan, dans müziği tarzında global başarı yakalamış bir eserdir."
        },
        {
          title: "Ölürüm Sana",
          year: "1997",
          lyrics_excerpt: "Ölürüm sana, ölürüm sana / Yanı başında durmuşum / Hiç mi hissetmedin / Ölürüm sana, ölürüm sana",
          description: "Tek taraflı, tutkulu bir aşkı ve bu aşkın verdiği acıyı anlatan duygusal bir eserdir."
        },
        {
          title: "Gülümse Kaderine",
          year: "2010",
          lyrics_excerpt: "Gülümse kaderine / Hayat ne getirirse / Hayat ne götürürse / Gülümse kaderine",
          description: "Yaşamın getirdiği her şeyi kabul etme ve pozitif kalma mesajı veren, felsefi bir eserdir."
        }
      ],
      influence: "Tarkan, Türk pop müziğinin global ölçekte tanınmasında ve kabul görmesinde büyük rol oynamıştır. Dans müziği ve performans tarzıyla birçok genç sanatçıya ilham kaynağı olmuş, Türk müzik endüstrisinin uluslararasılaşmasına katkıda bulunmuştur. Batı standartlarında prodüksiyon kalitesi ve profesyonel yaklaşımı ile Türk müzik sektörünün gelişimine öncülük etmiştir."
    },
    {
      name: "Cem Karaca",
      genre: "Anadolu Rock",
      period: "1945-2004",
      region: "Marmara (İstanbul)",
      bio: "İstanbul'da doğan Cem Karaca, sanatçı bir aileden gelmektedir. Müzik kariyerine 1960'larda başlamış, Apaşlar, Kardaşlar, Moğollar gibi gruplarla çalışmıştır. Güçlü sesi, etkileyici sahne performansı ve toplumsal mesaj içeren şarkılarıyla tanınır. Anadolu Rock akımının en önemli temsilcilerinden biri olarak, Türk halk müziği ile rock müziği başarıyla sentezlemiştir. Politik duruşu nedeniyle 1980 askeri darbesi sonrası yurtdışında yaşamak zorunda kalmış, 1987'de Türkiye'ye dönmüştür.",
      significance: "Anadolu Rock akımının en güçlü seslerinden ve öncülerinden biridir. Müziğinde toplumsal mesajlar, işçi sorunları, kültürel değerler ve politik eleştiriler öne çıkmıştır. Geleneksel Anadolu ezgilerini ve halk şairlerinin sözlerini modern rock aranjmanlarıyla buluşturmuş, Türk rock müziğine derinlik kazandırmıştır.",
      notable_works: [
        {
          title: "Parka",
          year: "1972",
          lyrics_excerpt: "Park yeri istiyorsanız, otomobil mezarlığı / İnsanın özlemiyse, yemyeşil bir park / Park yeri istiyorsanız, otomobil mezarlığı / İnsanın özlemiyse, yemyeşil bir park",
          description: "Sanayileşme ve kentleşmenin getirdiği çevre sorunlarını eleştiren, toplumsal bir eserdir."
        },
        {
          title: "Resimdeki Gözyaşları",
          year: "1975",
          lyrics_excerpt: "Resimdeki gözyaşları / Düşerse aynı yere / Gizli bir ırmak olur / Denize akar gider",
          description: "Ayrılık acısını ve geçmişe duyulan özlemi şiirsel bir dille anlatan duygusal bir eserdir."
        },
        {
          title: "Namus Belası",
          year: "1975",
          lyrics_excerpt: "Namus belası, namus belası / Biri kız, biri kardeş / Namus belası, namus belası / İkisi de genç yaşta",
          description: "Töre cinayetlerini ve namus kavramını sorgulayan, toplumsal bir eleştiri içeren güçlü bir eserdir."
        },
        {
          title: "Tamirci Çırağı",
          year: "1975",
          lyrics_excerpt: "Tamirci çırağı, tamirci çırağı / Okul dersen o ne ki, görmemiş ki / Tamirci çırağı, tamirci çırağı / Yağlı ellerle ekmek yemesi tek örneği",
          description: "İşçi sınıfının yaşam mücadelesini ve çocuk işçiliğini anlatan, sosyal bir eserdir."
        },
        {
          title: "Bindik Bir Alamete",
          year: "1976",
          lyrics_excerpt: "Bindik bir alamete, gidiyoruz kıyamete / Ne olacak halimiz / Ağlayan gözlerimiz, sızlayan yüreğimiz / Paylaşılan ümidimiz",
          description: "Toplumsal kaos ve belirsizlik karşısındaki endişeyi, ancak umudun paylaşılmasıyla aşılabileceğini anlatan bir eserdir."
        }
      ],
      influence: "Cem Karaca, Anadolu Rock akımının gelişiminde ve Türk rock müziğinin kimlik kazanmasında önemli rol oynamıştır. Politik ve toplumsal mesajları ile müziğin sosyal değişimdeki gücünü göstermiş, birçok müzisyene ilham kaynağı olmuştur. Onun eserleri, günümüzde de birçok sanatçı tarafından yeniden yorumlanmakta ve hala büyük bir dinleyici kitlesine ulaşmaktadır."
    },
    {
      name: "Duman",
      genre: "Türk Rock",
      period: "1999-Günümüz",
      region: "İstanbul merkezli",
      bio: "1999 yılında İstanbul'da kurulan Duman, Türk rock müziğinin en önemli gruplarından biridir. Kurucu üyeleri Kaan Tangöze (vokal, gitar), Ari Barokas (bas gitar), Batuhan Mutlugil (gitar) ve Cengiz Baysal'dır (davul, daha sonra ayrıldı). Grunge ve alternatif rock etkili müzikleri, Türkçe sözleri ve samimi sahne performanslarıyla geniş bir hayran kitlesine ulaşmışlardır. 2000'lerde çıkardıkları albümlerle Türk rock müziğine yeni bir soluk getiren grup, 20 yılı aşkın süredir aktif olarak müzik üretmeye devam etmektedir.",
      significance: "Modern Türk rock müziğinin en etkili gruplarından biridir. Grunge ve alternatif rock tarzını Türkçe rock müziğine başarıyla adapte etmişlerdir. Müziklerinde gerçekçi, zaman zaman melankolik ve toplumsal eleştiri içeren sözleri ile dikkat çekmişlerdir. Rock müziğinin geniş kitlelere ulaşmasına ve bir alt kültür olmaktan çıkıp ana akımda yer bulmasına katkıda bulunmuşlardır.",
      notable_works: [
        {
          title: "Seni Kendime Sakladım",
          year: "2000",
          lyrics_excerpt: "Seni kendime sakladım / Herkes başını alıp giderken / Beni sensiz sanıp da gülerken / Sen bende saklıydın",
          description: "Aşk ve içselleştirme temalarını işleyen, grubun ilk hit parçalarından biridir."
        },
        {
          title: "Bu Akşam",
          year: "2002",
          lyrics_excerpt: "Bu akşam, bu akşam / Bir kadeh olsun be gardaş / Derdim büyük, derdime eş olsun / Bu akşam, bu akşam",
          description: "Hayatın zorluklarından geçici bir kaçış arayışını ve arkadaşlığı konu alan bir eserdir."
        },
        {
          title: "Helal Olsun",
          year: "2005",
          lyrics_excerpt: "Helal olsun sana bu gözler / Bir bakışın can yaktı yine / Helal olsun sana bu yürek / Vurdun yine ayrılık yerine",
          description: "Acı veren bir aşk ilişkisini ve ayrılık sonrası duyguları anlatan, güçlü bir rock baladıdır."
        },
        {
          title: "Senden Daha Güzel",
          year: "2009",
          lyrics_excerpt: "Gözlerimi kapatıyorum / Yok oluyorsun / Açıyorum gözlerimi / Ve yokluğunu görüyorum",
          description: "Ayrılık sonrası yaşanan boşluk ve özlem duygularını anlatan, melankolik bir eserdir."
        },
        {
          title: "Öyle Dertli",
          year: "2010",
          lyrics_excerpt: "Öyle dertli ne yapacağını bilmiyor / Gönül bu, sözü dinlemiyor / Öyle dertli ne yapacağını bilmiyor / Gönül bu, seni seviyor",
          description: "Karşılıksız aşkın verdiği çaresizlik ve duygusal karmaşayı anlatan bir eserdir."
        }
      ],
      influence: "Duman, 2000'lerde Türk rock müziğinin yeniden canlanmasında önemli rol oynamış, özellikle genç kuşaklar üzerinde büyük etki bırakmıştır. Grunge ve alternatif rock tarzını Türkçe sözlerle başarıyla birleştirerek özgün bir sound yaratmış, birçok yeni rock grubuna ilham kaynağı olmuştur. Festivaller ve stadyum konserleriyle rock müziğinin Türkiye'de kitleselleşmesine katkıda bulunmuşlardır."
    },
    {
      name: "Ceza",
      genre: "Türkçe Rap/Hip-Hop",
      period: "1976-Günümüz",
      region: "Marmara (İstanbul)",
      bio: "İstanbul'da doğan Bilgin Özçalkan, sahne adıyla Ceza, Türk hip-hop kültürünün en önemli isimlerindendir. 1990'ların sonunda müziğe başlamış, Karakan ve Nefret gruplarında yer almış, sonrasında solo kariyerine devam etmiştir. Hızlı flow'u, güçlü kafiye yapısı ve toplumsal mesajlar içeren sözleriyle tanınır. 2000'lerin başından itibaren yayınladığı albümlerle Türkçe rap'in ana akım müzikte yer bulmasına öncülük etmiştir.",
      significance: "Türkçe rap müziğin en tanınan ve saygı duyulan isimlerinden biridir. Kendine özgü flow ve ses tonu ile hip-hop kültürünün Türkiye'de gelişimine ve tanınmasına büyük katkı sağlamıştır. Şarkılarında toplumsal eleştiri, kişisel deneyimler ve kent yaşamının zorlukları gibi temaları ele almıştır. Uluslararası projelerle de Türkçe rap'i dünyaya tanıtmıştır.",
      notable_works: [
        {
          title: "Suspus",
          year: "2004",
          lyrics_excerpt: "Suspus, lafı olmayan, sözü bitmiş / İçine atmış ne varsa, her şeyi gizli / Suspus, derdi çokmuş, kalbi kırık / Söyleyecek çok şeyi var, kalmış yalnız",
          description: "Toplumsal baskı ve susturulma hissini anlatan, suskunluğu ironik olarak 'Suspus' kelimesiyle ifade eden güçlü bir eserdir."
        },
        {
          title: "Holocaust",
          year: "2002",
          lyrics_excerpt: "Karşında Ceza, hardcore flow / Mele yansa görür seni / Kafa sesi, hardcore flow / Ezberlenmesi zor style",
          description: "Ceza'nın teknik yeteneğini ve kendine özgü tarzını ortaya koyan, underground hip-hop estetiğini yansıtan bir eserdir."
        },
        {
          title: "Fark Var",
          year: "2004",
          lyrics_excerpt: "Fark var, aramızda fark var / Sen beni bana sor, bana sor / Fark var, aramızda fark var / Ben seni sana sor, sana sor",
          description: "Bireysel farklılıklar ve kimlik arayışı temalarını işleyen, güçlü bir mesaj içeren eserdir."
        },
        {
          title: "Denizci",
          year: "2009",
          lyrics_excerpt: "Denizci, ben bir denizci / Her liman başka bir hikaye / Denizci, ben bir denizci / Her şehir başka bir aşk",
          description: "Hayat yolculuğunu denizcilik metaforuyla anlatan, felsefi bir derinliğe sahip eserdir."
        },
        {
          title: "Yerli Plaka",
          year: "2004",
          lyrics_excerpt: "34 İstanbul, yerli plaka / Sokakta tek başına yaşa mücadelen / 35 İzmir, yerli plaka / Denizin kokusunu alır burnun",
          description: "Türkiye'nin çeşitli şehirlerini ve her birinin karakteristik özelliklerini anlatan, kültürel bir eserdir."
        }
      ],
      influence: "Ceza, Türkçe rap'in gelişiminde ve popülerleşmesinde önemli rol oynamış, teknik yeteneği ve sahne performanslarıyla hip-hop kültürünün Türkiye'de saygın bir müzik türü olarak kabul görmesine katkıda bulunmuştur. Birçok genç rap sanatçısına mentor olmuş, Türkçe rap'in uluslararası platformlarda tanınmasına öncülük etmiştir."
    }
  ],
  
  // =====================================================================
  // MÜZİK ENSTRÜMANLARI VE ÇALMA TEKNİKLERİ
  // =====================================================================
  
  instruments: [
    // Türk Müzik Enstrümanları