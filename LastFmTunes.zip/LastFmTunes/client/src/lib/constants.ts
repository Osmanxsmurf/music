export const APP_NAME = "MüzikAI";
export const APP_DESCRIPTION = "Kişiselleştirilmiş müzik önerileri ve asistan";

// Mood options for selection
export const MOODS = [
  { id: "energetic", label: "Enerjik", color: "bg-primary" },
  { id: "peaceful", label: "Huzurlu", color: "bg-blue-400" },
  { id: "romantic", label: "Romantik", color: "bg-pink-400" },
  { id: "nostalgic", label: "Nostaljik", color: "bg-amber-400" },
  { id: "sad", label: "Hüzünlü", color: "bg-indigo-400" },
  { id: "motivational", label: "Motivasyon", color: "bg-red-400" },
  { id: "focus", label: "Odaklanma", color: "bg-emerald-400" },
  { id: "happy", label: "Mutlu", color: "bg-yellow-400" },
  { id: "chill", label: "Rahatlatıcı", color: "bg-teal-400" },
  { id: "party", label: "Parti", color: "bg-purple-400" }
];

// Music genres
export const GENRES = [
  { id: "pop", label: "Pop", color: "bg-primary" },
  { id: "rock", label: "Rock", color: "bg-secondary" },
  { id: "hiphop", label: "Hip Hop", color: "bg-orange-500" },
  { id: "jazz", label: "Jazz", color: "bg-amber-500" },
  { id: "electronic", label: "Elektronik", color: "bg-green-500" },
  { id: "classical", label: "Klasik", color: "bg-violet-500" },
  { id: "rnb", label: "R&B", color: "bg-rose-500" },
  { id: "country", label: "Country", color: "bg-cyan-500" },
  { id: "latin", label: "Latin", color: "bg-fuchsia-500" },
  { id: "indie", label: "Indie", color: "bg-emerald-500" }
];

// AI chat suggestions
export const CHAT_SUGGESTIONS = [
  "Enerjik şarkılar öner",
  "90'lar pop müziği",
  "Spor yaparken dinlemek için",
  "En sevilen rock şarkıları",
  "Odaklanmak için müzik",
  "Rahatlamak için ne dinleyebilirim?",
  "Yeni çıkan şarkıları göster",
  "Bana bir çalma listesi oluştur"
];

// Default greeting message for the AI
export const DEFAULT_GREETING = "Merhaba! Ben senin kişisel müzik asistanınım. Size nasıl yardımcı olabilirim?";

// Audio player constants
export const SKIP_TIME = 15; // seconds to skip when pressing forward/backward
export const DEFAULT_VOLUME = 0.7; // default volume level (0-1)

// Mapping LastFM tags to moods
export const LASTFM_MOOD_MAPPING = {
  "energetic": ["energetic", "upbeat", "powerful", "dance", "party"],
  "peaceful": ["calm", "peaceful", "relaxing", "ambient", "chill"],
  "romantic": ["romantic", "love", "slow", "ballad"],
  "nostalgic": ["80s", "90s", "00s", "oldies", "retro", "classic"],
  "sad": ["sad", "melancholic", "emotional", "ballad"],
  "motivational": ["motivational", "inspirational", "workout", "gym"],
  "focus": ["focus", "study", "concentration", "instrumental"],
  "happy": ["happy", "fun", "cheerful", "feel good"],
  "chill": ["chill", "laid back", "easy listening", "smooth"],
  "party": ["party", "dance", "club", "electronic", "edm"]
};

// API settings
export const API_REQUEST_THROTTLE = 1000; // ms between API requests
export const API_TIMEOUT = 10000; // ms to wait before timing out API requests
export const CACHE_DURATION = 24 * 60 * 60 * 1000; // 24 hours

// Local storage keys
export const LOCAL_STORAGE_KEYS = {
  SONGS: 'muzikai_songs',
  PLAYLISTS: 'muzikai_playlists',
  RECENTLY_PLAYED: 'muzikai_recently_played',
  LIKED_SONGS: 'muzikai_liked_songs',
  USER_PREFERENCES: 'muzikai_user_preferences',
  THEME: 'muzikai_theme',
  VOLUME: 'muzikai_volume',
  OFFLINE_MODE: 'muzikai_offline_mode'
};

// PWA Settings
export const PWA_CACHE_NAME = 'muzikai-cache-v1';
export const ASSETS_TO_CACHE = [
  '/',
  '/index.html',
  '/offline.html'
  // Additional paths will be added dynamically
];
