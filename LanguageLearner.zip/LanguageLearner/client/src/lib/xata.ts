// Xata DB integration
import { apiRequest } from "./queryClient";

const XATA_API_KEY = import.meta.env.VITE_XATA_API_KEY;
const XATA_DATABASE_URL = import.meta.env.VITE_XATA_DATABASE_URL;

// Check if Xata credentials are available
export const isXataAvailable = (): boolean => {
  return !!(XATA_API_KEY && XATA_DATABASE_URL);
};

// Log availability for debugging
console.log("Xata API available:", isXataAvailable());

// Interfaces for data types
export interface XataUser {
  id: string;
  username: string;
  fullName: string;
  email: string;
  profilePicture?: string;
  createdAt: Date;
}

export interface XataTrack {
  id: string;
  title: string;
  artist: string;
  album?: string;
  duration?: number;
  coverImage?: string;
  lastfmId?: string;
  youtubeId?: string;
}

export interface XataPlaylist {
  id: string;
  name: string;
  userId: string;
  description?: string;
  coverImage?: string;
  trackCount: number;
  duration: number;
  createdAt: Date;
}

export interface XataLikedTrack {
  id: string;
  userId: string;
  trackId: string;
  likedAt: Date;
}

export interface XataPlaylistTrack {
  id: string;
  playlistId: string;
  trackId: string;
  position: number;
}

export interface XataRecentlyPlayed {
  id: string;
  userId: string;
  trackId: string;
  playedAt: Date;
}

export interface XataChatMessage {
  id: string;
  userId: string;
  content: string;
  isUser: boolean;
  timestamp: Date;
}

// Track related functions
export const searchTracks = async (query: string): Promise<XataTrack[]> => {
  try {
    const response = await apiRequest("GET", `/api/tracks/search?q=${encodeURIComponent(query)}`, undefined);
    return await response.json();
  } catch (error) {
    console.error("Error searching tracks:", error);
    return [];
  }
};

export const getTrackByLastFMId = async (lastfmId: string): Promise<XataTrack | null> => {
  try {
    const response = await apiRequest("GET", `/api/tracks/lastfm/${encodeURIComponent(lastfmId)}`, undefined);
    if (!response.ok) return null;
    return await response.json();
  } catch (error) {
    console.error("Error getting track by LastFM ID:", error);
    return null;
  }
};

export const createTrack = async (track: Omit<XataTrack, "id">): Promise<XataTrack | null> => {
  try {
    const response = await apiRequest("POST", "/api/tracks", track);
    return await response.json();
  } catch (error) {
    console.error("Error creating track:", error);
    return null;
  }
};

// Playlist related functions
export const getUserPlaylists = async (userId: string): Promise<XataPlaylist[]> => {
  try {
    const response = await apiRequest("GET", `/api/users/${userId}/playlists`, undefined);
    return await response.json();
  } catch (error) {
    console.error("Error getting user playlists:", error);
    return [];
  }
};

export const createPlaylist = async (playlist: Omit<XataPlaylist, "id" | "createdAt">): Promise<XataPlaylist | null> => {
  try {
    const response = await apiRequest("POST", "/api/playlists", playlist);
    return await response.json();
  } catch (error) {
    console.error("Error creating playlist:", error);
    return null;
  }
};

export const addTrackToPlaylist = async (playlistId: string, trackId: string, position: number): Promise<boolean> => {
  try {
    const response = await apiRequest("POST", `/api/playlists/${playlistId}/tracks`, { trackId, position });
    return response.ok;
  } catch (error) {
    console.error("Error adding track to playlist:", error);
    return false;
  }
};

// Liked tracks related functions
export const getLikedTracks = async (userId: string): Promise<XataTrack[]> => {
  try {
    const response = await apiRequest("GET", `/api/users/${userId}/liked`, undefined);
    return await response.json();
  } catch (error) {
    console.error("Error getting liked tracks:", error);
    return [];
  }
};

export const likeTrack = async (userId: string, trackId: string): Promise<boolean> => {
  try {
    const response = await apiRequest("POST", `/api/tracks/${trackId}/like`, { userId });
    return response.ok;
  } catch (error) {
    console.error("Error liking track:", error);
    return false;
  }
};

export const unlikeTrack = async (userId: string, trackId: string): Promise<boolean> => {
  try {
    const response = await apiRequest("DELETE", `/api/tracks/${trackId}/like`, { userId });
    return response.ok;
  } catch (error) {
    console.error("Error unliking track:", error);
    return false;
  }
};

// Chat related functions
export const getUserChatMessages = async (userId: string): Promise<XataChatMessage[]> => {
  try {
    const response = await apiRequest("GET", `/api/users/${userId}/chat`, undefined);
    return await response.json();
  } catch (error) {
    console.error("Error getting user chat messages:", error);
    return [];
  }
};

export const sendChatMessage = async (userId: string, content: string, isUser: boolean): Promise<XataChatMessage | null> => {
  try {
    const response = await apiRequest("POST", `/api/users/${userId}/chat`, { content, isUser });
    return await response.json();
  } catch (error) {
    console.error("Error sending chat message:", error);
    return null;
  }
};