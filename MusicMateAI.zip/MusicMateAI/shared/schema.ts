import { pgTable, text, serial, integer, boolean, jsonb, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  email: text("email").notNull().unique(),
  name: text("name"),
  profilePicture: text("profile_picture"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const favorites = pgTable("favorites", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  trackId: text("track_id").notNull(),
  title: text("title").notNull(),
  artist: text("artist").notNull(),
  albumArt: text("album_art"),
  source: text("source").notNull(), // youtube, lastfm, etc.
  createdAt: timestamp("created_at").defaultNow(),
});

export const playHistory = pgTable("play_history", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  trackId: text("track_id").notNull(),
  title: text("title").notNull(),
  artist: text("artist").notNull(),
  albumArt: text("album_art"),
  source: text("source").notNull(), // youtube, lastfm, etc.
  playedAt: timestamp("played_at").defaultNow(),
});

export const searches = pgTable("searches", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  query: text("query").notNull(),
  type: text("type").notNull(), // song, artist, album
  resultCount: integer("result_count"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const aiChats = pgTable("ai_chats", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  messages: jsonb("messages").notNull(), // Array of messages with role, content
  createdAt: timestamp("created_at").defaultNow(),
});

// Insert Schemas
export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
});

export const insertFavoriteSchema = createInsertSchema(favorites).omit({
  id: true,
  createdAt: true,
});

export const insertPlayHistorySchema = createInsertSchema(playHistory).omit({
  id: true,
  playedAt: true,
});

export const insertSearchSchema = createInsertSchema(searches).omit({
  id: true,
  createdAt: true,
});

export const insertAiChatSchema = createInsertSchema(aiChats).omit({
  id: true,
  createdAt: true,
});

// Insert Types
export type InsertUser = z.infer<typeof insertUserSchema>;
export type InsertFavorite = z.infer<typeof insertFavoriteSchema>;
export type InsertPlayHistory = z.infer<typeof insertPlayHistorySchema>;
export type InsertSearch = z.infer<typeof insertSearchSchema>;
export type InsertAiChat = z.infer<typeof insertAiChatSchema>;

// Select Types
export type User = typeof users.$inferSelect;
export type Favorite = typeof favorites.$inferSelect;
export type PlayHistory = typeof playHistory.$inferSelect;
export type Search = typeof searches.$inferSelect;
export type AiChat = typeof aiChats.$inferSelect;
