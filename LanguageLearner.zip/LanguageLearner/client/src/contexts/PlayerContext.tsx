import { createContext, useContext, useState, useEffect, ReactNode } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useAuth } from "./AuthContext";
import { useToast } from "@/hooks/use-toast";

type Track = {
  id: number;
  title: string;
  artist: string;
  album?: string;
  duration?: number;
  coverImage?: string;
  lastfmId?: string;
};

type PlayerContextType = {
  currentTrack: Track | null;
  queue: Track[];
  isPlaying: boolean;
  volume: number;
  progress: number;
  duration: number;
  playTrack: (track: Track) => void;
  pauseTrack: () => void;
  resumeTrack: () => void;
  nextTrack: () => void;
  previousTrack: () => void;
  setVolume: (volume: number) => void;
  setProgress: (progress: number) => void;
  toggleLike: (track: Track) => Promise<void>;
  isTrackLiked: (trackId: number) => boolean;
};

const PlayerContext = createContext<PlayerContextType | undefined>(undefined);

export function PlayerProvider({ children }: { children: ReactNode }) {
  const [currentTrack, setCurrentTrack] = useState<Track | null>(null);
  const [queue, setQueue] = useState<Track[]>([]);
  const [isPlaying, setIsPlaying] = useState(false);
  const [volume, setVolumeState] = useState(70);
  const [progress, setProgressState] = useState(0);
  const [duration, setDuration] = useState(0);
  const [likedTracks, setLikedTracks] = useState<number[]>([]);
  
  const { user, isAuthenticated } = useAuth();
  const queryClient = useQueryClient();
  const { toast } = useToast();

  // Simulated audio player (to be replaced with actual implementation)
  const [audioElement, setAudioElement] = useState<HTMLAudioElement | null>(null);

  useEffect(() => {
    // Create a singleton audio element
    const audio = new Audio();
    setAudioElement(audio);

    // Set up event listeners
    const updateProgress = () => {
      if (audio && audio.duration) {
        setProgressState((audio.currentTime / audio.duration) * 100);
      }
    };

    const updateDuration = () => {
      if (audio && !isNaN(audio.duration)) {
        setDuration(audio.duration);
      }
    };

    const handleEnded = () => {
      nextTrack();
    };

    audio.addEventListener("timeupdate", updateProgress);
    audio.addEventListener("durationchange", updateDuration);
    audio.addEventListener("ended", handleEnded);

    return () => {
      audio.removeEventListener("timeupdate", updateProgress);
      audio.removeEventListener("durationchange", updateDuration);
      audio.removeEventListener("ended", handleEnded);
      audio.pause();
    };
  }, []);

  // Load liked tracks if authenticated
  useEffect(() => {
    if (isAuthenticated && user) {
      // Fetch liked tracks
      const fetchLikedTracks = async () => {
        try {
          const response = await fetch("/api/tracks/liked", {
            credentials: "include",
          });
          
          if (response.ok) {
            const data = await response.json();
            setLikedTracks(data.map((track: Track) => track.id));
          }
        } catch (error) {
          console.error("Error fetching liked tracks:", error);
        }
      };
      
      fetchLikedTracks();
    }
  }, [isAuthenticated, user]);

  // Track mutations
  const playedMutation = useMutation({
    mutationFn: async (trackId: number) => {
      if (!isAuthenticated) return null;
      const res = await apiRequest("POST", `/api/tracks/${trackId}/played`, {});
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tracks/recent"] });
    },
  });

  const likeMutation = useMutation({
    mutationFn: async (trackId: number) => {
      const res = await apiRequest("POST", `/api/tracks/${trackId}/like`, {});
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tracks/liked"] });
    },
    onError: () => {
      toast({
        variant: "destructive",
        title: "Hata",
        description: "Şarkı beğenilirken bir sorun oluştu",
      });
    },
  });

  const unlikeMutation = useMutation({
    mutationFn: async (trackId: number) => {
      const res = await apiRequest("DELETE", `/api/tracks/${trackId}/like`, {});
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tracks/liked"] });
    },
    onError: () => {
      toast({
        variant: "destructive",
        title: "Hata",
        description: "Şarkı beğenisi kaldırılırken bir sorun oluştu",
      });
    },
  });

  const playTrack = async (track: Track) => {
    if (!track) return;

    // Update current track
    setCurrentTrack(track);
    
    // Set duration if available
    if (track.duration) {
      setDuration(track.duration);
    }
    
    // Reset progress
    setProgressState(0);
    
    // Start playing indicator (but actual playback starts after we get the audio source)
    setIsPlaying(true);
    
    // Log played track if authenticated
    if (isAuthenticated && track.id) {
      playedMutation.mutate(track.id);
    }
    
    // Find audio source for the track using YouTubeAPI or fallback
    try {
      let previewUrl = null;
      let songTitle = track.title;
      let artistName = track.artist;
      
      // Log for debugging
      console.log(`Attempting to play: ${songTitle} by ${artistName}`);
      
      // Müzik ses dosyası için sözlük (gerçekte YouTube API'den alınacak)
      const songDictionary: Record<string, string> = {
        "Seni Dert Etmeler": "https://p.scdn.co/mp3-preview/3eb16018c2a700240e9dfb8817b6f2d041f15eb1",
        "Bu Akşam": "https://p.scdn.co/mp3-preview/05c1a594393a5c25dfb1cd88358c1bfc708ef864",
        "Cambaz": "https://p.scdn.co/mp3-preview/3eb16018c2a700240e9dfb8817b6f2d041f15eb1",
        "Kuzu Kuzu": "https://p.scdn.co/mp3-preview/3eb16018c2a700240e9dfb8817b6f2d041f15eb1",
        "Öyle Kolaysa": "https://p.scdn.co/mp3-preview/3eb16018c2a700240e9dfb8817b6f2d041f15eb1", 
        "Nil": "https://p.scdn.co/mp3-preview/3eb16018c2a700240e9dfb8817b6f2d041f15eb1"
      };
      
      try {
        // Parça adıyla eşleşen şarkıyı bul
        if (songTitle in songDictionary) {
          previewUrl = songDictionary[songTitle];
          console.log(`Şarkı bulundu: ${songTitle}`);
        } else {
          // Varsayılan URL kullan
          previewUrl = 'https://p.scdn.co/mp3-preview/3eb16018c2a700240e9dfb8817b6f2d041f15eb1';
          console.log(`Şarkı bulunamadı: ${songTitle} - ${artistName}, varsayılan parça kullanılıyor`);
        }
      } catch (error) {
        console.error('Şarkı yüklenirken hata:', error);
        previewUrl = 'https://p.scdn.co/mp3-preview/3eb16018c2a700240e9dfb8817b6f2d041f15eb1';
      }
      
      if (audioElement) {
        // Set the audio source
        audioElement.src = previewUrl;
        audioElement.volume = volume / 100;
        
        // Play the audio
        await audioElement.play();
        
        // Show success toast
        toast({
          title: "Şarkı çalınıyor",
          description: `${track.title} - ${track.artist}`,
          variant: "default",
        });
      }
    } catch (error) {
      console.error("Error playing audio:", error);
      
      // Show error toast
      toast({
        title: "Ses dosyası yüklenemedi",
        description: "Şarkı şu anda çalınamıyor. Lütfen daha sonra tekrar deneyin.",
        variant: "destructive",
      });
      
      // Reset playing state
      setIsPlaying(false);
    }
  };

  const pauseTrack = () => {
    if (isPlaying) {
      setIsPlaying(false);
      if (audioElement) {
        audioElement.pause();
      }
    }
  };

  const resumeTrack = async () => {
    if (currentTrack && !isPlaying) {
      setIsPlaying(true);
      
      if (audioElement) {
        try {
          await audioElement.play();
        } catch (error) {
          console.error("Error resuming audio:", error);
          
          // Show error toast
          toast({
            title: "Oynatma hatası",
            description: "Şarkı devam ettirilemiyor. Lütfen başka bir şarkı seçin.",
            variant: "destructive",
          });
          
          // Reset playing state
          setIsPlaying(false);
        }
      }
    }
  };

  const nextTrack = () => {
    if (queue.length > 0) {
      const nextTrack = queue[0];
      const newQueue = queue.slice(1);
      setQueue(newQueue);
      playTrack(nextTrack);
    } else {
      pauseTrack();
      setProgressState(0);
    }
  };

  const previousTrack = () => {
    // For simplicity, we'll just restart the current track
    if (audioElement) {
      audioElement.currentTime = 0;
      setProgressState(0);
      if (!isPlaying) {
        resumeTrack();
      }
    }
  };

  const setVolume = (newVolume: number) => {
    setVolumeState(newVolume);
    if (audioElement) {
      audioElement.volume = newVolume / 100;
    }
  };

  const setProgress = (newProgress: number) => {
    setProgressState(newProgress);
    if (audioElement && duration) {
      audioElement.currentTime = (newProgress / 100) * duration;
    }
  };

  const toggleLike = async (track: Track) => {
    if (!isAuthenticated || !track.id) {
      toast({
        title: "Giriş yapın",
        description: "Şarkıları beğenmek için giriş yapmanız gerekiyor",
        variant: "default",
      });
      return;
    }
    
    const isLiked = likedTracks.includes(track.id);
    
    try {
      if (isLiked) {
        await unlikeMutation.mutateAsync(track.id);
        setLikedTracks(likedTracks.filter(id => id !== track.id));
      } else {
        await likeMutation.mutateAsync(track.id);
        setLikedTracks([...likedTracks, track.id]);
      }
    } catch (error) {
      console.error("Error toggling track like:", error);
    }
  };

  const isTrackLiked = (trackId: number): boolean => {
    return likedTracks.includes(trackId);
  };

  return (
    <PlayerContext.Provider
      value={{
        currentTrack,
        queue,
        isPlaying,
        volume,
        progress,
        duration,
        playTrack,
        pauseTrack,
        resumeTrack,
        nextTrack,
        previousTrack,
        setVolume,
        setProgress,
        toggleLike,
        isTrackLiked,
      }}
    >
      {children}
    </PlayerContext.Provider>
  );
}

export function usePlayer() {
  const context = useContext(PlayerContext);
  if (context === undefined) {
    throw new Error("usePlayer must be used within a PlayerProvider");
  }
  return context;
}
