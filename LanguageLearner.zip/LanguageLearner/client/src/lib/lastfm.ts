// LastFM API integration for fetching music data
// API Key set in environment variables
const API_KEY = process.env.LASTFM_API_KEY || import.meta.env.VITE_LASTFM_API_KEY || "d36fa1c99414e1f8fc9ae7bd3857e9b5";
const API_BASE_URL = "https://ws.audioscrobbler.com/2.0/";

// Types
export interface LastFMTrack {
  name: string;
  artist: string;
  album?: string;
  image?: string[];
  url: string;
  mbid?: string;
}

export interface LastFMArtist {
  name: string;
  url: string;
  image?: string[];
  mbid?: string;
}

export interface LastFMAlbum {
  name: string;
  artist: string;
  url: string;
  image?: string[];
  mbid?: string;
}

// Helper function to make API requests
const makeRequest = async (method: string, params: Record<string, string>): Promise<any> => {
  const queryParams = new URLSearchParams({
    method,
    api_key: API_KEY,
    format: "json",
    ...params,
  });

  try {
    const response = await fetch(`${API_BASE_URL}?${queryParams.toString()}`);
    
    if (!response.ok) {
      throw new Error(`LastFM API error: ${response.status} ${response.statusText}`);
    }
    
    return await response.json();
  } catch (error) {
    console.error("LastFM API request failed:", error);
    throw error;
  }
};

// Get track info
export const getTrackInfo = async (artist: string, track: string): Promise<LastFMTrack> => {
  const data = await makeRequest("track.getInfo", {
    artist,
    track,
  });
  
  return {
    name: data.track.name,
    artist: data.track.artist.name,
    album: data.track.album?.title,
    image: data.track.album?.image,
    url: data.track.url,
    mbid: data.track.mbid,
  };
};

// Search for tracks
export const searchTracks = async (query: string): Promise<LastFMTrack[]> => {
  const data = await makeRequest("track.search", {
    track: query,
    limit: "10",
  });
  
  return data.results.trackmatches.track.map((track: any) => ({
    name: track.name,
    artist: track.artist,
    url: track.url,
    mbid: track.mbid,
    image: track.image,
  }));
};

// Get artist info
export const getArtistInfo = async (artist: string): Promise<LastFMArtist> => {
  const data = await makeRequest("artist.getInfo", {
    artist,
  });
  
  return {
    name: data.artist.name,
    url: data.artist.url,
    image: data.artist.image,
    mbid: data.artist.mbid,
  };
};

// Get top tracks by artist
export const getArtistTopTracks = async (artist: string): Promise<LastFMTrack[]> => {
  const data = await makeRequest("artist.getTopTracks", {
    artist,
    limit: "10",
  });
  
  return data.toptracks.track.map((track: any) => ({
    name: track.name,
    artist: track.artist.name,
    url: track.url,
    mbid: track.mbid,
    image: track.image,
  }));
};

// Get album info
export const getAlbumInfo = async (artist: string, album: string): Promise<LastFMAlbum> => {
  const data = await makeRequest("album.getInfo", {
    artist,
    album,
  });
  
  return {
    name: data.album.name,
    artist: data.album.artist,
    url: data.album.url,
    image: data.album.image,
    mbid: data.album.mbid,
  };
};

// Get popular tracks in Turkey
export const getTopTracksInTurkey = async (): Promise<LastFMTrack[]> => {
  const data = await makeRequest("geo.getTopTracks", {
    country: "Turkey",
    limit: "12",
  });
  
  return data.tracks.track.map((track: any) => ({
    name: track.name,
    artist: track.artist.name,
    url: track.url,
    mbid: track.mbid,
    image: track.image,
  }));
};

// Check if LastFM API key is available
export const isLastFMApiKeyAvailable = (): boolean => {
  return API_KEY !== "lastfm_api_key_placeholder";
};

// Log availability for debugging
console.log("LastFM API Key available:", isLastFMApiKeyAvailable());
