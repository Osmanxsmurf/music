import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
import { AIAssistant } from '@/components/AIAssistant';
import { RecommendationEngine } from '@/components/RecommendationEngine';
import { fetchRecentlyPlayed, fetchLikedSongs } from '@/lib/xata';
import { useToast } from '@/hooks/use-toast';
import { usePullToRefresh } from '@/hooks/use-pull-to-refresh';
import { motion } from 'framer-motion';
import { Song } from '@shared/schema';
import { Loader2, Sparkles } from 'lucide-react';

export default function AssistantPage() {
  const { toast } = useToast();
  const [recentlyPlayed, setRecentlyPlayed] = useState<Song[]>([]);
  const [likedSongs, setLikedSongs] = useState<Song[]>([]);
  const [loading, setLoading] = useState(true);
  
  // Load user data
  const fetchData = async () => {
    setLoading(true);
    try {
      const [recent, liked] = await Promise.all([
        fetchRecentlyPlayed(1, 5),
        fetchLikedSongs(1)
      ]);
      
      setRecentlyPlayed(recent);
      setLikedSongs(liked);
    } catch (error) {
      console.error("Error loading user data:", error);
      toast({
        title: "Veri Yükleme Hatası",
        description: "Kullanıcı verileri yüklenirken bir sorun oluştu.",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };
  
  // Load data on mount
  useEffect(() => {
    fetchData();
  }, []);
  
  // Pull to refresh
  const { containerRef, pullDistance, isRefreshing } = usePullToRefresh({
    onRefresh: fetchData
  });
  
  // Refresh indicator styles
  const refreshIndicatorStyles = {
    height: `${pullDistance}px`,
    opacity: pullDistance > 0 ? 1 : 0,
  };
  
  return (
    <div 
      ref={containerRef}
      className="py-6 px-4 md:px-6 space-y-8 overflow-auto h-full relative"
    >
      {/* Pull to refresh indicator */}
      <div 
        className="flex justify-center items-center absolute top-0 left-0 right-0 z-10 overflow-hidden"
        style={refreshIndicatorStyles}
      >
        {isRefreshing ? (
          <Loader2 className="animate-spin text-primary h-6 w-6" />
        ) : (
          <div className="text-primary text-xs">↓ Yenilemek için çekin</div>
        )}
      </div>
      
      <motion.div 
        className="space-y-8"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        {/* Page title with enhanced design */}
        <div className="flex flex-col items-center text-center mb-6">
          <div className="relative">
            <div className="absolute -inset-1 bg-gradient-to-r from-purple-600 to-pink-600 rounded-full blur opacity-70"></div>
            <div className="relative bg-background rounded-full p-3">
              <Sparkles className="h-8 w-8 text-primary" />
            </div>
          </div>
          <h1 className="text-3xl font-bold mt-4 bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">MüzikAI Asistanı</h1>
          <p className="text-muted-foreground mt-2 max-w-md">
            Kişiselleştirilmiş müzik önerileri, ruh halinize göre şarkılar ve müzikal keşifler
          </p>
        </div>
        
        {/* AI Assistant with enhanced visualization */}
        <Card className="shadow-lg border-0 overflow-hidden bg-gradient-to-b from-background to-background/80">
          <div className="absolute inset-x-0 top-0 h-1 bg-gradient-to-r from-indigo-500 via-purple-500 to-pink-500"></div>
          <CardContent className="p-0 max-h-[65vh] md:max-h-[60vh]">
            <AIAssistant />
          </CardContent>
        </Card>
        
        {/* Recommendation Engine */}
        {!loading && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
            className="mt-6"
          >
            <div className="mb-4 flex items-center gap-2">
              <div className="h-5 w-1 bg-primary rounded-full"></div>
              <h2 className="text-xl font-semibold">Size Özel Öneriler</h2>
            </div>
            
            <RecommendationEngine 
              recentlyPlayedSongs={recentlyPlayed}
              likedSongs={likedSongs}
              className="shadow-sm border rounded-xl overflow-hidden"
            />
          </motion.div>
        )}
      </motion.div>
    </div>
  );
}
