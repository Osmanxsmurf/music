import { useState, useEffect, useCallback } from 'react';
import { LOCAL_STORAGE_KEYS } from '@/lib/constants';
import { getStoredData, setStoredData } from '@/lib/localStorage';
import { setupConnectivityListeners } from '@/lib/service-worker';

// Hook for managing offline state and preferences
export function useOffline() {
  const [isOffline, setIsOffline] = useState(!navigator.onLine);
  const [offlineMode, setOfflineMode] = useState(false);
  
  // Load offline mode preference
  useEffect(() => {
    const loadOfflinePreference = async () => {
      const stored = await getStoredData<boolean>(LOCAL_STORAGE_KEYS.OFFLINE_MODE, false);
      setOfflineMode(stored);
    };
    
    loadOfflinePreference();
  }, []);
  
  // Set up online/offline event listeners
  useEffect(() => {
    const cleanup = setupConnectivityListeners(
      // Online callback
      () => setIsOffline(false),
      // Offline callback
      () => setIsOffline(true)
    );
    
    return cleanup;
  }, []);
  
  // Toggle offline mode preference
  const toggleOfflineMode = useCallback(async () => {
    const newMode = !offlineMode;
    setOfflineMode(newMode);
    await setStoredData(LOCAL_STORAGE_KEYS.OFFLINE_MODE, newMode);
  }, [offlineMode]);
  
  // Prefetch important data for offline use
  const prefetchOfflineData = useCallback(async () => {
    try {
      // This function would prefetch and cache important data
      // Placeholder for actual implementation
      console.log('Prefetching data for offline use...');
      
      // Example: Fetch all songs
      const response = await fetch('/api/songs');
      if (!response.ok) {
        throw new Error('Failed to fetch songs');
      }
      
      const songs = await response.json();
      await setStoredData(LOCAL_STORAGE_KEYS.SONGS, songs);
      
      // Could also prefetch other important data here
      
      return true;
    } catch (error) {
      console.error('Error prefetching offline data:', error);
      return false;
    }
  }, []);
  
  return {
    isOffline,           // Current network status
    offlineMode,         // User preference for offline mode
    toggleOfflineMode,   // Function to toggle offline mode
    prefetchOfflineData  // Function to prefetch data for offline use
  };
}
