// Duygu durumu tabanlı müzik öneri motoru

// Temel duygu durumları ve ilgili müzik türleri
const moodGenreMap: Record<string, string[]> = {
  "mutlu": ["Pop", "Dance", "Elektronik", "Disco", "Rock"],
  "heyecanlı": ["Rock", "Metal", "Elektronik", "Hip-Hop", "Rap"],
  "enerjik": ["Dance", "Elektronik", "Rock", "Pop", "Hip-Hop"],
  "hüzünlü": ["Arabesk", "Klasik", "Jazz", "Akustik", "Halk Müziği"],
  "sakin": ["Akustik", "Klasik", "Jazz", "Ambient", "Türk Sanat"],
  "romantik": ["Türk Sanat", "Jazz", "R&B", "Pop Balad", "Akustik"],
  "nostaljik": ["Türk Sanat", "Halk Müziği", "Arabesk", "Rock", "Klasik"],
  "motivasyonel": ["Rock", "Pop", "Hip-Hop", "Elektronik", "Rap"]
};

// Duygu kelimeleri sözlüğü (Türkçe)
const moodKeywords: Record<string, string[]> = {
  "mutlu": ["mutlu", "neşeli", "sevinçli", "keyifli", "eğlenceli", "güzel", "harika", "muhteşem"],
  "heyecanlı": ["heyecanlı", "coşkulu", "ateşli", "adrenalin", "hareketli"],
  "enerjik": ["enerjik", "canlı", "dinamik", "güçlü", "aktif"],
  "hüzünlü": ["hüzünlü", "üzgün", "kederli", "melankolik", "acılı", "yalnız", "ağlamaklı"],
  "sakin": ["sakin", "huzurlu", "sessiz", "dinlendirici", "rahatlatıcı", "durgun"],
  "romantik": ["romantik", "aşk", "sevgi", "tutku", "duygusal"],
  "nostaljik": ["nostaljik", "eski", "hatıra", "geçmiş", "özlem", "anı"],
  "motivasyonel": ["motivasyon", "motive", "ilham", "başarı", "güç", "umut", "azim"]
};

// Popüler Türk sanatçıları ve türleri
const turkishArtistGenreMap: Record<string, string[]> = {
  "Tarkan": ["Pop", "Dance"],
  "Sezen Aksu": ["Pop", "Türk Sanat"],
  "Barış Manço": ["Rock", "Anadolu Rock", "Halk Müziği"],
  "Müslüm Gürses": ["Arabesk"],
  "Orhan Gencebay": ["Arabesk", "Türk Sanat"],
  "Sertab Erener": ["Pop", "Rock"],
  "Şebnem Ferah": ["Rock"],
  "Duman": ["Rock", "Alternatif"],
  "MFÖ": ["Pop", "Rock"],
  "Ceza": ["Rap", "Hip-Hop"],
  "Ezhel": ["Rap", "Hip-Hop"],
  "Mabel Matiz": ["Pop", "Alternatif"]
};

// Popüler şarkılar ve türleri
const popularSongsGenreMap: Record<string, string[]> = {
  "Kuzu Kuzu": ["Pop", "Tarkan"],
  "Firuze": ["Türk Sanat", "Sezen Aksu"],
  "Gülpembe": ["Anadolu Rock", "Barış Manço"],
  "Nilüfer": ["Arabesk", "Müslüm Gürses"],
  "Bir Sevmek Bin Defa Ölmek Demekmiş": ["Arabesk", "Orhan Gencebay"],
  "Everyway That I Can": ["Pop", "Sertab Erener"],
  "Ben Sana Söylemiştim": ["Rock", "Şebnem Ferah"],
  "Bu Akşam": ["Rock", "Duman"],
  "Ali Desidero": ["Pop", "MFÖ"],
  "Suspus": ["Rap", "Ceza"],
  "Geceler": ["Rap", "Ezhel"],
  "Öyle Kolaysa": ["Pop", "Mabel Matiz"]
};

interface MoodAnalysisResult {
  mood: string | null;
  confidence: number;
  allMoods: Record<string, number>;
}

interface MoodRecommendation {
  genres: string[];
  artists: string[];
  message: string;
}

// Metinsel duygu analizi fonksiyonu
export function analyzeMood(text: string): MoodAnalysisResult {
  // Her bir duygu için puan hesaplama
  const moodScores: Record<string, number> = {};
  
  // Her duygunun metninde geçen anahtar kelimeleri say
  Object.keys(moodKeywords).forEach(mood => {
    moodScores[mood] = 0;
    moodKeywords[mood].forEach(keyword => {
      // Metinde ilgili anahtar kelimenin kaç kez geçtiğini hesapla
      const regex = new RegExp(`\\b${keyword}\\b`, 'gi');
      const matches = text.match(regex) || [];
      moodScores[mood] += matches.length;
    });
  });
  
  // En yüksek puanlı duyguyu bul
  let dominantMood = Object.keys(moodScores)[0];
  let highestScore = moodScores[dominantMood];
  
  Object.keys(moodScores).forEach(mood => {
    if (moodScores[mood] > highestScore) {
      dominantMood = mood;
      highestScore = moodScores[mood];
    }
  });
  
  // Eğer belirgin bir duygu bulunamadıysa
  if (highestScore === 0) {
    return {
      mood: null,
      confidence: 0,
      allMoods: moodScores
    };
  }
  
  // Toplam puanları hesapla
  const totalScore = Object.values(moodScores).reduce((sum, score) => sum + score, 0);
  
  // Baskın duygunun güven skorunu hesapla
  const confidence = totalScore > 0 ? highestScore / totalScore : 0;
  
  return {
    mood: dominantMood,
    confidence,
    allMoods: moodScores
  };
}

// Duygu durumuna göre müzik önerisi
export function getMoodBasedRecommendations(mood: string | null, count = 5): MoodRecommendation {
  if (!mood || !moodGenreMap[mood]) {
    // Eğer duygu anlaşılamadıysa veya eşleşen tür yoksa rastgele öneri yap
    const allGenres = Object.values(moodGenreMap).flat();
    const uniqueGenres = [...new Set(allGenres)];
    const randomGenres = uniqueGenres.sort(() => 0.5 - Math.random()).slice(0, 3);
    
    return {
      genres: randomGenres,
      artists: getArtistsByGenres(randomGenres, 3),
      message: "Duygularınızı anlamak için daha fazla bilgiye ihtiyacım var. İşte size rastgele öneriler:"
    };
  }
  
  // Duygu ile eşleşen türleri al
  const genres = moodGenreMap[mood];
  
  // Bu türlere uygun sanatçıları al
  const artists = getArtistsByGenres(genres, Math.floor(count / 2));
  
  // Önerilen türleri ve sanatçıları döndür
  return {
    genres,
    artists,
    message: `${mood.charAt(0).toUpperCase() + mood.slice(1)} hissettiğiniz için size uygun türler ve sanatçılar:`
  };
}

// Türlere göre sanatçı önerisi
export function getArtistsByGenres(genres: string[], count = 3): string[] {
  const matchingArtists: string[] = [];
  
  // Verilen türlerle eşleşen sanatçıları bul
  Object.keys(turkishArtistGenreMap).forEach(artist => {
    const artistGenres = turkishArtistGenreMap[artist];
    const hasMatchingGenre = genres.some(genre => 
      artistGenres.some(artistGenre => 
        artistGenre.toLowerCase().includes(genre.toLowerCase()) || 
        genre.toLowerCase().includes(artistGenre.toLowerCase())
      )
    );
    
    if (hasMatchingGenre) {
      matchingArtists.push(artist);
    }
  });
  
  // Sonuçları karıştır ve istenen sayıda döndür
  return matchingArtists.sort(() => 0.5 - Math.random()).slice(0, count);
}

// Kullanıcı mesajına göre öneride bulun
export function generateMusicRecommendation(userMessage: string): string {
  // Duygu analizi yap
  const moodAnalysis = analyzeMood(userMessage.toLowerCase());
  
  let recommendations;
  
  // Eğer belirgin bir duygu tespit edildiyse
  if (moodAnalysis.mood && moodAnalysis.confidence > 0.2) {
    recommendations = getMoodBasedRecommendations(moodAnalysis.mood, 5);
  } else {
    // Doğrudan tür veya sanatçı adı geçiyor mu kontrol et
    const mentionedGenres: string[] = [];
    const mentionedArtists: string[] = [];
    
    // Tür kontrolü
    Object.values(moodGenreMap).flat().forEach(genre => {
      if (userMessage.toLowerCase().includes(genre.toLowerCase())) {
        mentionedGenres.push(genre);
      }
    });
    
    // Sanatçı kontrolü
    Object.keys(turkishArtistGenreMap).forEach(artist => {
      if (userMessage.toLowerCase().includes(artist.toLowerCase())) {
        mentionedArtists.push(artist);
      }
    });
    
    if (mentionedGenres.length > 0 || mentionedArtists.length > 0) {
      const genres = mentionedGenres.length > 0 ? mentionedGenres : 
                    mentionedArtists.flatMap(artist => turkishArtistGenreMap[artist] || []);
      
      const artists = mentionedArtists.length > 0 ? mentionedArtists : 
                     getArtistsByGenres(genres, 3);
      
      recommendations = {
        genres: [...new Set(genres)],
        artists: [...new Set(artists)],
        message: "Bahsettiğiniz türler ve sanatçılarla ilgili öneriler:"
      };
    } else {
      // Ne duygu ne tür ne de sanatçı belirtilmişse genel öneri yap
      const popularGenres = ["Pop", "Rock", "Türk Sanat", "Arabesk", "Rap"].sort(() => 0.5 - Math.random()).slice(0, 3);
      
      recommendations = {
        genres: popularGenres,
        artists: getArtistsByGenres(popularGenres, 3),
        message: "İşte Türkiye'de popüler olan bazı müzik türleri ve sanatçılar:"
      };
    }
  }
  
  return formatRecommendation(recommendations);
}

// Öneri formatını düzenle
function formatRecommendation(recommendation: MoodRecommendation): string {
  const { genres, artists, message } = recommendation;
  
  let response = `${message}\n\n`;
  
  if (genres && genres.length > 0) {
    response += "🎵 Müzik Türleri:\n";
    genres.forEach(genre => {
      response += `- ${genre}\n`;
    });
    response += "\n";
  }
  
  if (artists && artists.length > 0) {
    response += "👨‍🎤 Sanatçılar:\n";
    artists.forEach(artist => {
      response += `- ${artist}\n`;
    });
    response += "\n";
  }
  
  response += "Bu sanatçıların şarkılarını çalmak için üzerine tıklayabilir veya daha spesifik öneriler için bana nasıl hissettiğinizi detaylı anlatabilirsiniz.";
  
  return response;
}