import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/contexts/AuthContext";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import TrackCard from "@/components/TrackCard";
import PlaylistCard from "@/components/PlaylistCard";
import { Plus, Heart, Clock, ListMusic, Search } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { useMutation, useQueryClient } from "@tanstack/react-query";

export default function Library() {
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [newPlaylistName, setNewPlaylistName] = useState("");
  const [newPlaylistDescription, setNewPlaylistDescription] = useState("");
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  
  // Fetch liked tracks
  const { data: likedTracks = [] } = useQuery({
    queryKey: ["/api/tracks/liked"],
    enabled: !!user,
  });
  
  // Fetch recently played tracks
  const { data: recentTracks = [] } = useQuery({
    queryKey: ["/api/tracks/recent"],
    enabled: !!user,
  });
  
  // Fetch user playlists
  const { data: playlists = [] } = useQuery({
    queryKey: ["/api/playlists"],
    enabled: !!user,
  });
  
  // Create playlist mutation
  const createPlaylistMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", "/api/playlists", {
        name: newPlaylistName,
        description: newPlaylistDescription,
      });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/playlists"] });
      setNewPlaylistName("");
      setNewPlaylistDescription("");
      setIsCreateDialogOpen(false);
      toast({
        title: "Çalma listesi oluşturuldu",
        description: `"${newPlaylistName}" başarıyla oluşturuldu`,
      });
    },
    onError: (error: Error) => {
      toast({
        variant: "destructive",
        title: "Hata",
        description: error.message || "Çalma listesi oluşturulurken bir hata oluştu",
      });
    },
  });
  
  const handleCreatePlaylist = () => {
    if (!newPlaylistName.trim()) {
      toast({
        variant: "destructive",
        title: "Hata",
        description: "Çalma listesi adı boş olamaz",
      });
      return;
    }
    
    createPlaylistMutation.mutate();
  };
  
  const handlePlayPlaylist = (playlist: any) => {
    toast({
      title: "Çalma listesi başlatıldı",
      description: `"${playlist.name}" çalma listesi başlatıldı`,
    });
  };

  return (
    <div className="p-4 md:p-8 pb-32">
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl md:text-3xl font-bold">Kitaplığım</h1>
        
        <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="h-4 w-4 mr-2" />
              Çalma Listesi Oluştur
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Yeni Çalma Listesi</DialogTitle>
              <DialogDescription>
                Yeni bir çalma listesi oluşturmak için aşağıdaki bilgileri girin.
              </DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div>
                <label htmlFor="name" className="text-sm font-medium mb-2 block">Çalma Listesi Adı</label>
                <Input
                  id="name"
                  placeholder="Çalma listesi adı"
                  value={newPlaylistName}
                  onChange={(e) => setNewPlaylistName(e.target.value)}
                />
              </div>
              <div>
                <label htmlFor="description" className="text-sm font-medium mb-2 block">Açıklama (İsteğe bağlı)</label>
                <Input
                  id="description"
                  placeholder="Çalma listesi açıklaması"
                  value={newPlaylistDescription}
                  onChange={(e) => setNewPlaylistDescription(e.target.value)}
                />
              </div>
            </div>
            <DialogFooter>
              <Button onClick={handleCreatePlaylist} disabled={createPlaylistMutation.isPending}>
                {createPlaylistMutation.isPending ? "Oluşturuluyor..." : "Oluştur"}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
      
      <Tabs defaultValue="playlists">
        <TabsList className="mb-6">
          <TabsTrigger value="playlists" className="flex items-center">
            <ListMusic className="h-4 w-4 mr-2" />
            Çalma Listeleri
          </TabsTrigger>
          <TabsTrigger value="liked" className="flex items-center">
            <Heart className="h-4 w-4 mr-2" />
            Beğendiklerim
          </TabsTrigger>
          <TabsTrigger value="recent" className="flex items-center">
            <Clock className="h-4 w-4 mr-2" />
            Son Çalınanlar
          </TabsTrigger>
        </TabsList>
        
        <TabsContent value="playlists">
          {playlists.length > 0 ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
              {playlists.map((playlist: any) => (
                <PlaylistCard 
                  key={playlist.id} 
                  playlist={playlist} 
                  onPlay={handlePlayPlaylist}
                />
              ))}
            </div>
          ) : (
            <div className="text-center py-10 bg-card rounded-md">
              <ListMusic className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
              <h3 className="text-lg font-medium mb-2">Henüz çalma listeniz yok</h3>
              <p className="text-muted-foreground mb-4 max-w-md mx-auto">
                "Çalma Listesi Oluştur" butonuna tıklayarak ilk çalma listenizi oluşturabilirsiniz.
              </p>
              <Button onClick={() => setIsCreateDialogOpen(true)}>
                <Plus className="h-4 w-4 mr-2" />
                Çalma Listesi Oluştur
              </Button>
            </div>
          )}
        </TabsContent>
        
        <TabsContent value="liked">
          {likedTracks.length > 0 ? (
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4">
              {likedTracks.map((track: any) => (
                <TrackCard key={track.id} track={track} />
              ))}
            </div>
          ) : (
            <div className="text-center py-10 bg-card rounded-md">
              <Heart className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
              <h3 className="text-lg font-medium mb-2">Henüz beğendiğiniz şarkı yok</h3>
              <p className="text-muted-foreground mb-4 max-w-md mx-auto">
                Şarkıları beğenmek için şarkı çalarken kalp simgesine tıklayabilirsiniz.
              </p>
              <Button variant="outline">
                <Search className="h-4 w-4 mr-2" />
                Müzik Keşfet
              </Button>
            </div>
          )}
        </TabsContent>
        
        <TabsContent value="recent">
          {recentTracks.length > 0 ? (
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4">
              {recentTracks.map((track: any) => (
                <TrackCard key={track.id} track={track} />
              ))}
            </div>
          ) : (
            <div className="text-center py-10 bg-card rounded-md">
              <Clock className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
              <h3 className="text-lg font-medium mb-2">Henüz çaldığınız şarkı yok</h3>
              <p className="text-muted-foreground mb-4 max-w-md mx-auto">
                Müzik dinlemeye başladığınızda, son çalınanlar burada görünecek.
              </p>
              <Button variant="outline">
                <Search className="h-4 w-4 mr-2" />
                Müzik Keşfet
              </Button>
            </div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}
