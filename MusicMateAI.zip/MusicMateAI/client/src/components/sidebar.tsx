import React from "react";
import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { 
  Home, 
  Search, 
  History, 
  Heart, 
  Library, 
  Bot, 
  BarChart3, 
  Settings, 
  Menu, 
  X 
} from "lucide-react";
import { ScrollArea } from "@/components/ui/scroll-area";
import { cn } from "@/lib/utils";

interface SidebarProps {
  user: any;
  isOpen: boolean;
  onClose: () => void;
  className?: string;
}

export function Sidebar({ user, isOpen, onClose, className }: SidebarProps) {
  const [location] = useLocation();
  
  return (
    <aside 
      className={cn(
        "bg-dark-200 transition-all duration-300 ease-in-out h-screen overflow-hidden",
        isOpen ? "block w-full fixed inset-0 z-50 md:relative md:w-64" : "hidden md:block md:w-64",
        className
      )}
    >
      <ScrollArea className="h-full">
        <div className="p-6">
          {/* Mobile Close Button */}
          <div className="flex md:hidden justify-end mb-4">
            <Button variant="ghost" size="icon" onClick={onClose} className="text-light-300 hover:text-light-100">
              <X size={24} />
            </Button>
          </div>
          
          {/* Logo */}
          <div className="flex items-center mb-8">
            <div className="h-10 w-10 bg-primary rounded-md flex items-center justify-center mr-3">
              <svg viewBox="0 0 24 24" className="h-6 w-6 text-white" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="M9 19V6l12-3v13M9 19c0 1.105-1.343 2-3 2s-3-.895-3-2 1.343-2 3-2 3 .895 3 2zm12-3c0 1.105-1.343 2-3 2s-3-.895-3-2 1.343-2 3-2 3 .895 3 2zM9 10l12-3" />
              </svg>
            </div>
            <h1 className="font-heading font-bold text-xl">MusicAI</h1>
          </div>
          
          {/* Navigation */}
          <nav className="space-y-6">
            {/* Main Navigation */}
            <div className="space-y-1">
              <Link href="/">
                <a className={cn(
                  "flex items-center text-light-100 py-2 px-4 rounded-md transition-colors",
                  location === "/" ? "bg-dark-100" : "hover:bg-dark-100"
                )}>
                  <Home className="mr-3" size={20} />
                  <span>Home</span>
                </a>
              </Link>
              <Link href="/search">
                <a className={cn(
                  "flex items-center text-light-100 py-2 px-4 rounded-md transition-colors",
                  location === "/search" ? "bg-dark-100" : "hover:bg-dark-100"
                )}>
                  <Search className="mr-3" size={20} />
                  <span>Search</span>
                </a>
              </Link>
            </div>
            
            {/* Library Section */}
            <div>
              <h3 className="text-light-300 uppercase font-medium text-xs tracking-wider mb-2 px-4">Your Library</h3>
              <div className="space-y-1">
                <Link href="/recent">
                  <a className={cn(
                    "flex items-center text-light-300 hover:text-light-100 py-2 px-4 rounded-md transition-colors",
                    location === "/recent" ? "bg-dark-100 text-light-100" : "hover:bg-dark-100"
                  )}>
                    <History className="mr-3" size={20} />
                    <span>Recently Played</span>
                  </a>
                </Link>
                <Link href="/favorites">
                  <a className={cn(
                    "flex items-center text-light-300 hover:text-light-100 py-2 px-4 rounded-md transition-colors",
                    location === "/favorites" ? "bg-dark-100 text-light-100" : "hover:bg-dark-100"
                  )}>
                    <Heart className="mr-3" size={20} />
                    <span>Favorites</span>
                  </a>
                </Link>
                <Link href="/playlists">
                  <a className={cn(
                    "flex items-center text-light-300 hover:text-light-100 py-2 px-4 rounded-md transition-colors",
                    location === "/playlists" ? "bg-dark-100 text-light-100" : "hover:bg-dark-100"
                  )}>
                    <Library className="mr-3" size={20} />
                    <span>Your Playlists</span>
                  </a>
                </Link>
              </div>
            </div>
            
            {/* AI Section */}
            <div>
              <h3 className="text-light-300 uppercase font-medium text-xs tracking-wider mb-2 px-4">AI Assistant</h3>
              <div className="space-y-1">
                <Link href="/ai-chat">
                  <a className={cn(
                    "flex items-center text-light-300 hover:text-light-100 py-2 px-4 rounded-md transition-colors",
                    location === "/ai-chat" ? "bg-dark-100 text-light-100" : "hover:bg-dark-100"
                  )}>
                    <Bot className="mr-3 text-secondary" size={20} />
                    <span>AI Chat</span>
                  </a>
                </Link>
                <Link href="/recommendations">
                  <a className={cn(
                    "flex items-center text-light-300 hover:text-light-100 py-2 px-4 rounded-md transition-colors",
                    location === "/recommendations" ? "bg-dark-100 text-light-100" : "hover:bg-dark-100"
                  )}>
                    <BarChart3 className="mr-3" size={20} />
                    <span>Music Recommendations</span>
                  </a>
                </Link>
              </div>
            </div>
          </nav>
        </div>
        
        {/* User Profile */}
        <div className="mt-auto p-6 border-t border-dark-100">
          <Link href="/settings">
            <a className={cn(
              "flex items-center text-light-300 hover:text-light-100 py-2 px-4 rounded-md transition-colors",
              location === "/settings" ? "bg-dark-100 text-light-100" : "hover:bg-dark-100"
            )}>
              <Settings className="mr-3" size={20} />
              <span>Settings</span>
            </a>
          </Link>
          
          {user ? (
            <div className="flex items-center mt-4 px-4">
              <div className="h-8 w-8 rounded-full bg-primary flex items-center justify-center">
                {user.profilePicture ? (
                  <img src={user.profilePicture} alt={user.name} className="h-8 w-8 rounded-full" />
                ) : (
                  <span className="font-medium text-sm text-white">
                    {user.name ? user.name.charAt(0).toUpperCase() : user.username.charAt(0).toUpperCase()}
                  </span>
                )}
              </div>
              <span className="ml-3 font-medium truncate">{user.name || user.username}</span>
            </div>
          ) : (
            <Button variant="outline" className="mt-4 w-full" onClick={onClose}>
              Sign In
            </Button>
          )}
        </div>
      </ScrollArea>
    </aside>
  );
}

export function MobileMenuButton({ onClick }: { onClick: () => void }) {
  return (
    <Button variant="ghost" size="icon" onClick={onClick} className="md:hidden text-light-200 hover:text-light-100">
      <Menu size={24} />
    </Button>
  );
}
