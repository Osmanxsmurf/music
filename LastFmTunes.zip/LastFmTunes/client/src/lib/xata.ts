import { apiRequest } from "./queryClient";
import { LOCAL_STORAGE_KEYS } from "./constants";
import { Song, AiMessage } from "@shared/schema";
import { getStoredData, setStoredData } from "./localStorage";

// Function to get song by ID (with offline support)
export async function fetchSong(id: number): Promise<Song | null> {
  try {
    // Try to get from API
    const response = await apiRequest('GET', `/api/songs/${id}`, undefined);
    const song = await response.json();
    return song;
  } catch (error) {
    console.error('Error fetching song from API, trying local storage', error);
    
    // Fallback to local storage
    const songs = await getStoredData<Song[]>(LOCAL_STORAGE_KEYS.SONGS, []);
    return songs.find(s => s.id === id) || null;
  }
}

// Function to get all songs (with offline support)
export async function fetchAllSongs(): Promise<Song[]> {
  try {
    // Try to get from API
    const response = await apiRequest('GET', '/api/songs', undefined);
    const songs = await response.json();
    
    // Update cache
    await setStoredData(LOCAL_STORAGE_KEYS.SONGS, songs);
    
    return songs;
  } catch (error) {
    console.error('Error fetching songs from API, using local storage', error);
    
    // Fallback to local storage
    return getStoredData<Song[]>(LOCAL_STORAGE_KEYS.SONGS, []);
  }
}

// Function to get songs by mood (with offline support)
export async function fetchSongsByMood(mood: string): Promise<Song[]> {
  try {
    // Try to get from API
    const response = await apiRequest('GET', `/api/songs/mood/${mood}`, undefined);
    const songs = await response.json();
    return songs;
  } catch (error) {
    console.error('Error fetching songs by mood from API, filtering from local storage', error);
    
    // Fallback to local storage and filter by mood
    const songs = await getStoredData<Song[]>(LOCAL_STORAGE_KEYS.SONGS, []);
    return songs.filter(song => song.mood && song.mood.includes(mood));
  }
}

// Function to get user's liked songs
export async function fetchLikedSongs(userId: number): Promise<Song[]> {
  try {
    // Try to get from API
    const response = await apiRequest('GET', `/api/users/${userId}/liked-songs`, undefined);
    const songs = await response.json();
    
    // Update cache
    await setStoredData(LOCAL_STORAGE_KEYS.LIKED_SONGS, songs);
    
    return songs;
  } catch (error) {
    console.error('Error fetching liked songs from API, using local storage', error);
    
    // Fallback to local storage
    return getStoredData<Song[]>(LOCAL_STORAGE_KEYS.LIKED_SONGS, []);
  }
}

// Function to get user's recently played songs
export async function fetchRecentlyPlayed(userId: number, limit?: number): Promise<Song[]> {
  try {
    // Try to get from API
    const url = limit ? `/api/users/${userId}/recently-played?limit=${limit}` : `/api/users/${userId}/recently-played`;
    const response = await apiRequest('GET', url, undefined);
    const songs = await response.json();
    
    // Update cache
    await setStoredData(LOCAL_STORAGE_KEYS.RECENTLY_PLAYED, songs);
    
    return songs;
  } catch (error) {
    console.error('Error fetching recently played from API, using local storage', error);
    
    // Fallback to local storage
    const songs = await getStoredData<Song[]>(LOCAL_STORAGE_KEYS.RECENTLY_PLAYED, []);
    return limit ? songs.slice(0, limit) : songs;
  }
}

// Function to add a song to recently played
export async function addToRecentlyPlayed(userId: number, songId: number): Promise<void> {
  try {
    // API call
    await apiRequest('POST', `/api/users/${userId}/recently-played`, { songId });
    
    // Update local cache
    const song = await fetchSong(songId);
    if (song) {
      const recentlyPlayed = await getStoredData<Song[]>(LOCAL_STORAGE_KEYS.RECENTLY_PLAYED, []);
      
      // Remove if already exists
      const filtered = recentlyPlayed.filter(s => s.id !== songId);
      
      // Add to beginning
      filtered.unshift(song);
      
      // Keep only last 20
      const updated = filtered.slice(0, 20);
      
      await setStoredData(LOCAL_STORAGE_KEYS.RECENTLY_PLAYED, updated);
    }
  } catch (error) {
    console.error('Error adding to recently played, falling back to local only', error);
    
    // Fallback to local-only update
    const song = await fetchSong(songId);
    if (song) {
      const recentlyPlayed = await getStoredData<Song[]>(LOCAL_STORAGE_KEYS.RECENTLY_PLAYED, []);
      const filtered = recentlyPlayed.filter(s => s.id !== songId);
      filtered.unshift(song);
      await setStoredData(LOCAL_STORAGE_KEYS.RECENTLY_PLAYED, filtered.slice(0, 20));
    }
  }
}

// Function to like a song
export async function likeSong(userId: number, songId: number): Promise<void> {
  try {
    // API call
    await apiRequest('POST', `/api/users/${userId}/liked-songs`, { songId });
    
    // Update local cache
    const song = await fetchSong(songId);
    if (song) {
      const likedSongs = await getStoredData<Song[]>(LOCAL_STORAGE_KEYS.LIKED_SONGS, []);
      if (!likedSongs.some(s => s.id === songId)) {
        likedSongs.unshift(song);
        await setStoredData(LOCAL_STORAGE_KEYS.LIKED_SONGS, likedSongs);
      }
    }
  } catch (error) {
    console.error('Error liking song, falling back to local only', error);
    
    // Fallback to local-only update
    const song = await fetchSong(songId);
    if (song) {
      const likedSongs = await getStoredData<Song[]>(LOCAL_STORAGE_KEYS.LIKED_SONGS, []);
      if (!likedSongs.some(s => s.id === songId)) {
        likedSongs.unshift(song);
        await setStoredData(LOCAL_STORAGE_KEYS.LIKED_SONGS, likedSongs);
      }
    }
  }
}

// Function to unlike a song
export async function unlikeSong(userId: number, songId: number): Promise<void> {
  try {
    // API call
    await apiRequest('DELETE', `/api/users/${userId}/liked-songs/${songId}`, undefined);
    
    // Update local cache
    const likedSongs = await getStoredData<Song[]>(LOCAL_STORAGE_KEYS.LIKED_SONGS, []);
    const updated = likedSongs.filter(s => s.id !== songId);
    await setStoredData(LOCAL_STORAGE_KEYS.LIKED_SONGS, updated);
  } catch (error) {
    console.error('Error unliking song, falling back to local only', error);
    
    // Fallback to local-only update
    const likedSongs = await getStoredData<Song[]>(LOCAL_STORAGE_KEYS.LIKED_SONGS, []);
    const updated = likedSongs.filter(s => s.id !== songId);
    await setStoredData(LOCAL_STORAGE_KEYS.LIKED_SONGS, updated);
  }
}

// Function to fetch chat history
export async function fetchChatHistory(userId: number = 1, limit?: number): Promise<AiMessage[]> {
  try {
    // API call
    const url = limit 
      ? `/api/users/${userId}/chat-history?limit=${limit}`
      : `/api/users/${userId}/chat-history`;
    
    const response = await apiRequest('GET', url, undefined);
    return await response.json();
  } catch (error) {
    console.error('Error fetching chat history:', error);
    return [];
  }
}

// Function to send a chat message and get response
export async function sendChatMessage(message: string, userId: number = 1): Promise<{ 
  message: AiMessage, 
  recommendations: Song[] 
}> {
  try {
    // API call
    const response = await apiRequest('POST', `/api/users/${userId}/chat`, { message });
    return await response.json();
  } catch (error) {
    console.error('Error sending chat message:', error);
    throw error;
  }
}
