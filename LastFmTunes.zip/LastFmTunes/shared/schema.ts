import { pgTable, text, serial, integer, boolean, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: text("id").primaryKey(), // Replit Auth kullanacağımız için string ID
  email: text("email").unique(),
  firstName: text("first_name"),
  lastName: text("last_name"),
  profileImageUrl: text("profile_image_url"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
  lastLogin: timestamp("last_login").defaultNow(),
  preferences: jsonb("preferences"),  // Kullanıcı tercihleri JSON olarak saklanacak
  totalListenTime: integer("total_listen_time").default(0),  // Dinleme istatistikleri (dakika)
  memberSince: timestamp("member_since").defaultNow(),
});

export const songs = pgTable("songs", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  artist: text("artist").notNull(),
  album: text("album"),
  coverImage: text("cover_image"),
  genre: text("genre"),
  mood: text("mood").array(),
  duration: integer("duration"),
  audioUrl: text("audio_url"),
  year: integer("year"),
  likeCount: integer("like_count").default(0),
  playCount: integer("play_count").default(0),
  // YouTube'dan şarkı çalabilmek için ekstra alanlar
  youtubeId: text("youtube_id"),
  youtubeUrl: text("youtube_url"),
});

export const playlists = pgTable("playlists", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  name: text("name").notNull(),
  description: text("description"),
  coverImage: text("cover_image"),
  isPublic: boolean("is_public").default(true),
  createdAt: timestamp("created_at").defaultNow(),
});

export const playlistSongs = pgTable("playlist_songs", {
  id: serial("id").primaryKey(),
  playlistId: integer("playlist_id").references(() => playlists.id),
  songId: integer("song_id").references(() => songs.id),
  position: integer("position"),
  addedAt: timestamp("added_at").defaultNow(),
});

export const userLikedSongs = pgTable("user_liked_songs", {
  id: serial("id").primaryKey(),
  userId: text("user_id").references(() => users.id),
  songId: integer("song_id").references(() => songs.id),
  likedAt: timestamp("liked_at").defaultNow(),
});

export const userRecentlyPlayed = pgTable("user_recently_played", {
  id: serial("id").primaryKey(),
  userId: text("user_id").references(() => users.id),
  songId: integer("song_id").references(() => songs.id),
  playedAt: timestamp("played_at").defaultNow(),
});

export const aiMessages = pgTable("ai_messages", {
  id: serial("id").primaryKey(),
  userId: text("user_id").references(() => users.id),
  role: text("role").notNull(), // 'user' or 'assistant'
  content: text("content").notNull(),
  timestamp: timestamp("timestamp").defaultNow(),
});

// Types
export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  profilePicture: true,
});

export const insertSongSchema = createInsertSchema(songs);

export const insertPlaylistSchema = createInsertSchema(playlists, {
  userId: z.number(),
  name: z.string(),
  description: z.string().optional(),
  coverImage: z.string().optional(),
  isPublic: z.boolean().default(true)
});

export const insertPlaylistSongSchema = createInsertSchema(playlistSongs).pick({
  playlistId: true,
  songId: true,
  position: true,
});

export const insertUserLikedSongSchema = createInsertSchema(userLikedSongs).pick({
  userId: true,
  songId: true,
});

export const insertUserRecentlyPlayedSchema = createInsertSchema(userRecentlyPlayed).pick({
  userId: true,
  songId: true,
});

export const insertAiMessageSchema = createInsertSchema(aiMessages).pick({
  userId: true,
  role: true,
  content: true,
});

// Export types
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type InsertSong = z.infer<typeof insertSongSchema>;
export type Song = typeof songs.$inferSelect;

export type InsertPlaylist = z.infer<typeof insertPlaylistSchema>;
export type Playlist = typeof playlists.$inferSelect;

export type InsertPlaylistSong = z.infer<typeof insertPlaylistSongSchema>;
export type PlaylistSong = typeof playlistSongs.$inferSelect;

export type InsertUserLikedSong = z.infer<typeof insertUserLikedSongSchema>;
export type UserLikedSong = typeof userLikedSongs.$inferSelect;

export type InsertUserRecentlyPlayed = z.infer<typeof insertUserRecentlyPlayedSchema>;
export type UserRecentlyPlayed = typeof userRecentlyPlayed.$inferSelect;

export type InsertAiMessage = z.infer<typeof insertAiMessageSchema>;
export type AiMessage = typeof aiMessages.$inferSelect;
