import { 
  users, type User, type InsertUser,
  tracks, type Track, type InsertTrack,
  playlists, type Playlist, type InsertPlaylist,
  playlistTracks, type PlaylistTrack, type InsertPlaylistTrack,
  likedTracks, type LikedTrack, type InsertLikedTrack,
  recentlyPlayed, type RecentlyPlayed, type InsertRecentlyPlayed,
  chatMessages, type ChatMessage, type InsertChatMessage
} from "@shared/schema";
import bcrypt from "bcryptjs";

export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Track methods
  getTrack(id: number): Promise<Track | undefined>;
  getTrackByLastFMId(lastfmId: string): Promise<Track | undefined>;
  createTrack(track: InsertTrack): Promise<Track>;
  searchTracks(query: string): Promise<Track[]>;
  
  // Playlist methods
  getPlaylist(id: number): Promise<Playlist | undefined>;
  getUserPlaylists(userId: number): Promise<Playlist[]>;
  createPlaylist(playlist: InsertPlaylist): Promise<Playlist>;
  updatePlaylist(id: number, playlist: Partial<InsertPlaylist>): Promise<Playlist | undefined>;
  deletePlaylist(id: number): Promise<boolean>;
  
  // Playlist track methods
  getPlaylistTracks(playlistId: number): Promise<Track[]>;
  addTrackToPlaylist(playlistTrack: InsertPlaylistTrack): Promise<PlaylistTrack>;
  removeTrackFromPlaylist(playlistId: number, trackId: number): Promise<boolean>;
  
  // Liked tracks methods
  getLikedTracks(userId: number): Promise<Track[]>;
  isTrackLiked(userId: number, trackId: number): Promise<boolean>;
  likeTrack(likedTrack: InsertLikedTrack): Promise<LikedTrack>;
  unlikeTrack(userId: number, trackId: number): Promise<boolean>;
  
  // Recently played methods
  getRecentlyPlayed(userId: number, limit?: number): Promise<Track[]>;
  addRecentlyPlayed(recentlyPlayed: InsertRecentlyPlayed): Promise<RecentlyPlayed>;
  
  // Chat methods
  getUserChatMessages(userId: string): Promise<ChatMessage[]>;
  addChatMessage(chatMessage: InsertChatMessage): Promise<ChatMessage>;
  deleteChatMessage(id: number): Promise<boolean>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private tracks: Map<number, Track>;
  private playlists: Map<number, Playlist>;
  private playlistTracks: Map<number, PlaylistTrack>;
  private likedTracks: Map<number, LikedTrack>;
  private recentlyPlayed: Map<number, RecentlyPlayed>;
  private chatMessages: Map<number, ChatMessage>;
  
  private userId: number;
  private trackId: number;
  private playlistId: number;
  private playlistTrackId: number;
  private likedTrackId: number;
  private recentlyPlayedId: number;
  private chatMessageId: number;

  constructor() {
    this.users = new Map();
    this.tracks = new Map();
    this.playlists = new Map();
    this.playlistTracks = new Map();
    this.likedTracks = new Map();
    this.recentlyPlayed = new Map();
    this.chatMessages = new Map();
    
    this.userId = 1;
    this.trackId = 1;
    this.playlistId = 1;
    this.playlistTrackId = 1;
    this.likedTrackId = 1;
    this.recentlyPlayedId = 1;
    this.chatMessageId = 1;
    
    // Initialize with demo data
    this.initDemoData();
  }

  private async initDemoData() {
    // Create a demo user
    const demoUser: InsertUser = {
      username: "demo",
      password: await bcrypt.hash("demo123", 10),
      fullName: "Ahmet Yılmaz",
      email: "demo@example.com",
      profilePicture: null
    };
    this.createUser(demoUser);
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username.toLowerCase() === username.toLowerCase()
    );
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.email.toLowerCase() === email.toLowerCase()
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userId++;
    const createdAt = new Date();
    const user: User = { ...insertUser, id, createdAt };
    this.users.set(id, user);
    return user;
  }

  // Track methods
  async getTrack(id: number): Promise<Track | undefined> {
    return this.tracks.get(id);
  }

  async getTrackByLastFMId(lastfmId: string): Promise<Track | undefined> {
    return Array.from(this.tracks.values()).find(
      (track) => track.lastfmId === lastfmId
    );
  }

  async createTrack(insertTrack: InsertTrack): Promise<Track> {
    const id = this.trackId++;
    const track: Track = { ...insertTrack, id };
    this.tracks.set(id, track);
    return track;
  }

  async searchTracks(query: string): Promise<Track[]> {
    const lowerQuery = query.toLowerCase();
    return Array.from(this.tracks.values()).filter(
      (track) => 
        track.title.toLowerCase().includes(lowerQuery) ||
        track.artist.toLowerCase().includes(lowerQuery) ||
        (track.album && track.album.toLowerCase().includes(lowerQuery))
    );
  }

  // Playlist methods
  async getPlaylist(id: number): Promise<Playlist | undefined> {
    return this.playlists.get(id);
  }

  async getUserPlaylists(userId: number): Promise<Playlist[]> {
    return Array.from(this.playlists.values()).filter(
      (playlist) => playlist.userId === userId
    );
  }

  async createPlaylist(insertPlaylist: InsertPlaylist): Promise<Playlist> {
    const id = this.playlistId++;
    const createdAt = new Date();
    const playlist: Playlist = { ...insertPlaylist, id, createdAt };
    this.playlists.set(id, playlist);
    return playlist;
  }

  async updatePlaylist(id: number, playlistData: Partial<InsertPlaylist>): Promise<Playlist | undefined> {
    const playlist = this.playlists.get(id);
    if (!playlist) return undefined;
    
    const updatedPlaylist = { ...playlist, ...playlistData };
    this.playlists.set(id, updatedPlaylist);
    return updatedPlaylist;
  }

  async deletePlaylist(id: number): Promise<boolean> {
    const deleted = this.playlists.delete(id);
    if (deleted) {
      // Delete all playlist tracks associated with this playlist
      const playlistTracksToDelete = Array.from(this.playlistTracks.values())
        .filter(pt => pt.playlistId === id);
      
      for (const pt of playlistTracksToDelete) {
        this.playlistTracks.delete(pt.id);
      }
    }
    return deleted;
  }

  // Playlist track methods
  async getPlaylistTracks(playlistId: number): Promise<Track[]> {
    const playlistTrackEntries = Array.from(this.playlistTracks.values())
      .filter(pt => pt.playlistId === playlistId)
      .sort((a, b) => a.position - b.position);
    
    const tracks: Track[] = [];
    for (const pt of playlistTrackEntries) {
      const track = this.tracks.get(pt.trackId);
      if (track) tracks.push(track);
    }
    
    return tracks;
  }

  async addTrackToPlaylist(insertPlaylistTrack: InsertPlaylistTrack): Promise<PlaylistTrack> {
    const id = this.playlistTrackId++;
    const playlistTrack: PlaylistTrack = { ...insertPlaylistTrack, id };
    this.playlistTracks.set(id, playlistTrack);
    
    // Update playlist track count and duration
    const playlist = this.playlists.get(insertPlaylistTrack.playlistId);
    const track = this.tracks.get(insertPlaylistTrack.trackId);
    
    if (playlist && track) {
      const updatedPlaylist = { 
        ...playlist, 
        trackCount: (playlist.trackCount || 0) + 1,
        duration: (playlist.duration || 0) + (track.duration || 0)
      };
      this.playlists.set(playlist.id, updatedPlaylist);
    }
    
    return playlistTrack;
  }

  async removeTrackFromPlaylist(playlistId: number, trackId: number): Promise<boolean> {
    const playlistTrackEntry = Array.from(this.playlistTracks.values())
      .find(pt => pt.playlistId === playlistId && pt.trackId === trackId);
    
    if (!playlistTrackEntry) return false;
    
    const deleted = this.playlistTracks.delete(playlistTrackEntry.id);
    if (deleted) {
      // Update playlist track count and duration
      const playlist = this.playlists.get(playlistId);
      const track = this.tracks.get(trackId);
      
      if (playlist && track) {
        const updatedPlaylist = { 
          ...playlist, 
          trackCount: Math.max(0, (playlist.trackCount || 0) - 1),
          duration: Math.max(0, (playlist.duration || 0) - (track.duration || 0))
        };
        this.playlists.set(playlist.id, updatedPlaylist);
      }
      
      // Reorder remaining tracks
      const remainingTracks = Array.from(this.playlistTracks.values())
        .filter(pt => pt.playlistId === playlistId)
        .sort((a, b) => a.position - b.position);
      
      remainingTracks.forEach((pt, index) => {
        const updated = { ...pt, position: index };
        this.playlistTracks.set(pt.id, updated);
      });
    }
    
    return deleted;
  }

  // Liked tracks methods
  async getLikedTracks(userId: number): Promise<Track[]> {
    const likedTrackEntries = Array.from(this.likedTracks.values())
      .filter(lt => lt.userId === userId)
      .sort((a, b) => b.likedAt.getTime() - a.likedAt.getTime());
    
    const tracks: Track[] = [];
    for (const lt of likedTrackEntries) {
      const track = this.tracks.get(lt.trackId);
      if (track) tracks.push(track);
    }
    
    return tracks;
  }

  async isTrackLiked(userId: number, trackId: number): Promise<boolean> {
    return Array.from(this.likedTracks.values())
      .some(lt => lt.userId === userId && lt.trackId === trackId);
  }

  async likeTrack(insertLikedTrack: InsertLikedTrack): Promise<LikedTrack> {
    // Check if already liked
    const existing = Array.from(this.likedTracks.values())
      .find(lt => lt.userId === insertLikedTrack.userId && lt.trackId === insertLikedTrack.trackId);
    
    if (existing) return existing;
    
    const id = this.likedTrackId++;
    const likedAt = new Date();
    const likedTrack: LikedTrack = { ...insertLikedTrack, id, likedAt };
    this.likedTracks.set(id, likedTrack);
    return likedTrack;
  }

  async unlikeTrack(userId: number, trackId: number): Promise<boolean> {
    const likedTrackEntry = Array.from(this.likedTracks.values())
      .find(lt => lt.userId === userId && lt.trackId === trackId);
    
    if (!likedTrackEntry) return false;
    
    return this.likedTracks.delete(likedTrackEntry.id);
  }

  // Recently played methods
  async getRecentlyPlayed(userId: number, limit: number = 10): Promise<Track[]> {
    const recentlyPlayedEntries = Array.from(this.recentlyPlayed.values())
      .filter(rp => rp.userId === userId)
      .sort((a, b) => b.playedAt.getTime() - a.playedAt.getTime())
      .slice(0, limit);
    
    const tracks: Track[] = [];
    for (const rp of recentlyPlayedEntries) {
      const track = this.tracks.get(rp.trackId);
      if (track) tracks.push(track);
    }
    
    return tracks;
  }

  async addRecentlyPlayed(insertRecentlyPlayed: InsertRecentlyPlayed): Promise<RecentlyPlayed> {
    const id = this.recentlyPlayedId++;
    const playedAt = new Date();
    const recentlyPlayed: RecentlyPlayed = { ...insertRecentlyPlayed, id, playedAt };
    this.recentlyPlayed.set(id, recentlyPlayed);
    return recentlyPlayed;
  }

  // Chat methods
  async getUserChatMessages(userId: string): Promise<ChatMessage[]> {
    return Array.from(this.chatMessages.values())
      .filter(cm => cm.userId === userId)
      .sort((a, b) => a.timestamp.getTime() - b.timestamp.getTime());
  }

  async addChatMessage(insertChatMessage: InsertChatMessage): Promise<ChatMessage> {
    const id = this.chatMessageId++;
    const timestamp = new Date();
    const chatMessage: ChatMessage = { ...insertChatMessage, id, timestamp };
    this.chatMessages.set(id, chatMessage);
    return chatMessage;
  }
  
  async deleteChatMessage(id: number): Promise<boolean> {
    if (this.chatMessages.has(id)) {
      this.chatMessages.delete(id);
      return true;
    }
    return false;
  }
}

export const storage = new MemStorage();
