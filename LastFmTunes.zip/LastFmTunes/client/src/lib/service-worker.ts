import { PWA_CACHE_NAME } from './constants';

// Register the service worker
export async function registerServiceWorker(): Promise<{
  success: boolean;
  error?: Error;
  registration?: ServiceWorkerRegistration;
}> {
  if (!('serviceWorker' in navigator)) {
    return {
      success: false,
      error: new Error('Service worker is not supported in this browser')
    };
  }
  
  try {
    const registration = await navigator.serviceWorker.register('/service-worker.js');
    
    console.log('Service worker registered successfully:', registration);
    
    return {
      success: true,
      registration
    };
  } catch (error) {
    console.error('Service worker registration failed:', error);
    
    return {
      success: false,
      error: error instanceof Error ? error : new Error('Unknown error during service worker registration')
    };
  }
}

// Check if the app is installed (PWA)
export function isAppInstalled(): boolean {
  return window.matchMedia('(display-mode: standalone)').matches || 
         (window.navigator as any).standalone === true;
}

// Show the PWA installation prompt
export function showInstallPrompt(): Promise<boolean> {
  return new Promise(resolve => {
    const deferredPrompt = (window as any).deferredPrompt;
    
    if (!deferredPrompt) {
      console.log('Installation prompt not available');
      resolve(false);
      return;
    }
    
    // Show the install prompt
    deferredPrompt.prompt();
    
    // Wait for the user to respond to the prompt
    deferredPrompt.userChoice.then((choiceResult: { outcome: string }) => {
      if (choiceResult.outcome === 'accepted') {
        console.log('User accepted the install prompt');
        resolve(true);
      } else {
        console.log('User dismissed the install prompt');
        resolve(false);
      }
      
      // Clear the deferred prompt
      (window as any).deferredPrompt = null;
    });
  });
}

// Check for service worker updates
export async function checkForUpdates(): Promise<boolean> {
  if (!('serviceWorker' in navigator)) {
    return false;
  }
  
  try {
    const registration = await navigator.serviceWorker.getRegistration();
    
    if (!registration) {
      return false;
    }
    
    await registration.update();
    return true;
  } catch (error) {
    console.error('Error checking for service worker updates:', error);
    return false;
  }
}

// Manually clear the cache (useful for forcing fresh content)
export async function clearCache(): Promise<boolean> {
  if (!('caches' in window)) {
    return false;
  }
  
  try {
    await caches.delete(PWA_CACHE_NAME);
    console.log('Cache cleared successfully');
    return true;
  } catch (error) {
    console.error('Error clearing cache:', error);
    return false;
  }
}

// Check if the app is currently offline
export function isOffline(): boolean {
  return !navigator.onLine;
}

// Add event listeners for online/offline events
export function setupConnectivityListeners(
  onlineCallback: () => void,
  offlineCallback: () => void
): () => void {
  const handleOnline = () => {
    console.log('App is online');
    onlineCallback();
  };
  
  const handleOffline = () => {
    console.log('App is offline');
    offlineCallback();
  };
  
  window.addEventListener('online', handleOnline);
  window.addEventListener('offline', handleOffline);
  
  // Return a function to remove the event listeners
  return () => {
    window.removeEventListener('online', handleOnline);
    window.removeEventListener('offline', handleOffline);
  };
}
