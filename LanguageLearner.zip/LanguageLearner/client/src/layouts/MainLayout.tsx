import { ReactNode, useEffect } from "react";
import { useLocation } from "wouter";
import Header from "@/components/Header";
import Sidebar from "@/components/Sidebar";
import MobileNav from "@/components/MobileNav";
import MusicPlayer from "@/components/MusicPlayer";
import { useAuth } from "@/contexts/AuthContext";

type MainLayoutProps = {
  children: ReactNode;
};

export default function MainLayout({ children }: MainLayoutProps) {
  const [location, navigate] = useLocation();
  const { isAuthenticated, isLoading } = useAuth();
  
  // Check if the user is authenticated and redirect if needed
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      navigate("/login");
    }
  }, [isAuthenticated, isLoading, navigate]);

  if (isLoading) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-background">
        <div className="flex flex-col items-center space-y-4">
          <div className="h-10 w-10 animate-spin rounded-full border-4 border-primary border-t-transparent" />
          <p className="text-foreground">Yükleniyor...</p>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return null; // Will redirect to login
  }

  return (
    <div className="flex flex-col min-h-screen bg-background">
      <Header />
      
      <div className="flex flex-1 overflow-hidden">
        <Sidebar activeRoute={location} />
        
        <main className="flex-1 overflow-y-auto scrollbar-hide bg-gradient-to-b from-muted to-background relative pb-28 md:pb-24">
          {children}
        </main>
      </div>
      
      <MobileNav activeRoute={location} />
      <MusicPlayer />
    </div>
  );
}
