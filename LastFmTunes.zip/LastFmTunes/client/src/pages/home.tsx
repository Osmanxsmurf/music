import React, { useState, useEffect } from 'react';
import { RecommendationEngine } from '@/components/RecommendationEngine';
import { FeaturedPlaylist } from '@/components/FeaturedPlaylist';
import { MoodSelector } from '@/components/MoodSelector';
import { SongCard } from '@/components/SongCard';
import { useToast } from '@/hooks/use-toast';
import { FEATURED_PLAYLISTS } from '@/lib/constants';
import { fetchAllSongs } from '@/lib/xata';
import { useOffline } from '@/hooks/use-offline';
import { getCachedData, CACHE_KEYS } from '@/lib/utils';
import { motion } from 'framer-motion';
import type { Song } from '@shared/schema';

const Home: React.FC = () => {
  const [selectedMood, setSelectedMood] = useState('');
  const [popularSongs, setPopularSongs] = useState<Song[]>([]);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();
  const isOffline = useOffline();
  
  useEffect(() => {
    const loadData = async () => {
      try {
        setLoading(true);
        
        // Try to get songs from API or fallback to cache
        let songs: Song[] = [];
        
        if (isOffline) {
          const cachedSongs = await getCachedData<Song[]>(CACHE_KEYS.SONGS);
          if (cachedSongs) {
            songs = cachedSongs;
          } else {
            throw new Error("You are offline and no cached songs are available");
          }
        } else {
          songs = await fetchAllSongs();
        }
        
        // Sort by popularity (in a real app, this would be a field from the API)
        const sortedSongs = [...songs].sort(() => Math.random() - 0.5).slice(0, 8);
        setPopularSongs(sortedSongs);
      } catch (error) {
        console.error('Error loading data:', error);
        
        toast({
          title: 'Failed to load content',
          description: isOffline 
            ? 'You are offline and no cached content is available' 
            : 'There was a problem loading the content. Please try again.',
          variant: 'destructive',
        });
        
        // Set empty array to avoid errors in the UI
        setPopularSongs([]);
      } finally {
        setLoading(false);
      }
    };
    
    loadData();
  }, [isOffline, toast]);
  
  // Animation variants for staggered animations
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: { 
      opacity: 1,
      transition: { 
        staggerChildren: 0.1,
        delayChildren: 0.2
      }
    }
  };
  
  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { 
      opacity: 1, 
      y: 0,
      transition: {
        type: "spring",
        stiffness: 100,
        damping: 15
      }
    }
  };
  
  return (
    <div className="py-6 px-4 md:px-6 space-y-8 animate-fade-in">
      {/* Mood Selector */}
      <MoodSelector
        onMoodSelect={setSelectedMood}
        selectedMood={selectedMood}
        className="mb-8"
      />
      
      {/* Featured Playlists */}
      <motion.div 
        className="space-y-4"
        initial="hidden"
        animate="visible"
        variants={containerVariants}
      >
        <motion.h2 
          className="text-lg font-semibold"
          variants={itemVariants}
        >
          Featured Playlists
        </motion.h2>
        
        {FEATURED_PLAYLISTS.map((playlist, index) => (
          <motion.div key={playlist.id} variants={itemVariants}>
            <FeaturedPlaylist
              title={playlist.title}
              description={playlist.description}
              imageUrl={playlist.imageUrl}
              songs={popularSongs.slice(0, 5)} // Use the first 5 songs for the playlist
              listeners={playlist.listeners}
              className="mb-6"
            />
          </motion.div>
        ))}
      </motion.div>
      
      {/* Recommendations */}
      <RecommendationEngine initialMood={selectedMood} />
      
      {/* Popular Songs */}
      <motion.div 
        className="space-y-4"
        initial="hidden"
        animate="visible"
        variants={containerVariants}
      >
        <motion.div 
          className="flex items-center justify-between"
          variants={itemVariants}
        >
          <h2 className="text-lg font-semibold">Popular Now</h2>
          <button className="text-primary hover:underline text-sm font-medium flex items-center gap-1">
            View All
          </button>
        </motion.div>
        
        {loading ? (
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            {[...Array(8)].map((_, i) => (
              <motion.div
                key={i}
                className="bg-muted rounded-lg h-[200px] animate-pulse"
                variants={itemVariants}
              />
            ))}
          </div>
        ) : (
          <motion.div 
            className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4"
            variants={containerVariants}
          >
            {popularSongs.map((song) => (
              <motion.div key={song.id} variants={itemVariants}>
                <SongCard song={song} />
              </motion.div>
            ))}
          </motion.div>
        )}
      </motion.div>
    </div>
  );
};

export default Home;
