import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { WebSocketServer } from "ws";
import { 
  insertUserSchema, 
  insertFavoriteSchema, 
  insertPlayHistorySchema, 
  insertSearchSchema, 
  insertAiChatSchema 
} from "@shared/schema";
import OpenAI from "openai";
import session from "express-session";
import passport from "passport";
import { Strategy as LocalStrategy } from "passport-local";
import bcrypt from "bcryptjs";
import MemoryStore from "memorystore";
import axios from "axios";

// Simple mood detection for music recommendations
const moodGenreMap: Record<string, string[]> = {
  "mutlu": ["Pop", "Dance", "Elektronik", "Disco"],
  "heyecanlı": ["Rock", "Metal", "Elektronik", "Hip-Hop"],
  "hüzünlü": ["Arabesk", "Klasik", "Jazz", "Halk Müziği"],
  "sakin": ["Akustik", "Klasik", "Jazz", "Türk Sanat"],
  "romantik": ["Türk Sanat", "Jazz", "R&B", "Pop"],
  "genel": ["Pop", "Rock", "Elektronik", "Hip-Hop"]
};

// Popular Turkish artists by genre
const turkishArtistsByGenre: Record<string, string[]> = {
  "Pop": ["Tarkan", "Sezen Aksu", "Mabel Matiz", "Sertab Erener", "Kenan Doğulu"],
  "Rock": ["Duman", "Şebnem Ferah", "Teoman", "maNga", "Mor ve Ötesi"],
  "Arabesk": ["Müslüm Gürses", "Orhan Gencebay", "Ferdi Tayfur", "İbrahim Tatlıses"],
  "Halk Müziği": ["Neşet Ertaş", "Barış Manço", "Selda Bağcan", "Arif Sağ"],
  "Türk Sanat": ["Zeki Müren", "Bülent Ersoy", "Müzeyyen Senar"],
  "Rap": ["Ceza", "Ezhel", "Sagopa Kajmer", "Şanışer"]
};

// Function to detect mood from message
function detectMood(message: string): string {
  // Simple keyword-based mood detection
  if (message.match(/mutlu|neşeli|sevinçli|keyifli|eğlenceli|güzel|harika/i)) return "mutlu";
  if (message.match(/heyecanlı|coşkulu|hareketli|dinamik|ateşli/i)) return "heyecanlı";
  if (message.match(/üzgün|hüzünlü|kederli|melankolik|yalnız|mutsuz|acı/i)) return "hüzünlü";
  if (message.match(/sakin|huzurlu|sessiz|dinlendirici|rahatlatıcı/i)) return "sakin";
  if (message.match(/romantik|aşk|sevgi|tutku/i)) return "romantik";
  
  // Default mood
  return "genel";
}

// Generate music recommendations based on mood
function generateMusicRecommendation(message: string): string {
  const mood = detectMood(message);
  
  // If it's a general mood, return general recommendations
  if (mood === "genel") {
    return "Müzik asistanınız olarak size yardımcı olmaktan memnuniyet duyarım! Nasıl hissettiğinizi veya ne tür müzik dinlemek istediğinizi söylerseniz, size özel öneriler sunabilirim. Örneğin 'Bugün çok mutluyum' veya 'Üzgün hissediyorum' diyebilirsiniz.";
  }
  
  // Get genres for this mood
  const genres = moodGenreMap[mood] || [];
  
  // Get artists for these genres
  const artists: string[] = [];
  genres.forEach(genre => {
    const genreArtists = turkishArtistsByGenre[genre] || [];
    artists.push(...genreArtists);
  });
  
  // Remove duplicates and limit to 5 random artists
  const uniqueArtists = Array.from(new Set(artists))
    .sort(() => 0.5 - Math.random())
    .slice(0, 5);
  
  // Format the response
  let response = `${mood.charAt(0).toUpperCase() + mood.slice(1)} hissettiğiniz için size uygun türler ve sanatçılar:\n\n`;
  
  response += "🎵 Müzik Türleri:\n";
  genres.forEach(genre => {
    response += `- ${genre}\n`;
  });
  
  response += "\n👨‍🎤 Sanatçılar:\n";
  uniqueArtists.forEach(artist => {
    response += `- ${artist}\n`;
  });
  
  response += "\nBu sanatçıların şarkılarını çalmak için üzerine tıklayabilir veya daha spesifik öneriler için bana nasıl hissettiğinizi detaylı anlatabilirsiniz.";
  
  return response;
}

export async function registerRoutes(app: Express): Promise<Server> {
  const httpServer = createServer(app);

  // Initialize WebSocket server for chat
  const wss = new WebSocketServer({ server: httpServer });

  // Setup session store
  const MemoryStoreSession = MemoryStore(session);
  
  app.use(
    session({
      secret: process.env.SESSION_SECRET || "music-ai-secret",
      resave: false,
      saveUninitialized: false,
      cookie: { secure: process.env.NODE_ENV === "production", maxAge: 86400000 }, // 1 day
      store: new MemoryStoreSession({
        checkPeriod: 86400000, // 1 day
      }),
    })
  );
  
  // Initialize passport
  app.use(passport.initialize());
  app.use(passport.session());
  
  // Configure passport local strategy
  passport.use(
    new LocalStrategy(
      {
        usernameField: "email",
        passwordField: "password",
      },
      async (email, password, done) => {
        try {
          const user = await storage.getUserByEmail(email);
          if (!user) {
            return done(null, false, { message: "Incorrect email or password" });
          }
          
          const isMatch = await bcrypt.compare(password, user.password);
          if (!isMatch) {
            return done(null, false, { message: "Incorrect email or password" });
          }
          
          return done(null, user);
        } catch (error) {
          return done(error);
        }
      }
    )
  );
  
  passport.serializeUser((user: any, done) => {
    done(null, user.id);
  });
  
  passport.deserializeUser(async (id: number, done) => {
    try {
      const user = await storage.getUser(id);
      done(null, user);
    } catch (error) {
      done(error, null);
    }
  });

  // Initialize OpenAI API (disabled - using local implementation)
  console.log("Using local AI implementation instead of OpenAI API");

  // Auth middleware
  const isAuthenticated = (req: Request, res: Response, next: Function) => {
    if (req.isAuthenticated()) {
      return next();
    }
    res.status(401).json({ message: "Unauthorized" });
  };

  // API routes
  // Authentication routes
  app.post("/api/auth/register", async (req, res) => {
    try {
      const validatedData = insertUserSchema.parse(req.body);
      
      // Check if user exists
      const existingUser = await storage.getUserByEmail(validatedData.email);
      if (existingUser) {
        return res.status(400).json({ message: "Email already in use" });
      }
      
      const existingUsername = await storage.getUserByUsername(validatedData.username);
      if (existingUsername) {
        return res.status(400).json({ message: "Username already in use" });
      }
      
      // Hash password
      const salt = await bcrypt.genSalt(10);
      const hashedPassword = await bcrypt.hash(validatedData.password, salt);
      
      // Create user
      const newUser = await storage.createUser({
        ...validatedData,
        password: hashedPassword,
      });
      
      // Remove password from response
      const { password, ...userWithoutPassword } = newUser;
      
      res.status(201).json({ 
        message: "User registered successfully", 
        user: userWithoutPassword 
      });
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  app.post("/api/auth/login", passport.authenticate("local"), (req, res) => {
    const { password, ...userWithoutPassword } = req.user as any;
    res.status(200).json({ 
      message: "Login successful", 
      user: userWithoutPassword 
    });
  });

  app.post("/api/auth/logout", (req, res) => {
    req.logout((err) => {
      if (err) {
        return res.status(500).json({ message: "Error during logout" });
      }
      res.status(200).json({ message: "Logged out successfully" });
    });
  });

  app.get("/api/auth/user", (req, res) => {
    if (!req.user) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    const { password, ...userWithoutPassword } = req.user as any;
    res.status(200).json({ user: userWithoutPassword });
  });

  // YouTube API routes
  app.get("/api/youtube/search", isAuthenticated, async (req, res) => {
    try {
      const { query, type = "video" } = req.query;
      
      if (!query) {
        return res.status(400).json({ message: "Query parameter is required" });
      }
      
      // Demo mode - return mock data since API key is missing
      if (!process.env.YOUTUBE_API_KEY) {
        console.log("YOUTUBE_API_KEY is missing, returning mock data");
        
        // Mock YouTube search response
        const mockData = {
          kind: "youtube#searchListResponse",
          etag: "mock_etag",
          nextPageToken: "mock_next_page",
          regionCode: "US",
          pageInfo: {
            totalResults: 3,
            resultsPerPage: 3
          },
          items: [
            {
              kind: "youtube#searchResult",
              etag: "mock_etag_1",
              id: {
                kind: "youtube#video",
                videoId: "dQw4w9WgXcQ"
              },
              snippet: {
                publishedAt: "2023-01-01T00:00:00Z",
                channelId: "mock_channel_1",
                title: "Test Video 1",
                description: "This is a test video",
                thumbnails: {
                  default: {
                    url: "https://i.ytimg.com/vi/dQw4w9WgXcQ/default.jpg",
                    width: 120,
                    height: 90
                  },
                  medium: {
                    url: "https://i.ytimg.com/vi/dQw4w9WgXcQ/mqdefault.jpg",
                    width: 320,
                    height: 180
                  },
                  high: {
                    url: "https://i.ytimg.com/vi/dQw4w9WgXcQ/hqdefault.jpg",
                    width: 480,
                    height: 360
                  }
                },
                channelTitle: "Test Channel",
                liveBroadcastContent: "none",
                publishTime: "2023-01-01T00:00:00Z"
              }
            },
            {
              kind: "youtube#searchResult",
              etag: "mock_etag_2",
              id: {
                kind: "youtube#video",
                videoId: "mock_video_id_2"
              },
              snippet: {
                publishedAt: "2023-01-02T00:00:00Z",
                channelId: "mock_channel_2",
                title: "Test Video 2",
                description: "This is another test video",
                thumbnails: {
                  default: {
                    url: "https://via.placeholder.com/120x90",
                    width: 120,
                    height: 90
                  },
                  medium: {
                    url: "https://via.placeholder.com/320x180",
                    width: 320,
                    height: 180
                  },
                  high: {
                    url: "https://via.placeholder.com/480x360",
                    width: 480,
                    height: 360
                  }
                },
                channelTitle: "Another Test Channel",
                liveBroadcastContent: "none",
                publishTime: "2023-01-02T00:00:00Z"
              }
            },
            {
              kind: "youtube#searchResult",
              etag: "mock_etag_3",
              id: {
                kind: "youtube#video",
                videoId: "mock_video_id_3"
              },
              snippet: {
                publishedAt: "2023-01-03T00:00:00Z",
                channelId: "mock_channel_3",
                title: "Test Video 3",
                description: "This is a third test video",
                thumbnails: {
                  default: {
                    url: "https://via.placeholder.com/120x90",
                    width: 120,
                    height: 90
                  },
                  medium: {
                    url: "https://via.placeholder.com/320x180",
                    width: 320,
                    height: 180
                  },
                  high: {
                    url: "https://via.placeholder.com/480x360",
                    width: 480,
                    height: 360
                  }
                },
                channelTitle: "Third Test Channel",
                liveBroadcastContent: "none",
                publishTime: "2023-01-03T00:00:00Z"
              }
            }
          ]
        };
        
        // Store search in history
        if (req.user) {
          await storage.addSearch({
            userId: (req.user as any).id,
            query: query as string,
            type: type as string,
            resultCount: mockData.items.length,
          });
        }
        
        return res.json(mockData);
      }
      
      // Real API call if key exists
      const response = await axios.get("https://www.googleapis.com/youtube/v3/search", {
        params: {
          part: "snippet",
          maxResults: 15,
          q: query,
          type,
          videoCategoryId: "10", // Music category
          key: process.env.YOUTUBE_API_KEY,
        },
      });
      
      // Store search in history
      if (req.user) {
        await storage.addSearch({
          userId: (req.user as any).id,
          query: query as string,
          type: type as string,
          resultCount: response.data.items.length,
        });
      }
      
      res.json(response.data);
    } catch (error: any) {
      res.status(500).json({ 
        message: "Error searching YouTube", 
        error: error.message 
      });
    }
  });

  // Last.fm API routes
  app.get("/api/lastfm/similar", isAuthenticated, async (req, res) => {
    try {
      const { artist, track } = req.query;
      
      if (!artist && !track) {
        return res.status(400).json({ 
          message: "Artist or track parameter is required" 
        });
      }
      
      const params: any = {
        method: track ? "track.getSimilar" : "artist.getSimilar",
        api_key: process.env.LASTFM_API_KEY,
        format: "json",
      };
      
      if (artist) params.artist = artist;
      if (track) params.track = track;
      
      const response = await axios.get("https://ws.audioscrobbler.com/2.0/", {
        params,
      });
      
      res.json(response.data);
    } catch (error: any) {
      res.status(500).json({ 
        message: "Error fetching Last.fm recommendations", 
        error: error.message 
      });
    }
  });

  app.get("/api/lastfm/artistinfo", isAuthenticated, async (req, res) => {
    try {
      const { artist } = req.query;
      
      if (!artist) {
        return res.status(400).json({ message: "Artist parameter is required" });
      }
      
      const response = await axios.get("https://ws.audioscrobbler.com/2.0/", {
        params: {
          method: "artist.getInfo",
          artist,
          api_key: process.env.LASTFM_API_KEY,
          format: "json",
        },
      });
      
      res.json(response.data);
    } catch (error: any) {
      res.status(500).json({ 
        message: "Error fetching Last.fm artist info", 
        error: error.message 
      });
    }
  });

  app.get("/api/lastfm/topgenres", isAuthenticated, async (req, res) => {
    try {
      const response = await axios.get("https://ws.audioscrobbler.com/2.0/", {
        params: {
          method: "tag.getTopTags",
          api_key: process.env.LASTFM_API_KEY,
          format: "json",
        },
      });
      
      res.json(response.data);
    } catch (error: any) {
      res.status(500).json({ 
        message: "Error fetching Last.fm top genres", 
        error: error.message 
      });
    }
  });

  // Favorites routes
  app.get("/api/favorites", isAuthenticated, async (req, res) => {
    try {
      const favorites = await storage.getFavorites((req.user as any).id);
      res.json(favorites);
    } catch (error: any) {
      res.status(500).json({ 
        message: "Error fetching favorites", 
        error: error.message 
      });
    }
  });

  app.post("/api/favorites", isAuthenticated, async (req, res) => {
    try {
      const validatedData = insertFavoriteSchema.parse({
        ...req.body,
        userId: (req.user as any).id,
      });
      
      // Check if already a favorite
      const isFavorite = await storage.isFavorite(
        validatedData.userId, 
        validatedData.trackId
      );
      
      if (isFavorite) {
        return res.status(400).json({ message: "Track already in favorites" });
      }
      
      const favorite = await storage.addFavorite(validatedData);
      res.status(201).json(favorite);
    } catch (error: any) {
      res.status(500).json({ 
        message: "Error adding favorite", 
        error: error.message 
      });
    }
  });

  app.delete("/api/favorites/:trackId", isAuthenticated, async (req, res) => {
    try {
      const { trackId } = req.params;
      const success = await storage.removeFavorite((req.user as any).id, trackId);
      
      if (!success) {
        return res.status(404).json({ message: "Favorite not found" });
      }
      
      res.status(200).json({ message: "Favorite removed successfully" });
    } catch (error: any) {
      res.status(500).json({ 
        message: "Error removing favorite", 
        error: error.message 
      });
    }
  });

  // Play History routes
  app.get("/api/history", isAuthenticated, async (req, res) => {
    try {
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 10;
      const history = await storage.getPlayHistory((req.user as any).id, limit);
      res.json(history);
    } catch (error: any) {
      res.status(500).json({ 
        message: "Error fetching play history", 
        error: error.message 
      });
    }
  });

  app.post("/api/history", isAuthenticated, async (req, res) => {
    try {
      const validatedData = insertPlayHistorySchema.parse({
        ...req.body,
        userId: (req.user as any).id,
      });
      
      const history = await storage.addPlayHistory(validatedData);
      res.status(201).json(history);
    } catch (error: any) {
      res.status(500).json({ 
        message: "Error adding play history", 
        error: error.message 
      });
    }
  });

  // Search History routes
  app.get("/api/searches", isAuthenticated, async (req, res) => {
    try {
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 5;
      const searches = await storage.getRecentSearches((req.user as any).id, limit);
      res.json(searches);
    } catch (error: any) {
      res.status(500).json({ 
        message: "Error fetching search history", 
        error: error.message 
      });
    }
  });

  // AI Chat routes
  app.get("/api/chats", isAuthenticated, async (req, res) => {
    try {
      const chats = await storage.getAiChats((req.user as any).id);
      res.json(chats);
    } catch (error: any) {
      res.status(500).json({ 
        message: "Error fetching chats", 
        error: error.message 
      });
    }
  });

  app.get("/api/chats/:id", isAuthenticated, async (req, res) => {
    try {
      const chatId = parseInt(req.params.id);
      const chat = await storage.getAiChat(chatId);
      
      if (!chat) {
        return res.status(404).json({ message: "Chat not found" });
      }
      
      if (chat.userId !== (req.user as any).id) {
        return res.status(403).json({ message: "Unauthorized access to this chat" });
      }
      
      res.json(chat);
    } catch (error: any) {
      res.status(500).json({ 
        message: "Error fetching chat", 
        error: error.message 
      });
    }
  });

  app.post("/api/chats", isAuthenticated, async (req, res) => {
    try {
      const validatedData = insertAiChatSchema.parse({
        userId: (req.user as any).id,
        messages: req.body.messages || [],
      });
      
      const chat = await storage.createAiChat(validatedData);
      res.status(201).json(chat);
    } catch (error: any) {
      res.status(500).json({ 
        message: "Error creating chat", 
        error: error.message 
      });
    }
  });

  app.post("/api/chats/:id/messages", isAuthenticated, async (req, res) => {
    try {
      const chatId = parseInt(req.params.id);
      const { message } = req.body;
      
      if (!message) {
        return res.status(400).json({ message: "Message is required" });
      }
      
      const chat = await storage.getAiChat(chatId);
      
      if (!chat) {
        return res.status(404).json({ message: "Chat not found" });
      }
      
      if (chat.userId !== (req.user as any).id) {
        return res.status(403).json({ message: "Unauthorized access to this chat" });
      }
      
      // Add user message
      const messages = [...chat.messages, { role: "user", content: message }];
      
      // Yerel müzik asistanı uygulaması - Yapay zeka API'sine bağlı değil
      
      // Son kullanıcı mesajını al
      const userMessage = messages[messages.length - 1].content.toLowerCase();
      
      // Yerel müzik tavsiye motoru
      let aiResponseContent = "";
      
      // Duygu durumuna göre müzik önerileri
      if (userMessage.includes("mutlu") || userMessage.includes("neşeli") || userMessage.includes("keyifli")) {
        aiResponseContent = "Mutlu ruh halinize uygun şu şarkıları dinleyebilirsiniz:\n\n1. Tarkan - 'Kuzu Kuzu'\n2. Kenan Doğulu - 'Çakkıdı'\n3. Gülşen - 'Bangır Bangır'\n4. MFÖ - 'Peki Peki Anladık'\n5. Mabel Matiz - 'Ya Bu İşler Ne'\n\nEnerjinizi yüksek tutacak bu parçalar size iyi gelecektir!";
      }
      else if (userMessage.includes("üzgün") || userMessage.includes("hüzünlü") || userMessage.includes("kederli")) {
        aiResponseContent = "Hüzünlü anlarınıza eşlik edebilecek şu şarkıları önerebilirim:\n\n1. Sezen Aksu - 'Gülümse'\n2. Teoman - 'Rüzgar Gülü'\n3. Mor ve Ötesi - 'Bir Derdim Var'\n4. Yıldız Tilbe - 'Vazgeçtim'\n5. Müslüm Gürses - 'Nilüfer'\n\nBazen hüzünlü müzikler duygularımızı ifade etmeye ve onlarla başa çıkmaya yardımcı olur.";
      }
      else if (userMessage.includes("romantik") || userMessage.includes("aşk")) {
        aiResponseContent = "Romantik bir atmosfer için şu şarkıları dinleyebilirsiniz:\n\n1. Sezen Aksu - 'Gülümse'\n2. Sıla - 'Yan Benimle'\n3. Yalın - 'Herşey Sensin'\n4. Kenan Doğulu - 'Kandırdım'\n5. Tarkan - 'Öp'\n6. Yaşar - 'Kumralım'\n7. Ebru Gündeş - 'Aşık'\n\nBu şarkılar romantik anlarınıza derinlik katacaktır.";
      }
      else if (userMessage.includes("motivasyon") || userMessage.includes("motive")) {
        aiResponseContent = "Motivasyonunuzu artıracak şu şarkıları dinleyebilirsiniz:\n\n1. Manga - 'Bir Kadın Çizeceksin'\n2. Athena - 'Arsız Gönül'\n3. Şebnem Ferah - 'Sil Baştan'\n4. Fatih Erkoç - 'Ellerim Bomboş'\n5. Gripin - 'Durma Yağmur Durma'\n\nBu şarkılar size enerji verecek ve motivasyonunuzu yükseltecektir!";
      }
      // Tür bazlı müzik önerileri
      else if (userMessage.includes("öneri") || userMessage.includes("öner") || userMessage.includes("tavsiye")) {
        aiResponseContent = "Size birkaç harika müzik önerebilirim! Hangi türde müzik dinlemeyi seviyorsunuz? Pop, rock, jazz, klasik, elektronik veya Türk halk müziği gibi?";
      } 
      else if (userMessage.includes("pop")) {
        aiResponseContent = "Türk pop müziği için şu sanatçıları dinleyebilirsiniz:\n\n1. Sezen Aksu - 'Firuze', 'Gülümse'\n2. Tarkan - 'Kuzu Kuzu', 'Dudu'\n3. Kenan Doğulu - 'Tutamıyorum Zamanı', 'Çakkıdı'\n4. Mabel Matiz - 'Öyle Kolaysa', 'Sarmaşık'\n5. Simge - 'Miş Miş', 'Ben Bazen'\n\nYabancı pop için Dua Lipa, The Weeknd, ve Ed Sheeran da dinleyebilirsiniz.";
      }
      else if (userMessage.includes("rock")) {
        aiResponseContent = "Türk rock müziği için şu grupları ve sanatçıları deneyebilirsiniz:\n\n1. Duman - 'Seni Kendime Sakladım', 'Bal'\n2. Mor ve Ötesi - 'Bir Derdim Var', 'Cambaz'\n3. maNga - 'Bir Kadın Çizeceksin', 'Dursun Zaman'\n4. Teoman - 'Rüzgar Gülü', 'Para Yok'\n5. Şebnem Ferah - 'Sil Baştan', 'Can Kırıkları'\n\nAyrıca Anadolu Rock için Barış Manço, Cem Karaca ve Erkin Koray gibi efsaneleri de dinleyebilirsiniz.";
      }
      else if (userMessage.includes("elektronik") || userMessage.includes("edm")) {
        aiResponseContent = "Elektronik müzik için şu Türk sanatçıları dinleyebilirsiniz:\n\n1. Mercan Dede - 'Nefes', 'Sufi Traveler'\n2. Ah! Kosmos - 'Wide', 'From Infinity to Here'\n3. Büyük Ev Ablukada - 'Fırtınayt'\n4. Nikaragua - 'Orman'\n5. Mabbas - 'Nightfall'\n\nYabancı elektronik müzik için Daft Punk, Deadmau5, ve Bonobo gibi sanatçıları deneyebilirsiniz.";
      }
      else if (userMessage.includes("klasik")) {
        aiResponseContent = "Türk klasik müziği için şu eserleri dinleyebilirsiniz:\n\n1. Fazıl Say - 'İstanbul Senfonisi', 'Kara Toprak'\n2. İdil Biret - 'Beethoven Sonatları'\n3. Gülsin Onay - 'Mozart Piyano Konçertoları'\n4. Klasik Türk sanat müziği için Münir Nurettin Selçuk, Bekir Sıdkı Sezgin ve Zeki Müren'in kayıtları\n\nBatı klasik müziği için Mozart, Beethoven, Bach, Chopin ve Debussy gibi bestecilerin eserlerini keşfedebilirsiniz.";
      }
      else if (userMessage.includes("jazz") || userMessage.includes("caz")) {
        aiResponseContent = "Türk jazz sanatçıları ve eserleri:\n\n1. İlhan Erşahin - 'Istanbul Sessions'\n2. Kerem Görsev - 'Warm Winter'\n3. Önder Focan - 'Autumn in New York'\n4. Ayşe Tütüncü - 'Dünya'\n5. Korhan Futacı - 'Kara Orkestra'\n\nJazz'ın ustaları arasında Miles Davis ('Kind of Blue'), John Coltrane ('A Love Supreme'), ve Bill Evans ('Sunday at the Village Vanguard') albümlerini de dinleyebilirsiniz.";
      }
      else if (userMessage.includes("türkü") || userMessage.includes("halk müziği") || userMessage.includes("halk")) {
        aiResponseContent = "Türk halk müziği için şu değerli sanatçıları ve eserlerini dinleyebilirsiniz:\n\n1. Neşet Ertaş - 'Zahidem', 'Neredesin Sen'\n2. Aşık Veysel - 'Uzun İnce Bir Yoldayım', 'Kara Toprak'\n3. Arif Sağ - 'Mihriban', 'Dost Yüzü Göresim Geldi'\n4. Belkıs Akkale - 'Ankara'nın Bağları', 'Dağlar Dağlar'\n5. Selda Bağcan - 'Yaz Gazeteci Yaz', 'Gesi Bağları'\n\nBu eserler Anadolu'nun zengin müzik kültürünün en güzel örnekleridir.";
      }
      else if (userMessage.includes("rap") || userMessage.includes("hip hop")) {
        aiResponseContent = "Türk rap müziği için şu sanatçıları dinleyebilirsiniz:\n\n1. Ceza - 'Holocaust', 'Suspus'\n2. Ezhel - 'Geceler', 'Şehrimin Tadı'\n3. Sagopa Kajmer - 'Galiba', 'İstisnalar Kaideyi Bozmaz'\n4. Şanışer - 'Ludovico', 'Susamam'\n5. Patron - 'Depo', 'İmparator'\n\nYabancı rap için Kendrick Lamar ('DAMN.'), J. Cole ('2014 Forest Hills Drive'), ve Nas ('Illmatic') gibi sanatçıları dinleyebilirsiniz.";
      }
      else if (userMessage.includes("metal")) {
        aiResponseContent = "Türk metal müziği için şu grupları dinleyebilirsiniz:\n\n1. Pentagram/Mezarkabul - 'Anatolia', 'Lions in a Cage'\n2. Mor ve Ötesi - 'Gül Kendine', 'Re'\n3. Kurban - 'Yalan', 'Sahip'\n4. Murder King - 'Gül Bahçesi', 'Anarşist'\n5. Cenotaph - 'Pseudo Vermination', 'Putrescent Infectious Rabidity'\n\nDünya metal sahnesinden Metallica, Iron Maiden, Gojira ve Opeth gibi grupları da keşfedebilirsiniz.";
      }
      else if (userMessage.includes("arabesk")) {
        aiResponseContent = "Arabesk müzik için şu efsanevi sanatçıları ve eserlerini dinleyebilirsiniz:\n\n1. Müslüm Gürses - 'Nilüfer', 'Sevda Yüklü Kervanlar'\n2. Orhan Gencebay - 'Bir Teselli Ver', 'Hatasız Kul Olmaz'\n3. Bergen - 'Acıların Kadını', 'İnsafsız'\n4. Ferdi Tayfur - 'Emmioğlu', 'Huzurum Kalmadı'\n5. İbrahim Tatlıses - 'Mavi Mavi', 'Mutlu Ol Yeter'\n\nArabesk müzik, Türk toplumunun duygusal yönünü yansıtan önemli bir türdür.";
      }
      // Makam ve müzik teorisi
      else if (userMessage.includes("makam")) {
        aiResponseContent = "Makam, Türk müziğinde melodilerin oluşturulmasında kullanılan, belirli perdeler ve seyir kurallarına sahip ses sistemleridir. Her makamın kendine özgü bir dolaşım (seyir) özelliği vardır.\n\nEn yaygın makamlar arasında:\n1. Rast - Neşe ve canlılık hissi verir\n2. Hüseyni - Daha melanklolik bir karakterdedir\n3. Hicaz - Hüzünlü ve duygusal bir etki yaratır\n4. Uşşak - Hasret duygusunu ifade eder\n5. Saba - Hüzün ve karamsarlık hissi verir\n\nTürk müziğinde 600'e yakın makam bulunur ancak günümüzde yaklaşık 120 tanesi aktif olarak kullanılmaktadır.";
      }
      // Temel konuşma kalıpları
      else if (userMessage.includes("merhaba") || userMessage.includes("selam") || userMessage.includes("nasılsın")) {
        aiResponseContent = "Merhaba! Size müzik konusunda nasıl yardımcı olabilirim? Belirli bir tür, sanatçı hakkında bilgi almak veya duygu durumunuza uygun müzik önerileri mi istiyorsunuz?";
      }
      else if (userMessage.includes("teşekkür")) {
        aiResponseContent = "Rica ederim! Müzik dünyasında keşfedilecek daha çok şey var. Başka bir müzik önerisi veya bilgi istediğinizde bana yazabilirsiniz. Size yardımcı olmaktan memnuniyet duyarım.";
      }
      // Sanatçı bilgileri
      else if (userMessage.includes("tarkan")) {
        aiResponseContent = "Tarkan Tevetoğlu, Türk pop müziğinin uluslararası alanda en tanınan temsilcisidir. 1992'de çıkardığı ilk albümü 'Yine Sensiz' ile büyük çıkış yakaladı. 'Şımarık' şarkısıyla dünya çapında tanındı. 'Kuzu Kuzu', 'Dudu', 'Gülümse Kaderine' gibi hit şarkılarıyla Türkiye'de rekorlar kırdı.\n\nTürk halk müziği ve klasik müziği öğelerini modern pop unsurlarıyla birleştiren kendine özgü bir tarzı vardır. Sezen Aksu ile yaptığı işbirliği kariyerinde önemli yer tutar. 'Türk Pop Prensi' olarak anılır.";
      }
      else if (userMessage.includes("sezen aksu")) {
        aiResponseContent = "Sezen Aksu (d. 13 Temmuz 1954), Türk pop müziğinin 'Minik Serçe' olarak bilinen efsanevi ismidir. 1970'lerde başladığı müzik kariyerinde 40'tan fazla albüm çıkardı. 'Firuze', 'Gülümse', 'Hata', 'Son Bakış', 'İkinci Bahar' gibi unutulmaz şarkılara imza attı.\n\n500'den fazla şarkı bestelemiş ve Tarkan, Sertab Erener, Levent Yüksel gibi birçok sanatçının kariyerinin gelişiminde mentor olmuştur. Modern Türk pop müziğinin kurucusu ve en etkili figürü olarak kabul edilir.";
      }
      else if (userMessage.includes("barış manço")) {
        aiResponseContent = "Barış Manço (2 Ocak 1943 - 1 Şubat 1999), Türk rock müziğinin ve Anadolu Rock akımının öncü isimlerinden biridir. 'Dağlar Dağlar', 'Gülpembe', 'Sarı Çizmeli Mehmet Ağa', 'Domates Biber Patlıcan' gibi unutulmaz eserlere imza attı.\n\nTürk halk müziği ile rock müziği sentezledi. '7'den 77'ye' ve 'Adam Olacak Çocuk' gibi televizyon programlarıyla da milyonlara ulaştı. Müziğinin yanı sıra kültürler arası köprü kurma çabasıyla da tanınır.";
      }
      else if (userMessage.includes("müslüm gürses")) {
        aiResponseContent = "Müslüm Gürses (1953-2013), Türk arabesk müziğinin efsanevi ismi, 'Müslüm Baba' olarak bilinen şarkıcı ve oyuncudur. 'Nilüfer', 'Sevda Yüklü Kervanlar', 'Affet', 'Mutlu Ol Yeter' gibi unutulmaz eserlere imza attı.\n\nKendine özgü yorumu, derin ve dokunaklı sesiyle tanınırdı. Yaşadığı zorluklara rağmen, acı, hüzün ve yaşam mücadelesi temalarını eşsiz bir yorumla dinleyicilerine aktardı. Son döneminde rock, pop ve caz yorumlarıyla da dikkat çekti.";
      }
      else {
        aiResponseContent = "Müzik zevkiniz ve aradığınız bilgi hakkında daha fazla detay verebilir misiniz? Hangi tür müzik, sanatçı hakkında bilgi almak istiyorsunuz veya hangi duygu durumunuza uygun müzik önerileri arıyorsunuz? Size daha iyi yardımcı olabilmem için biraz daha açıklama yapabilir misiniz?";
      }
      
      // Asistan yanıtını ekle
      messages.push({
        role: "assistant",
        content: aiResponseContent
      });
      
      // Update chat
      const updatedChat = await storage.updateAiChat(chatId, messages);
      res.json(updatedChat);
    } catch (error: any) {
      res.status(500).json({ 
        message: "Error processing AI response", 
        error: error.message 
      });
    }
  });

  // WebSocket connection for real-time chat
  wss.on("connection", (ws) => {
    console.log("New WebSocket connection established");
    
    // Send welcome message
    ws.send(JSON.stringify({
      type: "message",
      message: "Merhaba! MusicAI asistanınız bağlandı. Nasıl yardımcı olabilirim?",
      sender: "ai"
    }));
    
    ws.on("message", async (message) => {
      try {
        console.log("Received message:", message.toString());
        const data = JSON.parse(message.toString());
        
        if (data.type === "ai_message") {
          // Process AI message (handled via HTTP API for auth)
          // This is mainly for notifications and status updates
          ws.send(JSON.stringify({
            type: "status",
            status: "Yanıtınız hazırlanıyor..."
          }));
          
          // Handle AI message for music recommendations
          if (data.message) {
            const userMessage = data.message;
            const chatId = data.chatId;
            
            try {
              let aiResponse;
              
              // Check if message is asking for music recommendations or mood-based suggestions
              if (userMessage.toLowerCase().includes("öner") || 
                  userMessage.toLowerCase().includes("tavsiye") ||
                  userMessage.toLowerCase().includes("müzik") ||
                  userMessage.toLowerCase().includes("şarkı") ||
                  userMessage.toLowerCase().includes("hissediyorum") ||
                  userMessage.toLowerCase().includes("hisset") ||
                  userMessage.toLowerCase().includes("mood") ||
                  userMessage.toLowerCase().includes("duygu")) {
                
                // Use our custom mood-based recommendation engine
                aiResponse = generateMusicRecommendation(userMessage);
              } else {
                // Default AI response for general conversation
                aiResponse = "Müzik asistanınız olarak, size en iyi müzik önerilerini sunmak için buradayım. Nasıl yardımcı olabilirim? Duygu durumunuzu veya dinlemek istediğiniz müzik türünü söyleyebilirsiniz.";
              }
              
              // Send response to client
              ws.send(JSON.stringify({
                type: "message",
                message: aiResponse,
                sender: "ai"
              }));
            } catch (error) {
              console.error("Error generating AI response:", error);
              
              ws.send(JSON.stringify({
                type: "error",
                message: "Müzik önerisi oluşturulurken bir hata oluştu."
              }));
            }
          }
        }
      } catch (error) {
        console.error("WebSocket error:", error);
      }
    });
  });

  return httpServer;
}
