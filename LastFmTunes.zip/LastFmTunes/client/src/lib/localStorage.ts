import { CACHE_DURATION } from './constants';

interface CachedData<T> {
  data: T;
  timestamp: number;
}

// Function to get data from localStorage with optional expiration
export async function getStoredData<T>(key: string, defaultValue: T): Promise<T> {
  try {
    const storedJson = localStorage.getItem(key);
    
    if (!storedJson) {
      return defaultValue;
    }
    
    const stored = JSON.parse(storedJson) as CachedData<T>;
    const now = Date.now();
    
    // Check if data is expired
    if (stored.timestamp && now - stored.timestamp > CACHE_DURATION) {
      localStorage.removeItem(key);
      return defaultValue;
    }
    
    return stored.data;
  } catch (error) {
    console.error(`Error retrieving data from localStorage for key "${key}":`, error);
    return defaultValue;
  }
}

// Function to set data in localStorage with timestamp
export async function setStoredData<T>(key: string, data: T): Promise<void> {
  try {
    const cachedData: CachedData<T> = {
      data,
      timestamp: Date.now()
    };
    
    localStorage.setItem(key, JSON.stringify(cachedData));
  } catch (error) {
    console.error(`Error storing data in localStorage for key "${key}":`, error);
    
    // If quota exceeded, try to clean up old data
    if (error instanceof DOMException && error.name === 'QuotaExceededError') {
      cleanupOldCache();
      // Try again after cleanup
      try {
        const cachedData: CachedData<T> = {
          data,
          timestamp: Date.now()
        };
        localStorage.setItem(key, JSON.stringify(cachedData));
      } catch (retryError) {
        console.error(`Failed to store data after cleanup:`, retryError);
      }
    }
  }
}

// Function to clear expired items from localStorage
export function cleanupOldCache(): void {
  try {
    const now = Date.now();
    
    for (let i = 0; i < localStorage.length; i++) {
      const key = localStorage.key(i);
      
      if (key) {
        const storedJson = localStorage.getItem(key);
        
        if (storedJson) {
          try {
            const stored = JSON.parse(storedJson) as CachedData<unknown>;
            
            if (stored.timestamp && now - stored.timestamp > CACHE_DURATION) {
              localStorage.removeItem(key);
            }
          } catch (parseError) {
            // If not in our format, skip it
            continue;
          }
        }
      }
    }
  } catch (error) {
    console.error('Error cleaning up old cache:', error);
  }
}

// Function to get total storage usage
export function getStorageUsage(): { used: number, total: number, percentage: number } {
  // Estimate localStorage total size (5MB is common for most browsers)
  const estimatedTotal = 5 * 1024 * 1024;
  
  // Calculate current usage
  let totalSize = 0;
  for (let i = 0; i < localStorage.length; i++) {
    const key = localStorage.key(i);
    if (key) {
      const value = localStorage.getItem(key) || '';
      totalSize += key.length + value.length;
    }
  }
  
  // Convert to bytes (approximate as each character is ~2 bytes in UTF-16)
  const usedBytes = totalSize * 2;
  
  return {
    used: usedBytes,
    total: estimatedTotal,
    percentage: (usedBytes / estimatedTotal) * 100
  };
}

// Function to check if local storage is available
export function isLocalStorageAvailable(): boolean {
  try {
    const testKey = '__storage_test__';
    localStorage.setItem(testKey, testKey);
    localStorage.removeItem(testKey);
    return true;
  } catch (e) {
    return false;
  }
}
