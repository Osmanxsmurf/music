import { 
  users, type User, type InsertUser,
  songs, type Song, type InsertSong,
  playlists, type Playlist, type InsertPlaylist,
  playlistSongs, type PlaylistSong, type InsertPlaylistSong,
  userLikedSongs, type UserLikedSong, type InsertUserLikedSong,
  userRecentlyPlayed, type UserRecentlyPlayed, type InsertUserRecentlyPlayed,
  aiMessages, type AiMessage, type InsertAiMessage
} from "@shared/schema";

export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Song methods
  getSong(id: number): Promise<Song | undefined>;
  getAllSongs(): Promise<Song[]>;
  getSongsByMood(mood: string): Promise<Song[]>;
  createSong(song: InsertSong): Promise<Song>;
  updateSongLikeCount(songId: number, increment: boolean): Promise<void>;
  updateSongPlayCount(songId: number): Promise<void>;
  
  // Playlist methods
  getPlaylist(id: number): Promise<Playlist | undefined>;
  getUserPlaylists(userId: number): Promise<Playlist[]>;
  createPlaylist(playlist: InsertPlaylist): Promise<Playlist>;
  addSongToPlaylist(playlistSong: InsertPlaylistSong): Promise<PlaylistSong>;
  removeSongFromPlaylist(playlistId: number, songId: number): Promise<void>;
  getPlaylistSongs(playlistId: number): Promise<Song[]>;
  
  // User liked songs
  getLikedSongs(userId: number): Promise<Song[]>;
  likeSong(userLikedSong: InsertUserLikedSong): Promise<UserLikedSong>;
  unlikeSong(userId: number, songId: number): Promise<void>;
  
  // Recently played
  getRecentlyPlayed(userId: number, limit?: number): Promise<Song[]>;
  addRecentlyPlayed(recent: InsertUserRecentlyPlayed): Promise<UserRecentlyPlayed>;
  
  // AI messages
  getChatHistory(userId: number, limit?: number): Promise<AiMessage[]>;
  addChatMessage(message: InsertAiMessage): Promise<AiMessage>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private songs: Map<number, Song>;
  private playlists: Map<number, Playlist>;
  private playlistSongs: Map<number, PlaylistSong>;
  private userLikedSongs: Map<number, UserLikedSong>;
  private userRecentlyPlayed: Map<number, UserRecentlyPlayed>;
  private aiMessages: Map<number, AiMessage>;
  
  userCurrentId: number;
  songCurrentId: number;
  playlistCurrentId: number;
  playlistSongCurrentId: number;
  likedSongCurrentId: number;
  recentlyPlayedCurrentId: number;
  aiMessageCurrentId: number;

  constructor() {
    this.users = new Map();
    this.songs = new Map();
    this.playlists = new Map();
    this.playlistSongs = new Map();
    this.userLikedSongs = new Map();
    this.userRecentlyPlayed = new Map();
    this.aiMessages = new Map();
    
    this.userCurrentId = 1;
    this.songCurrentId = 1;
    this.playlistCurrentId = 1;
    this.playlistSongCurrentId = 1;
    this.likedSongCurrentId = 1;
    this.recentlyPlayedCurrentId = 1;
    this.aiMessageCurrentId = 1;
    
    // Initialize with some sample songs
    this.initializeSampleData();
  }

  // Initialize sample data
  private initializeSampleData() {
    // Sample songs with different moods
    const sampleSongs: InsertSong[] = [
      {
        title: "Blinding Lights",
        artist: "The Weeknd",
        album: "After Hours",
        coverImage: "https://example.com/blinding-lights.jpg",
        genre: "Pop",
        mood: ["energetic", "upbeat"],
        duration: 203,
        audioUrl: "https://example.com/blinding-lights.mp3",
        year: 2020
      },
      {
        title: "Don't Start Now",
        artist: "Dua Lipa",
        album: "Future Nostalgia",
        coverImage: "https://example.com/dont-start-now.jpg",
        genre: "Pop",
        mood: ["energetic", "danceable"],
        duration: 183,
        audioUrl: "https://example.com/dont-start-now.mp3",
        year: 2019
      },
      {
        title: "The Less I Know The Better",
        artist: "Tame Impala",
        album: "Currents",
        coverImage: "https://example.com/the-less-i-know.jpg",
        genre: "Alternative",
        mood: ["chill", "reflective"],
        duration: 216,
        audioUrl: "https://example.com/the-less-i-know.mp3",
        year: 2015
      },
      {
        title: "Bohemian Rhapsody",
        artist: "Queen",
        album: "A Night at the Opera",
        coverImage: "https://example.com/bohemian-rhapsody.jpg",
        genre: "Rock",
        mood: ["dramatic", "nostalgic"],
        duration: 354,
        audioUrl: "https://example.com/bohemian-rhapsody.mp3",
        year: 1975
      },
      {
        title: "Starboy",
        artist: "The Weeknd",
        album: "Starboy",
        coverImage: "https://example.com/starboy.jpg",
        genre: "R&B",
        mood: ["energetic", "confident"],
        duration: 230,
        audioUrl: "https://example.com/starboy.mp3",
        year: 2016
      },
      {
        title: "Watermelon Sugar",
        artist: "Harry Styles",
        album: "Fine Line",
        coverImage: "https://example.com/watermelon-sugar.jpg",
        genre: "Pop",
        mood: ["happy", "summer"],
        duration: 174,
        audioUrl: "https://example.com/watermelon-sugar.mp3",
        year: 2019
      },
      {
        title: "Hotel California",
        artist: "Eagles",
        album: "Hotel California",
        coverImage: "https://example.com/hotel-california.jpg",
        genre: "Rock",
        mood: ["nostalgic", "chill"],
        duration: 391,
        audioUrl: "https://example.com/hotel-california.mp3",
        year: 1976
      },
      {
        title: "lovely",
        artist: "Billie Eilish, Khalid",
        album: "lovely",
        coverImage: "https://example.com/lovely.jpg",
        genre: "Alternative",
        mood: ["sad", "emotional"],
        duration: 200,
        audioUrl: "https://example.com/lovely.mp3",
        year: 2018
      },
      {
        title: "Sweet Child O' Mine",
        artist: "Guns N' Roses",
        album: "Appetite for Destruction",
        coverImage: "https://example.com/sweet-child.jpg",
        genre: "Rock",
        mood: ["energetic", "nostalgic"],
        duration: 356,
        audioUrl: "https://example.com/sweet-child.mp3",
        year: 1987
      },
      {
        title: "Deep Focus",
        artist: "Brian Eno",
        album: "Ambient 1: Music for Airports",
        coverImage: "https://example.com/deep-focus.jpg",
        genre: "Ambient",
        mood: ["focused", "calm"],
        duration: 480,
        audioUrl: "https://example.com/deep-focus.mp3",
        year: 1978
      }
    ];
    
    // Add the sample songs
    sampleSongs.forEach(song => {
      this.createSong(song);
    });
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userCurrentId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }
  
  // Song methods
  async getSong(id: number): Promise<Song | undefined> {
    return this.songs.get(id);
  }
  
  async getAllSongs(): Promise<Song[]> {
    return Array.from(this.songs.values());
  }
  
  async getSongsByMood(mood: string): Promise<Song[]> {
    return Array.from(this.songs.values()).filter(
      song => song.mood && song.mood.includes(mood.toLowerCase())
    );
  }
  
  async createSong(insertSong: InsertSong): Promise<Song> {
    const id = this.songCurrentId++;
    const song: Song = { 
      ...insertSong, 
      id, 
      likeCount: 0,
      playCount: 0
    };
    this.songs.set(id, song);
    return song;
  }
  
  async updateSongLikeCount(songId: number, increment: boolean): Promise<void> {
    const song = this.songs.get(songId);
    if (song) {
      song.likeCount = increment 
        ? (song.likeCount || 0) + 1 
        : Math.max(0, (song.likeCount || 0) - 1);
      this.songs.set(songId, song);
    }
  }
  
  async updateSongPlayCount(songId: number): Promise<void> {
    const song = this.songs.get(songId);
    if (song) {
      song.playCount = (song.playCount || 0) + 1;
      this.songs.set(songId, song);
    }
  }
  
  // Playlist methods
  async getPlaylist(id: number): Promise<Playlist | undefined> {
    return this.playlists.get(id);
  }
  
  async getUserPlaylists(userId: number): Promise<Playlist[]> {
    return Array.from(this.playlists.values()).filter(
      playlist => playlist.userId === userId
    );
  }
  
  async createPlaylist(insertPlaylist: InsertPlaylist): Promise<Playlist> {
    const id = this.playlistCurrentId++;
    const now = new Date();
    const playlist: Playlist = { ...insertPlaylist, id, createdAt: now };
    this.playlists.set(id, playlist);
    return playlist;
  }
  
  async addSongToPlaylist(insertPlaylistSong: InsertPlaylistSong): Promise<PlaylistSong> {
    const id = this.playlistSongCurrentId++;
    const now = new Date();
    const playlistSong: PlaylistSong = { ...insertPlaylistSong, id, addedAt: now };
    this.playlistSongs.set(id, playlistSong);
    return playlistSong;
  }
  
  async removeSongFromPlaylist(playlistId: number, songId: number): Promise<void> {
    for (const [id, playlistSong] of this.playlistSongs.entries()) {
      if (playlistSong.playlistId === playlistId && playlistSong.songId === songId) {
        this.playlistSongs.delete(id);
        break;
      }
    }
  }
  
  async getPlaylistSongs(playlistId: number): Promise<Song[]> {
    const playlistSongsEntries = Array.from(this.playlistSongs.values())
      .filter(playlistSong => playlistSong.playlistId === playlistId)
      .sort((a, b) => (a.position || 0) - (b.position || 0));
    
    return playlistSongsEntries.map(entry => {
      const song = this.songs.get(entry.songId);
      return song!;
    }).filter(Boolean);
  }
  
  // User liked songs
  async getLikedSongs(userId: number): Promise<Song[]> {
    const likedSongEntries = Array.from(this.userLikedSongs.values())
      .filter(userLikedSong => userLikedSong.userId === userId)
      .sort((a, b) => b.likedAt.getTime() - a.likedAt.getTime());
    
    return likedSongEntries.map(entry => {
      const song = this.songs.get(entry.songId);
      return song!;
    }).filter(Boolean);
  }
  
  async likeSong(insertUserLikedSong: InsertUserLikedSong): Promise<UserLikedSong> {
    const id = this.likedSongCurrentId++;
    const now = new Date();
    const userLikedSong: UserLikedSong = { ...insertUserLikedSong, id, likedAt: now };
    this.userLikedSongs.set(id, userLikedSong);
    
    // Update song like count
    this.updateSongLikeCount(insertUserLikedSong.songId, true);
    
    return userLikedSong;
  }
  
  async unlikeSong(userId: number, songId: number): Promise<void> {
    for (const [id, userLikedSong] of this.userLikedSongs.entries()) {
      if (userLikedSong.userId === userId && userLikedSong.songId === songId) {
        this.userLikedSongs.delete(id);
        
        // Update song like count
        this.updateSongLikeCount(songId, false);
        
        break;
      }
    }
  }
  
  // Recently played
  async getRecentlyPlayed(userId: number, limit: number = 20): Promise<Song[]> {
    const recentlyPlayedEntries = Array.from(this.userRecentlyPlayed.values())
      .filter(userRecentlyPlayed => userRecentlyPlayed.userId === userId)
      .sort((a, b) => b.playedAt.getTime() - a.playedAt.getTime())
      .slice(0, limit);
    
    return recentlyPlayedEntries.map(entry => {
      const song = this.songs.get(entry.songId);
      return song!;
    }).filter(Boolean);
  }
  
  async addRecentlyPlayed(insertRecentlyPlayed: InsertUserRecentlyPlayed): Promise<UserRecentlyPlayed> {
    const id = this.recentlyPlayedCurrentId++;
    const now = new Date();
    const userRecentlyPlayed: UserRecentlyPlayed = { ...insertRecentlyPlayed, id, playedAt: now };
    this.userRecentlyPlayed.set(id, userRecentlyPlayed);
    
    // Update song play count
    this.updateSongPlayCount(insertRecentlyPlayed.songId);
    
    return userRecentlyPlayed;
  }
  
  // AI messages
  async getChatHistory(userId: number, limit: number = 50): Promise<AiMessage[]> {
    return Array.from(this.aiMessages.values())
      .filter(message => message.userId === userId)
      .sort((a, b) => a.timestamp.getTime() - b.timestamp.getTime())
      .slice(-limit);
  }
  
  async addChatMessage(insertMessage: InsertAiMessage): Promise<AiMessage> {
    const id = this.aiMessageCurrentId++;
    const now = new Date();
    const message: AiMessage = { ...insertMessage, id, timestamp: now };
    this.aiMessages.set(id, message);
    return message;
  }
}

export const storage = new MemStorage();
