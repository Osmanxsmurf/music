import React, { useState, useEffect, useRef } from "react";
import { useAuth } from "@/context/auth-context";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { createChat, sendChatMessage } from "@/lib/api";
import { ChatConversation, ChatMessage, createChatWebSocket, getRecommendedMessages, getAIPersonaSystemMessage } from "@/lib/openai";
import { apiRequest } from "@/lib/queryClient";
import { useLocation } from "wouter";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar";
import { Bot, Music, Send, ArrowLeft, Heart, MoveRight, RefreshCcw } from "lucide-react";
import { ScrollArea } from "@/components/ui/scroll-area";
import { cn } from "@/lib/utils";
import { MoodMusicGuide } from "@/components/mood-music-guide";

export default function AIChat() {
  const { isAuthenticated, user } = useAuth();
  const [location, navigate] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const [chatId, setChatId] = useState<number | null>(null);
  const [input, setInput] = useState("");
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [isTyping, setIsTyping] = useState(false);
  const [isConnected, setIsConnected] = useState(false);
  const scrollAreaRef = useRef<HTMLDivElement>(null);
  const wsRef = useRef<WebSocket | null>(null);
  
  // Redirect if not authenticated
  useEffect(() => {
    if (!isAuthenticated) {
      navigate("/");
      toast({
        title: "Önce giriş yapmalısınız",
        description: "Yapay zeka sohbet özelliğini kullanmak için lütfen giriş yapın",
        variant: "destructive",
      });
    }
  }, [isAuthenticated, navigate, toast]);
  
  // Create a new chat on mount
  useEffect(() => {
    if (isAuthenticated && !chatId) {
      const createNewChat = async () => {
        try {
          const chat = await createChat();
          setChatId(chat.id);
          
          // Add system message
          setMessages([getAIPersonaSystemMessage()]);
          
          // Add welcome message
          const welcomeMessage: ChatMessage = {
            role: "assistant",
            content: "Merhaba! Ben MusicAI, müzik asistanınızım. Size müzik önerileri sunabilir ve müzik hakkında sorularınızı cevaplayabilirim. Nasıl yardımcı olabilirim? Duygularınıza uygun müzik önerileri için nasıl hissettiğinizi söyleyebilirsiniz."
          };
          setMessages(prev => [...prev, welcomeMessage]);
        } catch (error) {
          console.error("Error creating chat:", error);
          toast({
            title: "Sohbet oluşturulamadı",
            description: "Lütfen daha sonra tekrar deneyin",
            variant: "destructive",
          });
        }
      };
      
      createNewChat();
    }
  }, [isAuthenticated, chatId, toast]);
  
  // Setup WebSocket connection
  useEffect(() => {
    if (isAuthenticated && chatId) {
      const ws = createChatWebSocket();
      
      ws.onopen = () => {
        console.log("WebSocket connected");
        setIsConnected(true);
      };
      
      ws.onmessage = (event) => {
        const data = JSON.parse(event.data);
        console.log("WebSocket message:", data);
        
        if (data.type === "message") {
          setMessages(prev => [...prev, {
            role: "assistant",
            content: data.message
          }]);
          setIsTyping(false);
        } else if (data.type === "status") {
          // Handle status updates
          setIsTyping(true);
        } else if (data.type === "error") {
          toast({
            title: "Hata",
            description: data.message || "Bir hata oluştu",
            variant: "destructive",
          });
          setIsTyping(false);
        }
      };
      
      ws.onclose = () => {
        console.log("WebSocket disconnected");
        setIsConnected(false);
      };
      
      ws.onerror = (error) => {
        console.error("WebSocket error:", error);
        toast({
          title: "Bağlantı hatası",
          description: "Sunucu ile bağlantı kurulamadı",
          variant: "destructive",
        });
      };
      
      wsRef.current = ws;
      
      return () => {
        if (ws.readyState === WebSocket.OPEN) {
          ws.close();
        }
      };
    }
  }, [isAuthenticated, chatId, toast]);
  
  // Scroll to bottom when messages change
  useEffect(() => {
    if (scrollAreaRef.current) {
      const scrollContainer = scrollAreaRef.current;
      scrollContainer.scrollTop = scrollContainer.scrollHeight;
    }
  }, [messages]);
  
  // Handle message submission
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!input.trim()) return;
    if (!isConnected) {
      toast({
        title: "Bağlantı yok",
        description: "Sunucu ile bağlantı kurulamadı. Lütfen daha sonra tekrar deneyin.",
        variant: "destructive",
      });
      return;
    }
    
    // Add user message to state
    const userMessage: ChatMessage = {
      role: "user",
      content: input
    };
    
    setMessages(prev => [...prev, userMessage]);
    setInput("");
    setIsTyping(true);
    
    // Send message via WebSocket
    if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN) {
      wsRef.current.send(JSON.stringify({
        type: "ai_message",
        message: input,
        chatId: chatId
      }));
    } else {
      toast({
        title: "Bağlantı hatası",
        description: "Sunucu ile bağlantı kurulamadı. Lütfen sayfayı yenileyin.",
        variant: "destructive",
      });
      setIsTyping(false);
    }
  };
  
  // Handle demo message click
  const handleDemoMessageClick = (message: string) => {
    setInput(message);
  };
  
  if (!isAuthenticated) {
    return null;
  }
  
  return (
    <div className="flex flex-col h-full max-w-4xl mx-auto px-4 py-6">
      <div className="flex items-center mb-4">
        <Button 
          variant="ghost" 
          size="icon"
          onClick={() => navigate("/")}
          className="mr-2"
        >
          <ArrowLeft className="h-5 w-5" />
        </Button>
        <div className="flex items-center">
          <Avatar className="h-8 w-8 mr-2">
            <AvatarFallback className="bg-primary text-primary-foreground">
              <Bot className="h-4 w-4" />
            </AvatarFallback>
          </Avatar>
          <h1 className="text-xl font-bold">Müzik Yapay Zeka Asistanı</h1>
        </div>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 flex-1">
        {/* AI Chat Section */}
        <Card className="md:col-span-3 flex flex-col border-dark-100 bg-dark-200/50">
          <CardHeader className="py-3 border-b border-dark-100">
            <CardTitle className="text-lg flex items-center">
              <Bot className="h-5 w-5 mr-2 text-primary" />
              <span>MusicAI ile Sohbet</span>
            </CardTitle>
          </CardHeader>
          
          <ScrollArea 
            ref={scrollAreaRef}
            className="flex-1 p-4"
          >
            <div className="space-y-4">
              {messages.filter(m => m.role !== "system").map((message, i) => (
                <div
                  key={i}
                  className={cn(
                    "flex",
                    message.role === "assistant" ? "justify-start" : "justify-end"
                  )}
                >
                  <div
                    className={cn(
                      "max-w-[80%] px-4 py-3 rounded-lg",
                      message.role === "assistant" 
                        ? "bg-dark-100 text-white rounded-tl-none" 
                        : "bg-primary text-white rounded-tr-none"
                    )}
                  >
                    {message.content.split("\n").map((text, i) => (
                      <React.Fragment key={i}>
                        {text}
                        {i < message.content.split("\n").length - 1 && <br />}
                      </React.Fragment>
                    ))}
                  </div>
                </div>
              ))}
              
              {isTyping && (
                <div className="flex justify-start">
                  <div className="bg-dark-100 text-white rounded-lg rounded-tl-none max-w-[80%] px-4 py-3">
                    <div className="flex space-x-2">
                      <div className="w-2 h-2 rounded-full bg-gray-400 animate-bounce" />
                      <div className="w-2 h-2 rounded-full bg-gray-400 animate-bounce" style={{ animationDelay: "0.2s" }} />
                      <div className="w-2 h-2 rounded-full bg-gray-400 animate-bounce" style={{ animationDelay: "0.4s" }} />
                    </div>
                  </div>
                </div>
              )}
            </div>
          </ScrollArea>
          
          <CardFooter className="pt-3 pb-3 border-t border-dark-100">
            <form onSubmit={handleSubmit} className="flex w-full gap-2">
              <Input
                placeholder="Nasıl hissettiğinizi veya ne tür müzik dinlemek istediğinizi yazın..."
                value={input}
                onChange={(e) => setInput(e.target.value)}
                className="flex-1 bg-dark-100 border-dark-100 focus:border-primary"
                autoComplete="off"
              />
              <Button type="submit" disabled={!input.trim() || !isConnected}>
                <Send className="h-4 w-4" />
              </Button>
            </form>
          </CardFooter>
        </Card>
        
        {/* Suggestions Section */}
        <div className="hidden md:block">
          <MoodMusicGuide />
        </div>
      </div>
      
      {/* Mobile Suggestions */}
      <div className="block md:hidden mt-4">
        <MoodMusicGuide />
      </div>
    </div>
  );
}