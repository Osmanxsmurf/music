import { API_REQUEST_THROTTLE, API_TIMEOUT } from './constants';
import { throttle } from './utils';

// YouTube API entegrasyonu
const YOUTUBE_API_KEY = import.meta.env.VITE_YOUTUBE_API_KEY || import.meta.env.YOUTUBE_API_KEY;
const YOUTUBE_API_BASE = 'https://www.googleapis.com/youtube/v3';

// API kotası takip sistemi (günlük 10,000 birim ücretsiz limit)
let apiQuotaUsed = 0;
const MAX_DAILY_QUOTA = 10000; 
const QUOTA_RESET_INTERVAL = 24 * 60 * 60 * 1000; // 24 saat
const QUOTA_SAFETY_MARGIN = 0.9; // %90 limit
const QUOTA_STORAGE_KEY = 'youtube_api_quota';

// YouTube video sonuç tipi
interface YouTubeVideoResult {
  id: {
    kind: string;
    videoId: string;
  };
  snippet: {
    publishedAt: string;
    channelId: string;
    title: string;
    description: string;
    thumbnails: {
      default: { url: string; width: number; height: number };
      medium: { url: string; width: number; height: number };
      high: { url: string; width: number; height: number };
    };
    channelTitle: string;
    liveBroadcastContent: string;
  };
}

// Normalize edilmiş video sonucu
export interface NormalizedYouTubeVideo {
  id: string;
  title: string;
  channelTitle: string;
  description: string;
  thumbnailUrl: string;
  publishedAt: string;
  viewUrl: string;
}

// API çağrısı için kota maliyeti hesaplama
function calculateQuotaCost(endpoint: string, params: Record<string, string>): number {
  // Referans: 
  // list işlemleri: 1 birim
  // search işlemleri: 100 birim
  // video işlemleri: part parametresi sayısı kadar birim
  
  let cost = 1;
  
  if (endpoint === 'search') {
    cost = 100;
  }
  
  if (endpoint === 'videos' && params.part) {
    const parts = params.part.split(',');
    cost = parts.length;
  }
  
  return cost;
}

// Kota kullanımını güncelleme
function updateQuotaUsage(cost: number): void {
  apiQuotaUsed += cost;
  
  try {
    localStorage.setItem(QUOTA_STORAGE_KEY, apiQuotaUsed.toString());
  } catch (error) {
    console.warn('Kota bilgisi localStorage\'a kaydedilemedi:', error);
  }
  
  console.log(`YouTube API kullanılan kota: ${apiQuotaUsed}/${MAX_DAILY_QUOTA} birim (${(apiQuotaUsed / MAX_DAILY_QUOTA * 100).toFixed(2)}%)`);
  
  if (apiQuotaUsed >= MAX_DAILY_QUOTA * QUOTA_SAFETY_MARGIN) {
    console.warn(`YouTube API kotası limite yaklaşıyor: ${apiQuotaUsed}/${MAX_DAILY_QUOTA} birim kullanıldı`);
  }
}

// Yeterli kota kontrolü
function hasEnoughQuota(endpoint: string, params: Record<string, string> = {}): boolean {
  const cost = calculateQuotaCost(endpoint, params);
  return apiQuotaUsed + cost < MAX_DAILY_QUOTA;
}

// Kota sistemini başlatma
function initQuotaTracking(): void {
  try {
    const storedQuota = localStorage.getItem(QUOTA_STORAGE_KEY);
    const lastResetTime = localStorage.getItem(`${QUOTA_STORAGE_KEY}_last_reset`);
    
    if (storedQuota) {
      apiQuotaUsed = parseInt(storedQuota, 10);
    }
    
    // Günlük sıfırlama kontrolü
    if (lastResetTime) {
      const lastReset = parseInt(lastResetTime, 10);
      const now = Date.now();
      
      if (now - lastReset >= QUOTA_RESET_INTERVAL) {
        // Süre dolmuşsa kotayı sıfırla
        apiQuotaUsed = 0;
        localStorage.setItem(QUOTA_STORAGE_KEY, '0');
        localStorage.setItem(`${QUOTA_STORAGE_KEY}_last_reset`, now.toString());
      }
    } else {
      // İlk kez çalıştırılıyorsa son sıfırlama zamanını kaydet
      localStorage.setItem(`${QUOTA_STORAGE_KEY}_last_reset`, Date.now().toString());
    }
  } catch (error) {
    console.warn('Kota takip sistemi başlatılamadı:', error);
  }
}

// API'yi çağır
async function callYouTubeAPI<T>(
  endpoint: string, 
  params: Record<string, string> = {}
): Promise<T> {
  // Kota kontrolü
  if (!hasEnoughQuota(endpoint, params)) {
    throw new Error('YouTube API kota limiti aşıldı. Lütfen daha sonra tekrar deneyin.');
  }
  
  // API parametrelerini hazırla
  const queryParams = new URLSearchParams({
    ...params,
    key: YOUTUBE_API_KEY
  });
  
  const url = `${YOUTUBE_API_BASE}/${endpoint}?${queryParams.toString()}`;
  
  try {
    // Zaman aşımı kontrolü için Promise
    const timeoutPromise = new Promise((_, reject) => {
      setTimeout(() => reject(new Error('YouTube API isteği zaman aşımına uğradı')), API_TIMEOUT);
    });
    
    // API isteği
    const fetchPromise = fetch(url, {
      method: 'GET',
      headers: {
        'Accept': 'application/json'
      }
    });
    
    // Hangisi önce tamamlanırsa
    const response = await Promise.race([fetchPromise, timeoutPromise]) as Response;
    
    if (!response.ok) {
      throw new Error(`YouTube API hatası: ${response.status} ${response.statusText}`);
    }
    
    const data = await response.json();
    
    // Kota güncelleme
    updateQuotaUsage(calculateQuotaCost(endpoint, params));
    
    return data as T;
  } catch (error) {
    console.error('YouTube API hatası:', error);
    throw error;
  }
}

// YouTube API'deki sonuçları normalize et
function normalizeYouTubeVideos(videos: YouTubeVideoResult[]): NormalizedYouTubeVideo[] {
  return videos.map(video => ({
    id: video.id.videoId,
    title: video.snippet.title,
    channelTitle: video.snippet.channelTitle,
    description: video.snippet.description,
    thumbnailUrl: video.snippet.thumbnails.medium.url,
    publishedAt: video.snippet.publishedAt,
    viewUrl: `https://www.youtube.com/watch?v=${video.id.videoId}`
  }));
}

// YouTube'da arama yap
export const searchYouTube = throttle(async (
  query: string,
  maxResults: number = 10
): Promise<NormalizedYouTubeVideo[]> => {
  try {
    const response = await callYouTubeAPI<{
      items: YouTubeVideoResult[];
    }>('search', {
      part: 'snippet',
      maxResults: maxResults.toString(),
      q: query,
      type: 'video',
      videoCategoryId: '10', // Sadece müzik videolarını ara
      videoEmbeddable: 'true', // Sadece embed edilebilen videoları getir
    });
    
    return normalizeYouTubeVideos(response.items);
  } catch (error) {
    console.error('YouTube araması sırasında hata:', error);
    throw error;
  }
}, API_REQUEST_THROTTLE);

// Kota takip sistemini başlat
initQuotaTracking();