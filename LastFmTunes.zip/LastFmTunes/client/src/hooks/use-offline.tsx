import { useState, useEffect } from 'react';

export function useOffline(): boolean | null {
  const [isOffline, setIsOffline] = useState<boolean | null>(
    typeof navigator !== 'undefined' && typeof navigator.onLine === 'boolean' 
      ? !navigator.onLine 
      : null // null means we don't know yet
  );
  
  useEffect(() => {
    // Only run this on the client
    if (typeof window === 'undefined') return;
    
    const handleOnline = () => setIsOffline(false);
    const handleOffline = () => setIsOffline(true);
    
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    
    // Set initial state more accurately
    setIsOffline(!navigator.onLine);
    
    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);
  
  return isOffline;
}
