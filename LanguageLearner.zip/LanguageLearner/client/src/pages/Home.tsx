import { useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/contexts/AuthContext";
import { usePlayer } from "@/contexts/PlayerContext";
import AIAssistant from "@/components/AIAssistant";
import TrackCard from "@/components/TrackCard";
import PlaylistCard from "@/components/PlaylistCard";
import ArtistCard from "@/components/ArtistCard";
import AlbumCard from "@/components/AlbumCard";
import { Link } from "wouter";
import { useToast } from "@/hooks/use-toast";

// Demo data - would come from API in production
const mockRecentlyPlayed = [
  { id: 1, title: "Seni Dert Etmeler", artist: "Mabel Matiz", coverImage: "https://images.unsplash.com/photo-1470225620780-dba8ba36b745?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=300" },
  { id: 2, title: "Boynun Borcu", artist: "Duman", coverImage: "https://images.unsplash.com/photo-1494232410401-ad00d5433cfa?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=300" },
  { id: 3, title: "İmkansızım", artist: "Ezhel", coverImage: "https://images.unsplash.com/photo-1558584673-c834fb1cc3ca?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=300" },
  { id: 4, title: "Cambaz", artist: "Adamlar", coverImage: "https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=300" },
  { id: 5, title: "Bir Derdim Var", artist: "mor ve ötesi", coverImage: "https://images.unsplash.com/photo-1526218626217-dc65a29bb444?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=300" },
  { id: 6, title: "Taş", artist: "Sezen Aksu", coverImage: "https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=300" }
];

const mockPlaylists = [
  { id: 1, name: "Türkçe Rock Seçkisi", description: "En iyi Türkçe rock şarkıları", coverImage: "https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400", trackCount: 32, duration: 8100 },
  { id: 2, name: "Akustik Kahve Molası", description: "Kahve eşliğinde dinlenebilecek akustik parçalar", coverImage: "https://images.unsplash.com/photo-1506157786151-b8491531f063?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400", trackCount: 45, duration: 11220 },
  { id: 3, name: "Haftasonu Enerjisi", description: "Enerjinizi yükseltecek parçalar", coverImage: "https://images.unsplash.com/photo-1511367461989-f85a21fda167?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400", trackCount: 28, duration: 6720 },
  { id: 4, name: "90'lar Türkçe Pop", description: "Nostaljik 90'lar Türkçe pop şarkıları", coverImage: "https://images.unsplash.com/photo-1458560871784-56d23406c091?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400", trackCount: 50, duration: 13500 }
];

const mockArtists = [
  { id: 1, name: "Tarkan", image: "https://images.unsplash.com/photo-1549213783-8284d0336c4f?ixlib=rb-4.0.3&auto=format&fit=crop&w=200&h=200" },
  { id: 2, name: "Sezen Aksu", image: "https://images.unsplash.com/photo-1516223725307-6f76b9ec8742?ixlib=rb-4.0.3&auto=format&fit=crop&w=200&h=200" },
  { id: 3, name: "Murat Boz", image: "https://images.unsplash.com/photo-1511367461989-f85a21fda167?ixlib=rb-4.0.3&auto=format&fit=crop&w=200&h=200" },
  { id: 4, name: "Sıla", image: "https://images.unsplash.com/photo-1513829596324-4bb2800c5efb?ixlib=rb-4.0.3&auto=format&fit=crop&w=200&h=200" },
  { id: 5, name: "Teoman", image: "https://images.unsplash.com/photo-1549213783-8284d0336c4f?ixlib=rb-4.0.3&auto=format&fit=crop&w=200&h=200" },
  { id: 6, name: "Hadise", image: "https://images.unsplash.com/photo-1606041008023-472dfb5e530f?ixlib=rb-4.0.3&auto=format&fit=crop&w=200&h=200" },
  { id: 7, name: "Mabel Matiz", image: "https://images.unsplash.com/photo-1463453091185-61582044d556?ixlib=rb-4.0.3&auto=format&fit=crop&w=200&h=200" }
];

const mockNewReleases = [
  { id: 1, title: "Rüya", artist: "Emir Can İğrek", year: "2023", coverImage: "https://images.unsplash.com/photo-1598387846148-47e82ee120cc?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=300" },
  { id: 2, title: "Rengarenk", artist: "Zeynep Bastık", year: "2023", coverImage: "https://images.unsplash.com/photo-1598387846148-47e82ee120cc?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=300" },
  { id: 3, title: "Uzak", artist: "Duman", year: "2023", coverImage: "https://images.unsplash.com/photo-1557682250-33bd709cbe85?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=300" },
  { id: 4, title: "Yollar", artist: "Adamlar", year: "2023", coverImage: "https://images.unsplash.com/photo-1557682250-33bd709cbe85?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=300" },
  { id: 5, title: "Gölge", artist: "Melike Şahin", year: "2023", coverImage: "https://images.unsplash.com/photo-1586165368502-1bad197a6461?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=300" },
  { id: 6, title: "Gecenin Kanatları", artist: "Mor ve Ötesi", year: "2023", coverImage: "https://images.unsplash.com/photo-1557682250-33bd709cbe85?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=300" }
];

export default function Home() {
  const { user } = useAuth();
  const { playTrack } = usePlayer();
  const { toast } = useToast();

  // Fetch recently played tracks
  const { data: recentlyPlayed = mockRecentlyPlayed } = useQuery({
    queryKey: ["/api/tracks/recent"],
    enabled: !!user,
  });
  
  // Handle playing a track
  const handlePlayTrack = (track: any) => {
    playTrack(track);
  };
  
  // Handle playing a playlist
  const handlePlayPlaylist = (playlist: any) => {
    // In a real implementation, we would fetch all tracks in the playlist and queue them
    toast({
      title: "Çalma listesi başlatıldı",
      description: `"${playlist.name}" çalma listesi başlatıldı`,
    });
  };
  
  // Handle viewing an artist
  const handleViewArtist = (artist: any) => {
    toast({
      title: "Sanatçı sayfası",
      description: `${artist.name} sayfası henüz geliştirme aşamasında`,
    });
  };

  return (
    <div className="p-4 md:p-8 pb-32">
      {/* Hero Section */}
      <div className="mb-8">
        <h1 className="text-2xl md:text-3xl font-bold mb-2">Hoş Geldin, {user?.fullName.split(' ')[0] || 'Misafir'}</h1>
        <p className="text-muted-foreground">Bugün senin için seçtiğimiz müzikler</p>
      </div>
      
      {/* AI Assistant Section */}
      <AIAssistant />
      
      {/* Recently Played */}
      <section className="mb-8">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xl font-bold">Son Çalınanlar</h2>
          <Link href="/library/recent">
            <a className="text-sm text-primary hover:underline">Tümünü Gör</a>
          </Link>
        </div>
        
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4">
          {recentlyPlayed.map((track) => (
            <TrackCard key={track.id} track={track} />
          ))}
        </div>
      </section>
      
      {/* Recommended Playlists */}
      <section className="mb-8">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xl font-bold">Önerilen Çalma Listeleri</h2>
          <Link href="/library/playlists">
            <a className="text-sm text-primary hover:underline">Tümünü Gör</a>
          </Link>
        </div>
        
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-4 gap-4">
          {mockPlaylists.map((playlist) => (
            <PlaylistCard 
              key={playlist.id} 
              playlist={playlist} 
              onPlay={handlePlayPlaylist}
            />
          ))}
        </div>
      </section>
      
      {/* Popular Artists */}
      <section className="mb-8">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xl font-bold">Popüler Sanatçılar</h2>
          <Link href="/artists">
            <a className="text-sm text-primary hover:underline">Tümünü Gör</a>
          </Link>
        </div>
        
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 xl:grid-cols-7 gap-4">
          {mockArtists.map((artist) => (
            <ArtistCard 
              key={artist.id} 
              artist={artist} 
              onView={handleViewArtist}
            />
          ))}
        </div>
      </section>
      
      {/* New Releases */}
      <section className="mb-8">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xl font-bold">Yeni Çıkanlar</h2>
          <Link href="/new-releases">
            <a className="text-sm text-primary hover:underline">Tümünü Gör</a>
          </Link>
        </div>
        
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4">
          {mockNewReleases.map((album) => (
            <AlbumCard key={album.id} album={album} />
          ))}
        </div>
      </section>
    </div>
  );
}
