import { useState, useEffect } from 'react';

// Hook to detect if the current device is a mobile device
export function useMobile() {
  const [isMobile, setIsMobile] = useState(false);
  
  useEffect(() => {
    // Check if window is defined (for SSR)
    if (typeof window === 'undefined') return;
    
    // Function to check viewport width
    const checkMobile = () => {
      // 768px is a common breakpoint for mobile devices
      setIsMobile(window.innerWidth < 768);
    };
    
    // Check on mount
    checkMobile();
    
    // Add resize event listener
    window.addEventListener('resize', checkMobile);
    
    // Clean up
    return () => {
      window.removeEventListener('resize', checkMobile);
    };
  }, []);
  
  return isMobile;
}

export default useMobile;
