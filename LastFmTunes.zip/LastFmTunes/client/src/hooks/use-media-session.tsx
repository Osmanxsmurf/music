import { useEffect } from 'react';
import type { Song } from '@shared/schema';

export function useMediaSession(
  currentSong: Song | null, 
  isPlaying: boolean,
  pauseSong: () => void,
  resumeSong: () => void,
  skipToNext: () => void,
  skipToPrevious: () => void
) {
  useEffect(() => {
    if (!currentSong) return;
    
    // Check if Media Session API is supported
    if ('mediaSession' in navigator) {
      navigator.mediaSession.metadata = new MediaMetadata({
        title: currentSong.title,
        artist: currentSong.artist,
        album: currentSong.album || '',
        artwork: [
          { src: currentSong.coverArt || '', sizes: '512x512', type: 'image/jpeg' }
        ]
      });
      
      // Update playback state
      navigator.mediaSession.playbackState = isPlaying ? 'playing' : 'paused';
      
      // Set action handlers
      navigator.mediaSession.setActionHandler('play', resumeSong);
      navigator.mediaSession.setActionHandler('pause', pauseSong);
      navigator.mediaSession.setActionHandler('nexttrack', skipToNext);
      navigator.mediaSession.setActionHandler('previoustrack', skipToPrevious);
      
      // More advanced handlers could be added here:
      // - seekbackward
      // - seekforward
      // - seekto
      // - stop
    }
    
    return () => {
      if ('mediaSession' in navigator) {
        // Clear handlers on cleanup
        navigator.mediaSession.setActionHandler('play', null);
        navigator.mediaSession.setActionHandler('pause', null);
        navigator.mediaSession.setActionHandler('nexttrack', null);
        navigator.mediaSession.setActionHandler('previoustrack', null);
      }
    };
  }, [currentSong, isPlaying, pauseSong, resumeSong, skipToNext, skipToPrevious]);
}
