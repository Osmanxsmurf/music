import { db } from './db';
import { songs } from '@shared/schema';
import { eq, like, ilike, SQL, or, and } from 'drizzle-orm';

// Popüler sanatçılar ve onların popüler şarkıları
interface ArtistInfo {
  id: string;
  name: string;
  similarNames: string[]; // Alternatif yazımlar
  popularSongs: Array<{
    title: string;
    year?: number;
  }>;
}

// Türkçe ses uyumuna göre sanatçı adı varyasyonları oluşturur
function generateNameVariations(name: string): string[] {
  const variations: string[] = [name];
  const normalized = name.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "");
  if (normalized !== name.toLowerCase()) variations.push(normalized);
  
  // Türkçe karakterler için alternatifler
  const replacements: Record<string, string> = {
    'ş': 's', 'ğ': 'g', 'ı': 'i', 'ö': 'o', 'ü': 'u', 'ç': 'c',
    'Ş': 'S', 'Ğ': 'G', 'İ': 'I', 'Ö': 'O', 'Ü': 'U', 'Ç': 'C'
  };
  
  let turkishVersion = name;
  let englishVersion = name;
  
  Object.entries(replacements).forEach(([tr, en]) => {
    if (name.includes(tr)) {
      englishVersion = englishVersion.replace(new RegExp(tr, 'g'), en);
    } else if (name.includes(en)) {
      turkishVersion = turkishVersion.replace(new RegExp(en, 'g'), tr);
    }
  });
  
  if (turkishVersion !== name) variations.push(turkishVersion);
  if (englishVersion !== name) variations.push(englishVersion);
  
  return [...new Set(variations)]; // Benzersiz değerler
}

// Popüler sanatçıların listesi
const popularArtists: ArtistInfo[] = [
  {
    id: "dua-lipa",
    name: "Dua Lipa",
    similarNames: ["dualipa", "dua lipa", "dua"],
    popularSongs: [
      { title: "Don't Start Now", year: 2019 },
      { title: "Levitating", year: 2020 },
      { title: "New Rules", year: 2017 },
      { title: "Physical", year: 2020 },
      { title: "One Kiss", year: 2018 }
    ]
  },
  {
    id: "rihanna",
    name: "Rihanna",
    similarNames: ["rihana", "riri", "ri ri"],
    popularSongs: [
      { title: "Diamonds", year: 2012 },
      { title: "Umbrella", year: 2007 },
      { title: "Work", year: 2016 },
      { title: "Love On The Brain", year: 2016 },
      { title: "Stay", year: 2012 }
    ]
  },
  {
    id: "the-weeknd",
    name: "The Weeknd",
    similarNames: ["weeknd", "the weekend", "weekend", "abel tesfaye", "abel"],
    popularSongs: [
      { title: "Blinding Lights", year: 2019 },
      { title: "Save Your Tears", year: 2020 },
      { title: "Starboy", year: 2016 },
      { title: "Die For You", year: 2016 },
      { title: "The Hills", year: 2015 }
    ]
  },
  {
    id: "coldplay",
    name: "Coldplay",
    similarNames: ["cold play"],
    popularSongs: [
      { title: "Yellow", year: 2000 },
      { title: "Fix You", year: 2005 },
      { title: "Viva La Vida", year: 2008 },
      { title: "Paradise", year: 2011 },
      { title: "A Sky Full of Stars", year: 2014 }
    ]
  },
  {
    id: "billie-eilish",
    name: "Billie Eilish",
    similarNames: ["billie", "billy eilish", "bili ailish"],
    popularSongs: [
      { title: "Bad Guy", year: 2019 },
      { title: "Everything I Wanted", year: 2019 },
      { title: "Happier Than Ever", year: 2021 },
      { title: "Ocean Eyes", year: 2016 },
      { title: "lovely", year: 2018 }
    ]
  },
  {
    id: "taylor-swift",
    name: "Taylor Swift",
    similarNames: ["taylor", "t swift", "swift"],
    popularSongs: [
      { title: "Anti-Hero", year: 2022 },
      { title: "Blank Space", year: 2014 },
      { title: "Cruel Summer", year: 2019 },
      { title: "Love Story", year: 2008 },
      { title: "Shake It Off", year: 2014 }
    ]
  },
  {
    id: "beyonce",
    name: "Beyoncé",
    similarNames: ["beyonce", "bey", "queen b", "queen bey", "bejonse"],
    popularSongs: [
      { title: "Halo", year: 2008 },
      { title: "Single Ladies", year: 2008 },
      { title: "Crazy In Love", year: 2003 },
      { title: "Formation", year: 2016 },
      { title: "Irreplaceable", year: 2006 }
    ]
  },
  {
    id: "drake",
    name: "Drake",
    similarNames: ["drizzy", "champagne papi", "6 god", "aubrey"],
    popularSongs: [
      { title: "God's Plan", year: 2018 },
      { title: "Hotline Bling", year: 2015 },
      { title: "One Dance", year: 2016 },
      { title: "In My Feelings", year: 2018 },
      { title: "Started From The Bottom", year: 2013 }
    ]
  },
  {
    id: "justin-bieber",
    name: "Justin Bieber",
    similarNames: ["bieber", "jb", "justin"],
    popularSongs: [
      { title: "Sorry", year: 2015 },
      { title: "Love Yourself", year: 2015 },
      { title: "What Do You Mean?", year: 2015 },
      { title: "Stay", year: 2021 },
      { title: "Peaches", year: 2021 }
    ]
  },
  {
    id: "tarkan",
    name: "Tarkan",
    similarNames: ["megastar", "tarkan tevetoğlu", "tarkan tevetoglu"],
    popularSongs: [
      { title: "Şımarık", year: 1997 },
      { title: "Kuzu Kuzu", year: 2001 },
      { title: "Dudu", year: 2003 },
      { title: "Yolla", year: 2017 },
      { title: "10", year: 2017 }
    ]
  },
  {
    id: "mfo",
    name: "MFÖ",
    similarNames: ["mazhar fuat özkan", "mazhar fuat ozkan", "m.f.ö."],
    popularSongs: [
      { title: "Ele Güne Karşı", year: 1985 },
      { title: "Sarı Laleler", year: 1986 },
      { title: "Peki Peki Anladık", year: 1987 },
      { title: "Ali Desidero", year: 1983 },
      { title: "Mazeretim Var Asabiyim Ben", year: 1994 }
    ]
  },
  {
    id: "sezen-aksu",
    name: "Sezen Aksu",
    similarNames: ["minik serçe", "minik serce", "sezen"],
    popularSongs: [
      { title: "Gülümse", year: 1991 },
      { title: "Beni Unutma", year: 1990 },
      { title: "Firuze", year: 1982 },
      { title: "Kutlama", year: 1998 },
      { title: "Kaybolan Yıllar", year: 1986 }
    ]
  },
];

// Sanatçı adlarının tüm varyasyonlarını oluştur
const artistsWithVariations = popularArtists.map(artist => {
  const variations = [
    ...artist.similarNames,
    ...generateNameVariations(artist.name)
  ];
  return {
    ...artist,
    similarNames: [...new Set(variations)] // Tekrarlı olanları çıkar
  };
});

// Müzik tür/türleri
const musicGenres = [
  "Pop", "Rock", "Hip Hop", "Rap", "R&B", "Electronic", "Dance", "EDM",
  "Classical", "Jazz", "Blues", "Country", "Folk", "Indie", "Alternative",
  "Metal", "Punk", "Soul", "Funk", "Reggae", "Disco", "House", "Ambient",
  "Türkçe Pop", "Arabesk", "Halk Müziği", "Klasik Türk Müziği", "Özgün"
];

// Müzik ruh hali tipleri
const moodTypes = [
  "Energetic", "Happy", "Chill", "Sad", "Relaxing", "Party", "Focus", "Study",
  "Workout", "Dance", "Romantic", "Sleep", "Dinner", "Morning", "Night", 
  "Angry", "Emotional", "Nostalgic", "Epic", "Motivational",
  "Enerjik", "Mutlu", "Sakin", "Üzgün", "Rahatlatıcı", "Parti", "Odak", "Ders",
  "Spor", "Dans", "Romantik", "Uyku", "Akşam Yemeği", "Sabah", "Gece", 
  "Kızgın", "Duygusal", "Nostaljik", "Epik", "Motive Edici"
];

// Zaman dilimleri
const dayParts = [
  "Morning", "Afternoon", "Evening", "Night", "Midnight", "Dawn",
  "Sabah", "Öğle", "Akşam", "Gece", "Gece Yarısı", "Şafak"
];

// Duygu durumları
const emotions = [
  "Happy", "Sad", "Angry", "Excited", "Calm", "Anxious", "Relaxed", "Stressed",
  "Nostalgic", "Bored", "Lonely", "Motivated", "Inspired", "Tired", "Energetic",
  "Mutlu", "Üzgün", "Kızgın", "Heyecanlı", "Sakin", "Endişeli", "Rahat", "Stresli",
  "Nostaljik", "Sıkılmış", "Yalnız", "Motive", "İlham Almış", "Yorgun", "Enerjik"
];

// Basit istek kalıpları
const requestPatterns = [
  "play", "listen", "recommend", "find", "show", "suggest", "give",
  "çal", "dinle", "öner", "bul", "göster", "tavsiye et", "ver", "çalsana", "dinlemek istiyorum", 
  "istiyorum", "lazım", "arıyorum", "bakıyorum"
];

// Müzik aktiviteleri
const musicActivities = [
  "dance", "sing", "study", "work", "sleep", "exercise", "workout", "run", "meditate",
  "dans", "şarkı söyle", "ders çalış", "çalış", "uyu", "egzersiz", "spor", "koş", "meditasyon yap"
];

// İstek tipleri (ayrıştırma için)
export enum RequestType {
  ARTIST_REQUEST = 'artist',
  SONG_REQUEST = 'song',
  GENRE_REQUEST = 'genre',
  MOOD_REQUEST = 'mood',
  ACTIVITY_REQUEST = 'activity',
  GENERAL_REQUEST = 'general'
}

// Kullanıcı isteği analiz sonucu
export interface RequestAnalysis {
  type: RequestType;
  confidence: number;
  artist?: string;
  artistId?: string;
  song?: string;
  genre?: string;
  mood?: string;
  activity?: string;
  dayPart?: string;
  emotion?: string;
  requestPattern?: string;
}

// Metin içindeki anahtar kelimeleri kontrol eder
function checkForKeywords(text: string, keywords: string[]): { found: boolean, keyword: string, score: number } {
  const normalizedText = text.toLowerCase();
  
  for (const keyword of keywords) {
    // Tam eşleşme
    if (normalizedText.includes(keyword.toLowerCase())) {
      // Tam kelime eşleşmesi için puan artışı (ör: "pop müzik" vs "popüler")
      const exactWordMatch = new RegExp(`\\b${keyword.toLowerCase()}\\b`).test(normalizedText);
      return { 
        found: true, 
        keyword: keyword, 
        score: exactWordMatch ? 1.0 : 0.7 
      };
    }
    
    // Yaklaşık eşleşme (Levenshtein mesafesi gibi algoritmalar kullanılabilir)
    // Basit implementasyon olarak 3 karakter ve fazlası için kısmi eşleşme kontrolü
    if (keyword.length >= 4 && normalizedText.includes(keyword.toLowerCase().substring(0, keyword.length - 1))) {
      return { found: true, keyword: keyword, score: 0.5 };
    }
  }
  
  return { found: false, keyword: '', score: 0 };
}

// Mesajdan sanatçı ismini tespit eder
function detectArtist(message: string): { found: boolean, artist: ArtistInfo, score: number } {
  const normalizedMessage = message.toLowerCase();
  
  for (const artist of artistsWithVariations) {
    // Ana sanatçı adını kontrol et
    if (normalizedMessage.includes(artist.name.toLowerCase())) {
      return { found: true, artist, score: 1.0 };
    }
    
    // Alternatif isimleri kontrol et
    for (const altName of artist.similarNames) {
      if (normalizedMessage.includes(altName.toLowerCase())) {
        // Bu bir tam isim mi yoksa kısaltma/takma isim mi diye kontrol et
        const isFullName = altName.split(' ').length > 1;
        return { found: true, artist, score: isFullName ? 0.9 : 0.7 };
      }
    }
  }
  
  return { found: false, artist: null as any, score: 0 };
}

// Mesajdan şarkı ismini tespit eder
function detectSong(message: string, detectedArtist?: ArtistInfo): { found: boolean, song: string, artist?: ArtistInfo, score: number } {
  const normalizedMessage = message.toLowerCase();
  
  // Eğer sanatçı tespit edilmişse, o sanatçının popüler şarkılarını kontrol et
  if (detectedArtist) {
    for (const song of detectedArtist.popularSongs) {
      if (normalizedMessage.includes(song.title.toLowerCase())) {
        return { found: true, song: song.title, artist: detectedArtist, score: 1.0 };
      }
    }
  }
  
  // Tüm sanatçıların popüler şarkılarını kontrol et
  for (const artist of artistsWithVariations) {
    for (const song of artist.popularSongs) {
      if (normalizedMessage.includes(song.title.toLowerCase())) {
        return { found: true, song: song.title, artist, score: 0.8 };
      }
    }
  }
  
  return { found: false, song: '', score: 0 };
}

// Kullanıcının isteğini analiz eder
export async function analyzeRequest(message: string): Promise<RequestAnalysis> {
  const normalizedMessage = message.toLowerCase();
  const analysis: RequestAnalysis = {
    type: RequestType.GENERAL_REQUEST,
    confidence: 0.5,
  };
  
  // İstek türünü belirle
  const requestPatternResult = checkForKeywords(normalizedMessage, requestPatterns);
  if (requestPatternResult.found) {
    analysis.requestPattern = requestPatternResult.keyword;
  }
  
  // Sanatçı tespit et
  const artistResult = detectArtist(normalizedMessage);
  if (artistResult.found) {
    analysis.type = RequestType.ARTIST_REQUEST;
    analysis.artist = artistResult.artist.name;
    analysis.artistId = artistResult.artist.id;
    analysis.confidence = artistResult.score;
    
    // Şarkı tespit et
    const songResult = detectSong(normalizedMessage, artistResult.artist);
    if (songResult.found) {
      analysis.type = RequestType.SONG_REQUEST;
      analysis.song = songResult.song;
      analysis.confidence = Math.max(analysis.confidence, songResult.score);
    }
  } else {
    // Sanatçısız şarkı tespit et
    const generalSongResult = detectSong(normalizedMessage);
    if (generalSongResult.found) {
      analysis.type = RequestType.SONG_REQUEST;
      analysis.song = generalSongResult.song;
      if (generalSongResult.artist) {
        analysis.artist = generalSongResult.artist.name;
        analysis.artistId = generalSongResult.artist.id;
      }
      analysis.confidence = generalSongResult.score;
    }
  }
  
  // Tür tespit et
  const genreResult = checkForKeywords(normalizedMessage, musicGenres);
  if (genreResult.found) {
    if (analysis.type === RequestType.GENERAL_REQUEST) {
      analysis.type = RequestType.GENRE_REQUEST;
    }
    analysis.genre = genreResult.keyword;
    if (analysis.confidence < genreResult.score) {
      analysis.confidence = genreResult.score;
    }
  }
  
  // Ruh hali tespit et
  const moodResult = checkForKeywords(normalizedMessage, moodTypes);
  if (moodResult.found) {
    if (analysis.type === RequestType.GENERAL_REQUEST) {
      analysis.type = RequestType.MOOD_REQUEST;
    }
    analysis.mood = moodResult.keyword;
    if (analysis.confidence < moodResult.score) {
      analysis.confidence = moodResult.score;
    }
  }
  
  // Aktivite tespit et
  const activityResult = checkForKeywords(normalizedMessage, musicActivities);
  if (activityResult.found) {
    if (analysis.type === RequestType.GENERAL_REQUEST) {
      analysis.type = RequestType.ACTIVITY_REQUEST;
    }
    analysis.activity = activityResult.keyword;
    if (analysis.confidence < activityResult.score) {
      analysis.confidence = activityResult.score;
    }
  }
  
  // Günün bölümü tespit et
  const dayPartResult = checkForKeywords(normalizedMessage, dayParts);
  if (dayPartResult.found) {
    analysis.dayPart = dayPartResult.keyword;
  }
  
  // Duygu durumu tespit et
  const emotionResult = checkForKeywords(normalizedMessage, emotions);
  if (emotionResult.found) {
    analysis.emotion = emotionResult.keyword;
  }
  
  return analysis;
}

// Belirli bir sanatçının en popüler şarkılarını döndürür
export async function getArtistTopSongs(artistId: string, limit: number = 5): Promise<any[]> {
  const artist = popularArtists.find(a => a.id === artistId);
  
  if (artist) {
    try {
      // Önce veritabanında bu sanatçıya ait şarkıları ara
      const dbSongs = await db.select().from(songs)
        .where(or(
          eq(songs.artist, artist.name),
          ilike(songs.artist, `%${artist.name}%`)
        ))
        .limit(limit);
      
      // Veritabanında varsa onları döndür
      if (dbSongs.length > 0) {
        return dbSongs;
      }
      
      // Veritabanında yoksa, sabit verideki popüler şarkılardan yeni Song nesneleri oluştur
      const mockSongs = artist.popularSongs.map((song, index) => {
        return {
          id: index + 1000, // Benzersiz ID (gerçek veritabanında bu farklı olacak)
          title: song.title,
          artist: artist.name,
          albumCover: `https://source.unsplash.com/300x300/?music,album,${encodeURIComponent(artist.name)}`,
          duration: Math.floor(Math.random() * 120) + 180, // 3-5 dakika arası
          url: "", // Gerçek URL
          genre: "Pop", // Varsayılan
          mood: index % 2 === 0 ? "Energetic" : "Chill", // Örnek
          releaseYear: song.year || new Date().getFullYear(),
          playCount: Math.floor(Math.random() * 1000) + 500,
          likeCount: Math.floor(Math.random() * 500) + 100,
        };
      });
      
      return mockSongs;
    } catch (error) {
      console.error("Error fetching artist top songs:", error);
      // Hata durumunda sabit verilerdeki popüler şarkıları döndür
      return artist.popularSongs.map((song, index) => ({
        id: index + 1000,
        title: song.title,
        artist: artist.name,
        albumCover: `https://source.unsplash.com/300x300/?music,album,${encodeURIComponent(artist.name)}`,
        duration: Math.floor(Math.random() * 120) + 180,
        url: "",
        genre: "Pop",
        mood: index % 2 === 0 ? "Energetic" : "Chill",
        releaseYear: song.year || new Date().getFullYear(),
        playCount: Math.floor(Math.random() * 1000) + 500,
        likeCount: Math.floor(Math.random() * 500) + 100,
      }));
    }
  }
  
  return [];
}

// Belirli bir ruh haline veya türe göre şarkıları döndürür
export async function getSongsByMoodOrGenre(
  mood?: string, 
  genre?: string, 
  activity?: string, 
  limit: number = 5
): Promise<any[]> {
  try {
    const conditions: SQL[] = [];
    
    if (mood) {
      conditions.push(ilike(songs.mood, `%${mood}%`));
    }
    
    if (genre) {
      conditions.push(ilike(songs.genre, `%${genre}%`));
    }
    
    // Aktiviteye göre uygun mood eşleştirmesi
    if (activity) {
      if (activity.toLowerCase().includes('workout') || 
          activity.toLowerCase().includes('exercise') || 
          activity.toLowerCase().includes('run') ||
          activity.toLowerCase().includes('spor') || 
          activity.toLowerCase().includes('koş')) {
        conditions.push(or(
          ilike(songs.mood, '%energetic%'),
          ilike(songs.mood, '%upbeat%'),
          ilike(songs.mood, '%motivational%'),
          ilike(songs.mood, '%enerjik%'),
          ilike(songs.mood, '%motive%')
        ));
      } else if (activity.toLowerCase().includes('study') || 
                 activity.toLowerCase().includes('work') ||
                 activity.toLowerCase().includes('çalış') || 
                 activity.toLowerCase().includes('ders')) {
        conditions.push(or(
          ilike(songs.mood, '%focus%'),
          ilike(songs.mood, '%calm%'),
          ilike(songs.mood, '%instrumental%'),
          ilike(songs.mood, '%odak%'),
          ilike(songs.mood, '%sakin%')
        ));
      } else if (activity.toLowerCase().includes('sleep') || 
                 activity.toLowerCase().includes('uyu')) {
        conditions.push(or(
          ilike(songs.mood, '%calm%'),
          ilike(songs.mood, '%relaxing%'),
          ilike(songs.mood, '%ambient%'),
          ilike(songs.mood, '%sakin%'),
          ilike(songs.mood, '%rahatlat%')
        ));
      } else if (activity.toLowerCase().includes('dance') || 
                 activity.toLowerCase().includes('party') ||
                 activity.toLowerCase().includes('dans') || 
                 activity.toLowerCase().includes('parti')) {
        conditions.push(or(
          ilike(songs.mood, '%dance%'),
          ilike(songs.mood, '%upbeat%'),
          ilike(songs.mood, '%energetic%'),
          ilike(songs.mood, '%party%'),
          ilike(songs.mood, '%dans%'),
          ilike(songs.mood, '%enerjik%')
        ));
      }
    }
    
    // Koşulları birleştir
    const whereClause = conditions.length > 0 
      ? and(...conditions) 
      : undefined;
    
    // Veritabanından uygun şarkıları al
    const dbSongs = whereClause 
      ? await db.select().from(songs).where(whereClause).limit(limit)
      : await db.select().from(songs).limit(limit);
    
    // Veritabanında varsa onları döndür
    if (dbSongs.length > 0) {
      return dbSongs;
    }
    
    // Veritabanında yoksa, sabit veri oluştur
    // Gerçek uygulamada bu kısım yerine veritabanı kullanılacak
    const mockGenre = genre || (activity ? mapActivityToGenre(activity) : "Pop");
    const mockMood = mood || (activity ? mapActivityToMood(activity) : "Energetic");
    
    return generateMockSongs(mockGenre, mockMood, limit);
  } catch (error) {
    console.error("Error fetching songs by mood or genre:", error);
    return [];
  }
}

// Aktiviteyi tür ile eşleştirir
function mapActivityToGenre(activity: string): string {
  const activityLC = activity.toLowerCase();
  
  if (activityLC.includes('workout') || activityLC.includes('exercise') || activityLC.includes('spor')) {
    return "Electronic";
  } else if (activityLC.includes('study') || activityLC.includes('work') || activityLC.includes('ders')) {
    return "Classical";
  } else if (activityLC.includes('sleep') || activityLC.includes('uyu')) {
    return "Ambient";
  } else if (activityLC.includes('dance') || activityLC.includes('party') || activityLC.includes('dans')) {
    return "Dance";
  } else {
    return "Pop";
  }
}

// Aktiviteyi ruh hali ile eşleştirir
function mapActivityToMood(activity: string): string {
  const activityLC = activity.toLowerCase();
  
  if (activityLC.includes('workout') || activityLC.includes('exercise') || activityLC.includes('spor')) {
    return "Energetic";
  } else if (activityLC.includes('study') || activityLC.includes('work') || activityLC.includes('ders')) {
    return "Focus";
  } else if (activityLC.includes('sleep') || activityLC.includes('uyu')) {
    return "Relaxing";
  } else if (activityLC.includes('dance') || activityLC.includes('party') || activityLC.includes('dans')) {
    return "Party";
  } else {
    return "Happy";
  }
}

// Örnek şarkılar oluşturur
function generateMockSongs(genre: string, mood: string, count: number): any[] {
  const sampleArtists = [
    "The Weeknd", "Dua Lipa", "Billie Eilish", "Ed Sheeran", "Taylor Swift",
    "Tarkan", "Sezen Aksu", "MFÖ", "Teoman", "Sertab Erener"
  ];
  
  return Array(count).fill(0).map((_, index) => {
    const artist = sampleArtists[Math.floor(Math.random() * sampleArtists.length)];
    return {
      id: index + 2000,
      title: `${mood} ${genre} Song ${index + 1}`,
      artist: artist,
      albumCover: `https://source.unsplash.com/300x300/?music,album,${encodeURIComponent(genre)}`,
      duration: Math.floor(Math.random() * 120) + 180,
      url: "",
      genre: genre,
      mood: mood,
      releaseYear: 2023,
      playCount: Math.floor(Math.random() * 1000) + 100,
      likeCount: Math.floor(Math.random() * 300) + 50,
    };
  });
}