import { XataClient } from '@xata.io/client';

// Xata istemcisini oluştur
const xata = new XataClient({
  apiKey: process.env.XATA_API_KEY || 'au_BJzzy94NsG0clOMuEXDC6747Qi2r07mJ0',
  databaseURL: process.env.XATA_DATABASE_URL || 'https://Osman-zdo-an-s-workspace-rbheop.eu-central-1.xata.sh/db/music_assistant:main'
});

// Xata veritabanı servisini dışa aktar
export { xata };

// Müzik önerileri için Türkçe anahtar kelime tabanlı basit bir öneri motoru
export const getMusicRecommendation = (query: string) => {
  // Sorguyu küçük harfe çevir
  const lowerQuery = query.toLowerCase();
  
  // Öneriler için sabit veri
  const recommendations = {
    pop: [
      { artist: "Tarkan", title: "Kuzu Kuzu", albumArt: "https://i.scdn.co/image/ab67616d0000b2737d214af8499aa95ad220f573" },
      { artist: "Sezen Aksu", title: "Seni Yerler", albumArt: "https://i.scdn.co/image/ab67616d0000b273b3919e1d2bac71d1c33b2a5e" },
      { artist: "Kenan Doğulu", title: "Çakkıdı", albumArt: "https://i.scdn.co/image/ab67616d0000b2731cb9f10164327dfb456f87a7" },
      { artist: "Mabel Matiz", title: "Öyle Kolaysa", albumArt: "https://i.scdn.co/image/ab67616d0000b273e8bab3ad48b170228144ef99" },
      { artist: "Hadise", title: "Düm Tek Tek", albumArt: "https://i.scdn.co/image/ab67616d0000b27376ef25706e907da367e45ba1" }
    ],
    rock: [
      { artist: "Duman", title: "Seni Kendime Sakladım", albumArt: "https://i.scdn.co/image/ab67616d0000b273ebec4eed6303e0252465e9e5" },
      { artist: "Mor ve Ötesi", title: "Bir Derdim Var", albumArt: "https://i.scdn.co/image/ab67616d0000b2737a4b35c303311e721e539b0c" },
      { artist: "maNga", title: "Bir Kadın Çizeceksin", albumArt: "https://i.scdn.co/image/ab67616d0000b273a02b4da9519130e135837950" },
      { artist: "Teoman", title: "Papatya", albumArt: "https://i.scdn.co/image/ab67616d0000b273eb8ceca7c71d93e3c51d5799" },
      { artist: "Şebnem Ferah", title: "Yalnız", albumArt: "https://i.scdn.co/image/ab67616d0000b2735f4839b5add4d78b74446820" }
    ],
    elektronik: [
      { artist: "Mercan Dede", title: "800", albumArt: "https://i.scdn.co/image/ab67616d0000b273ebf461d9574a219f49fe9ec9" },
      { artist: "Ah! Kosmos", title: "Wide", albumArt: "https://i.scdn.co/image/ab67616d0000b273d296f71bda38c82b4e73e920" },
      { artist: "Mabel Matiz", title: "A Canım", albumArt: "https://i.scdn.co/image/ab67616d0000b273e8bab3ad48b170228144ef99" },
      { artist: "Can Ozan", title: "Mask", albumArt: "https://i.scdn.co/image/ab67616d0000b273064c11b7e63e47d43ad5b6d0" },
      { artist: "Büyük Ev Ablukada", title: "Olmadı Kaçarız", albumArt: "https://i.scdn.co/image/ab67616d0000b273b7a3828242070ab30ba7862a" }
    ],
    klasik: [
      { artist: "Fazıl Say", title: "Kara Toprak", albumArt: "https://i.scdn.co/image/ab67616d0000b273cc3c73473a1c8f630c860c70" },
      { artist: "İdil Biret", title: "Moonlight Sonata", albumArt: "https://i.scdn.co/image/ab67616d0000b273a30729c4dab197f2366a1a87" },
      { artist: "Gülsin Onay", title: "Piano Sonata No. 11", albumArt: "https://i.scdn.co/image/ab67616d0000b273e0a0c40b30aaa6e6a3e87889" },
      { artist: "Burhan Öçal", title: "Istanbul Oriental Ensemble", albumArt: "https://i.scdn.co/image/ab67616d0000b273cb4b68a74ca2c4f4006ab181" },
      { artist: "Tuluyhan Uğurlu", title: "Istanbul Kanatlarımın Altında", albumArt: "https://i.scdn.co/image/ab67616d0000b273fdf5c60f04a63c25bd3b0486" }
    ],
    caz: [
      { artist: "İlhan Erşahin", title: "Afternoon", albumArt: "https://i.scdn.co/image/ab67616d0000b273c908278d0d9a35915c1a015e" },
      { artist: "Kerem Görsev", title: "For My Mother", albumArt: "https://i.scdn.co/image/ab67616d0000b273eb65c0e18a1ca3ceedd1ac7e" },
      { artist: "Önder Focan", title: "Bulutsuzluk Özlemi", albumArt: "https://i.scdn.co/image/ab67616d0000b2739cfb04ea04acded59cd5bec1" },
      { artist: "TRT Hafif Müzik ve Caz Orkestrası", title: "Katibim", albumArt: "https://i.scdn.co/image/ab67616d0000b273d2c9e09f0bc1106ee0b99d8e" },
      { artist: "Okay Temiz", title: "Denizaltı Rüzgarları", albumArt: "https://i.scdn.co/image/ab67616d0000b273a4e0ea6a4ee4d8d03f6e5dd1" }
    ],
    halk: [
      { artist: "Neşet Ertaş", title: "Neredesin Sen", albumArt: "https://i.scdn.co/image/ab67616d0000b2731a76f1abea8e0eacd1eb76e6" },
      { artist: "Aşık Veysel", title: "Uzun İnce Bir Yoldayım", albumArt: "https://i.scdn.co/image/ab67616d0000b273d2dc9a39563e690f04bd6970" },
      { artist: "Arif Sağ", title: "Benim Kabrim Taştan Olsun", albumArt: "https://i.scdn.co/image/ab67616d0000b273fa9547d9bffa9ce9cad7f245" },
      { artist: "Belkıs Akkale", title: "Dersim Dört Dağ İçinde", albumArt: "https://i.scdn.co/image/ab67616d0000b273cbef03616a8a865a28e3749f" },
      { artist: "Müzeyyen Senar", title: "Kalamış", albumArt: "https://i.scdn.co/image/ab67616d0000b273f4f78cf360d92c0468e8d26a" }
    ],
    rap: [
      { artist: "Ceza", title: "Suspus", albumArt: "https://i.scdn.co/image/ab67616d0000b27363def56f26eb1abe0f897e09" },
      { artist: "Ezhel", title: "Geceler", albumArt: "https://i.scdn.co/image/ab67616d0000b273e865cf7df773a80e81cbb951" },
      { artist: "Sagopa Kajmer", title: "Uzun Yollara Devam", albumArt: "https://i.scdn.co/image/ab67616d0000b2735a5c7ddc493ad30be08636c7" },
      { artist: "Şanışer", title: "Ludovico", albumArt: "https://i.scdn.co/image/ab67616d0000b273b60da25fba7d1254d52afc36" },
      { artist: "Patron", title: "Ateşten Gömlek", albumArt: "https://i.scdn.co/image/ab67616d0000b2731a65f97b1d7afc5a71d84935" }
    ],
    metal: [
      { artist: "Pentagram", title: "Bir", albumArt: "https://i.scdn.co/image/ab67616d0000b273aad45de8a44ff8acd5c3ca5e" },
      { artist: "Mezarkabul", title: "Anthology", albumArt: "https://i.scdn.co/image/ab67616d0000b273aad45de8a44ff8acd5c3ca5e" },
      { artist: "Murder King", title: "Gözlerin Ardında", albumArt: "https://i.scdn.co/image/ab67616d0000b273d35b2c00e08c9a32c7e6044d" },
      { artist: "Cenotaph", title: "Putrescent Infectious Rabidity", albumArt: "https://i.scdn.co/image/ab67616d0000b273d4d3d9bd8e9c848b22beb85e" },
      { artist: "The Headhunter", title: "Türk Lirası", albumArt: "https://i.scdn.co/image/ab67616d0000b2731397b2f8fb4e1c3802026bb0" }
    ],
    arabesk: [
      { artist: "Müslüm Gürses", title: "Nilüfer", albumArt: "https://i.scdn.co/image/ab67616d0000b273eadfe01bb0c14ba3f860a63a" },
      { artist: "Orhan Gencebay", title: "Bir Teselli Ver", albumArt: "https://i.scdn.co/image/ab67616d0000b273a5ef856e5b58a8ccdee65f35" },
      { artist: "Bergen", title: "Acıların Kadını", albumArt: "https://i.scdn.co/image/ab67616d0000b273ae9a16e35e04332581a81f1e" },
      { artist: "Ferdi Tayfur", title: "Derbeder", albumArt: "https://i.scdn.co/image/ab67616d0000b273d989b52eb45a9149f9c0dd7f" },
      { artist: "İbrahim Tatlıses", title: "Mutlu Ol Yeter", albumArt: "https://i.scdn.co/image/ab67616d0000b273f45c7fafdcafee5deb267cbd" }
    ]
  };
  
  // Anahtar kelimelere göre müzik önerilerini belirle
  if (lowerQuery.includes("pop")) {
    return recommendations.pop;
  } else if (lowerQuery.includes("rock")) {
    return recommendations.rock;
  } else if (lowerQuery.includes("elektronik") || lowerQuery.includes("edm")) {
    return recommendations.elektronik;
  } else if (lowerQuery.includes("klasik")) {
    return recommendations.klasik;
  } else if (lowerQuery.includes("jazz") || lowerQuery.includes("caz")) {
    return recommendations.caz;
  } else if (lowerQuery.includes("türkü") || lowerQuery.includes("halk")) {
    return recommendations.halk;
  } else if (lowerQuery.includes("rap") || lowerQuery.includes("hip hop")) {
    return recommendations.rap;
  } else if (lowerQuery.includes("metal")) {
    return recommendations.metal;
  } else if (lowerQuery.includes("arabesk")) {
    return recommendations.arabesk;
  } else {
    // Varsayılan olarak popüler şarkıları öner
    return [
      ...recommendations.pop.slice(0, 2),
      ...recommendations.rock.slice(0, 2),
      ...recommendations.elektronik.slice(0, 1)
    ];
  }
};

// AI Chatbot için Türkçe müzik konuşmaları yapay zeka simülasyonu
export const getAIChatResponse = (userMessage: string) => {
  // Sorguyu küçük harfe çevir
  const lowerMessage = userMessage.toLowerCase();
  
  // Temel anahtar kelime yanıt sistemi
  if (lowerMessage.includes("öneri") || lowerMessage.includes("öner") || lowerMessage.includes("tavsiye")) {
    return "Size birkaç harika müzik önerebilirim! Hangi türde müzik dinlemeyi seviyorsunuz? Pop, rock, jazz, klasik veya elektronik müzik gibi?";
  } 
  else if (lowerMessage.includes("pop")) {
    return "Pop müzik için şu sanatçıları dinleyebilirsiniz: Sezen Aksu, Tarkan, Kenan Doğulu ve Mabel Matiz. Yabancı sanatçılardan ise Dua Lipa, The Weeknd, ve Ed Sheeran dinleyebilirsiniz.";
  }
  else if (lowerMessage.includes("rock")) {
    return "Rock müzik için şu sanatçıları deneyebilirsiniz: Duman, Mor ve Ötesi, maNga, Teoman. Yabancı rock için Coldplay, Linkin Park, ve Imagine Dragons dinleyebilirsiniz.";
  }
  else if (lowerMessage.includes("elektronik") || lowerMessage.includes("edm")) {
    return "Elektronik müzik için Mercan Dede, Ah! Kosmos gibi Türk sanatçıları veya yabancılardan Daft Punk, Deadmau5, ve Avicii'nin eserlerini keşfedebilirsiniz.";
  }
  else if (lowerMessage.includes("klasik")) {
    return "Klasik müzik için Fazıl Say'ın eserlerini veya Mozart, Beethoven, Bach gibi klasik bestecilerin eserlerini dinleyebilirsiniz.";
  }
  else if (lowerMessage.includes("jazz") || lowerMessage.includes("caz")) {
    return "Jazz için İlhan Erşahin, Kerem Görsev gibi Türk sanatçıları veya Miles Davis, John Coltrane gibi jazz ustalarını dinleyebilirsiniz.";
  }
  else if (lowerMessage.includes("türkü") || lowerMessage.includes("halk")) {
    return "Türk halk müziği için Neşet Ertaş, Aşık Veysel, Arif Sağ ve Belkıs Akkale gibi değerli sanatçıları dinleyebilirsiniz.";
  }
  else if (lowerMessage.includes("rap") || lowerMessage.includes("hip hop")) {
    return "Rap müzik için Ceza, Ezhel, Sagopa Kajmer, Şanışer gibi Türk sanatçıları veya yabancılardan Kendrick Lamar, Eminem gibi sanatçıları dinleyebilirsiniz.";
  }
  else if (lowerMessage.includes("metal")) {
    return "Metal müzik için Pentagram, Mezarkabul, Cenotaph gibi Türk gruplarını veya Metallica, Iron Maiden, Black Sabbath gibi klasik metal gruplarını dinleyebilirsiniz.";
  }
  else if (lowerMessage.includes("arabesk")) {
    return "Arabesk müzik için Müslüm Gürses, Orhan Gencebay, Bergen, Ferdi Tayfur gibi sanatçıları dinleyebilirsiniz.";
  }
  else if (lowerMessage.includes("merhaba") || lowerMessage.includes("selam") || lowerMessage.includes("nasılsın")) {
    return "Merhaba! Size müzik konusunda nasıl yardımcı olabilirim? Belirli bir tür veya sanatçı hakkında bilgi vermemi ister misiniz?";
  }
  else if (lowerMessage.includes("teşekkür")) {
    return "Rica ederim! Başka bir müzik önerisi veya bilgi istediğinizde bana yazabilirsiniz.";
  }
  else if (lowerMessage.includes("tarkan")) {
    return "Tarkan, Türk pop müziğinin en tanınmış isimlerinden biridir. 'Kuzu Kuzu', 'Dudu', 'Şımarık' gibi hit şarkıları bulunmaktadır. Uluslararası başarı kazanmış nadir Türk sanatçılardan biridir.";
  }
  else if (lowerMessage.includes("duman")) {
    return "Duman, Türk rock müziğinin önemli gruplarından biridir. 'Seni Kendime Sakladım', 'Bu Akşam', 'Helal Olsun' gibi sevilen şarkıları vardır. Grubun vokali Kaan Tangöze'dir.";
  }
  else if (lowerMessage.includes("manga") || lowerMessage.includes("maNga")) {
    return "maNga, alternatif rock ve rap rock tarzında müzik yapan bir Türk rock grubudur. 2010 Eurovision şarkı yarışmasında 'We Could Be The Same' şarkısıyla Türkiye'yi temsil etmiş ve ikinci olmuştur.";
  }
  else if (lowerMessage.includes("sezen aksu")) {
    return "Sezen Aksu, Türk pop müziğinin 'Minik Serçe' olarak bilinen efsanevi ismidir. 40 yılı aşkın kariyerinde sayısız hit şarkıya imza atmış, birçok sanatçıyı keşfetmiş ve Türk pop müziğinin gelişiminde büyük rol oynamıştır.";
  }
  else if (lowerMessage.includes("neşet ertaş")) {
    return "Neşet Ertaş, Türk halk müziğinin usta isimlerinden biridir. 'Bozkırın Tezenesi' olarak anılır. Kendine özgü yorumu ve bağlama tekniğiyle Türk halk müziğine büyük katkılar sunmuştur.";
  }
  else if (lowerMessage.includes("müslüm") || lowerMessage.includes("müslüm gürses") || lowerMessage.includes("müslüm baba")) {
    return "Müslüm Gürses (Müslüm Baba), Türk arabesk müziğinin efsane isimlerindendir. Acılı hayatı ve etkileyici yorumuyla milyonlarca hayran kazanmıştır. 'Nilüfer', 'Affet', 'Sevda Yüklü Kervanlar' gibi unutulmaz eserleri vardır.";
  }
  else if (lowerMessage.includes("mor ve ötesi")) {
    return "Mor ve Ötesi, Türk rock müziğinin öncü gruplarından biridir. 'Bir Derdim Var', 'Cambaz', 'Şehir' gibi hit şarkılarıyla tanınırlar. 2008 Eurovision'da Türkiye'yi 'Deli' şarkısıyla temsil etmişlerdir.";
  }
  else {
    return "Müzik zevkiniz hakkında daha fazla bilgi verebilir misiniz? Hangi tür müzik veya hangi sanatçıları seviyorsunuz? Böylece size daha iyi öneriler sunabilirim.";
  }
};

// Türk müzik türleri ve sanatçılar eğitim veri seti
export const turkishMusicData = {
  genres: [
    {
      name: "Pop",
      description: "Türk pop müziği, 1970'lerden günümüze gelişen, batı pop formlarıyla Türk müzik geleneklerini birleştiren popüler bir türdür.",
      popularArtists: ["Tarkan", "Sezen Aksu", "Kenan Doğulu", "Mabel Matiz", "Hadise", "Hande Yener", "Gülşen", "Murat Boz", "Sıla", "Bengü"]
    },
    {
      name: "Rock",
      description: "Türk rock müziği, Batı rock müziğinden etkilenen, elektro gitar ve bateri ağırlıklı modern bir türdür.",
      popularArtists: ["Duman", "Mor ve Ötesi", "maNga", "Teoman", "Şebnem Ferah", "Athena", "Hayko Cepkin", "Kurban", "Gripin", "Yüksek Sadakat"]
    },
    {
      name: "Arabesk",
      description: "Arabesk, Arap müziğinden etkilenen, genellikle keder ve acı temalı, tipik olarak dar perdeli ve melismatik bir türdür.",
      popularArtists: ["Müslüm Gürses", "Orhan Gencebay", "Bergen", "Ferdi Tayfur", "İbrahim Tatlıses", "Ebru Gündeş", "Hakan Altun", "Cengiz Kurtoğlu", "Alişan", "Ahmet Kaya"]
    },
    {
      name: "Halk",
      description: "Türk halk müziği, Anadolu'nun çeşitli bölgelerinde gelişen, yerel enstrümanlar ve geleneksel melodiler içeren anonim türkülerden oluşan bir türdür.",
      popularArtists: ["Neşet Ertaş", "Aşık Veysel", "Arif Sağ", "Belkıs Akkale", "Müzeyyen Senar", "İbrahim Tatlıses", "Özgür Akdemir", "Selda Bağcan", "Musa Eroğlu", "Zara"]
    },
    {
      name: "Rap/Hip-Hop",
      description: "Türkçe rap, 1990'larda başlayan, Türkçe sözlerle toplumsal eleştiri ve kişisel hikayeleri anlatan urban bir müzik türüdür.",
      popularArtists: ["Ceza", "Ezhel", "Sagopa Kajmer", "Şanışer", "Patron", "Ben Fero", "Norm Ender", "Hidra", "Server Uraz", "Motive"]
    },
    {
      name: "Klasik Türk Müziği",
      description: "Klasik Türk müziği, Osmanlı saray müziğinden gelişen, makam sistemi üzerine kurulu, geleneksel Türk enstrümanlarıyla icra edilen bir türdür.",
      popularArtists: ["Münir Nurettin Selçuk", "Zeki Müren", "Bekir Sıdkı Sezgin", "Müzeyyen Senar", "Ahmet Özhan", "Melihat Gülses", "Emel Sayın", "Bülent Ersoy", "Mustafa Keser", "Alâeddin Yavaşça"]
    },
    {
      name: "Elektronik",
      description: "Türk elektronik müziği, modern dijital teknolojilerle üretilen, dans ve ambient türlerini içeren bir tür haline gelmiştir.",
      popularArtists: ["Mercan Dede", "Ah! Kosmos", "Mabel Matiz", "Can Ozan", "Büyük Ev Ablukada", "Elektro Hafız", "Gaye Su Akyol", "Cevdet Erek", "Ekin Fil", "Ekin Üzeltüzenci"]
    },
    {
      name: "Caz",
      description: "Türk caz müziği, Batı caz formlarıyla Türk müzik unsurlarını birleştiren modern bir füzyon türüdür.",
      popularArtists: ["İlhan Erşahin", "Kerem Görsev", "Önder Focan", "TRT Hafif Müzik ve Caz Orkestrası", "Okay Temiz", "Ayşe Tütüncü", "Süheyl Denizci", "Genco Arı", "Şenova Ülker", "Sibel Köse"]
    },
    {
      name: "Metal",
      description: "Türk metal müziği, ağır gitar rifleri ve güçlü vokalleriyle karakterize olan sert bir rock türüdür.",
      popularArtists: ["Pentagram", "Mezarkabul", "Murder King", "Cenotaph", "The Headhunter", "Whisky", "Moribund Oblivion", "Forgiveness", "Casualties", "Deathcraft"]
    }
  ],
  
  // Popüler şarkılar
  popularSongs: [
    { title: "Kuzu Kuzu", artist: "Tarkan", genre: "Pop", year: 2001 },
    { title: "Seni Kendime Sakladım", artist: "Duman", genre: "Rock", year: 2002 },
    { title: "Bir Kadın Çizeceksin", artist: "maNga", genre: "Rock", year: 2006 },
    { title: "Nilüfer", artist: "Müslüm Gürses", genre: "Arabesk", year: 1996 },
    { title: "Neredesin Sen", artist: "Neşet Ertaş", genre: "Halk", year: 1999 },
    { title: "Suspus", artist: "Ceza", genre: "Rap", year: 2004 },
    { title: "Geceler", artist: "Ezhel", genre: "Rap", year: 2017 },
    { title: "Kalamış", artist: "Müzeyyen Senar", genre: "Klasik Türk Müziği", year: 1955 },
    { title: "Öyle Kolaysa", artist: "Mabel Matiz", genre: "Pop", year: 2018 },
    { title: "Bir", artist: "Pentagram", genre: "Metal", year: 1992 },
    { title: "Teslim Olma", artist: "Şebnem Ferah", genre: "Rock", year: 2007 },
    { title: "Aşk", artist: "Sezen Aksu", genre: "Pop", year: 1991 },
    { title: "Denizaltı Rüzgarları", artist: "Okay Temiz", genre: "Caz", year: 1975 },
    { title: "Afternoon", artist: "İlhan Erşahin", genre: "Caz", year: 2005 },
    { title: "800", artist: "Mercan Dede", genre: "Elektronik", year: 2007 }
  ],
  
  // Eşsiz Türk enstrümanları
  instruments: [
    { name: "Bağlama", description: "Uzun saplı telli bir çalgı, halk müziğinin temel enstrümanıdır." },
    { name: "Zurna", description: "Yüksek sesli, üflemeli bir çalgıdır." },
    { name: "Davul", description: "Büyük, çift taraflı bir vurmalı çalgıdır." },
    { name: "Ney", description: "Kamıştan yapılan üflemeli bir çalgıdır, tasavvuf müziğinde önemli bir yere sahiptir." },
    { name: "Kanun", description: "Yatay olarak çalınan, telli bir çalgıdır." },
    { name: "Ud", description: "Orta Doğu kökenli, armudi şekilli telli bir çalgıdır." },
    { name: "Kemençe", description: "Karadeniz bölgesine özgü, yaylı küçük bir çalgıdır." },
    { name: "Darbuka", description: "Vazo şeklinde, elle çalınan bir vurmalı çalgıdır." },
    { name: "Tef", description: "Zilli bir kasnaktan oluşan vurmalı bir çalgıdır." },
    { name: "Kaval", description: "Çoban flütü olarak da bilinen üflemeli bir çalgıdır." }
  ]
};

// Arama veri seti - Türkçe müzik arama için eğitim veri seti
export const searchData = {
  // Popüler müzik terimleri (Türkçe)
  terms: [
    "pop müzik", "rock müzik", "arabesk", "halk müziği", "türkü", "rap", "hip hop",
    "elektronik müzik", "klasik müzik", "caz", "metal", "alternatif", "indie",
    "90lar türkçe pop", "2000ler rock", "eski şarkılar", "yeni çıkan şarkılar",
    "türkçe slow", "türkçe romantik", "türkçe dans", "türkçe parti", "hareketli şarkılar",
    "düğün şarkıları", "türkçe rap", "yabancı pop", "arabesk rap", "nostalji"
  ],
  
  // Popüler sanatçı aramaları
  artists: [
    "Tarkan", "Sezen Aksu", "Duman", "Müslüm Gürses", "Neşet Ertaş", "Ceza", "Ezhel",
    "Mabel Matiz", "MFÖ", "Barış Manço", "İbrahim Tatlıses", "Cem Karaca", "Orhan Gencebay",
    "Mor ve Ötesi", "maNga", "Şebnem Ferah", "Teoman", "Ajda Pekkan", "Gülşen",
    "Kenan Doğulu", "Hande Yener", "Serdar Ortaç", "Ebru Gündeş", "Sibel Can",
    "Hadise", "Murat Boz", "Demet Akalın", "Sagopa Kajmer", "Athena"
  ],
  
  // Popüler şarkı aramaları
  songs: [
    "Kuzu Kuzu", "Seni Kendime Sakladım", "Bir Kadın Çizeceksin", "Nilüfer",
    "Neredesin Sen", "Suspus", "Geceler", "Öyle Kolaysa", "Şımarık", "Kalamış",
    "Firuze", "Gül Pembe", "Uzun İnce Bir Yoldayım", "Arapsaçı", "Param Yok",
    "Hayvan", "Fesuphanallah", "Leyli Leyli", "Deli", "Bu Akşam", "Vazgeçtim",
    "Göç", "Vur Yüreğim", "Ben İnsan Değil miyim", "Beddua", "Antidepresan",
    "Yanıyoruz", "Nerdesin", "Cambaz", "Reckless"
  ]
};