// YouTube API integration for fetching video data
const API_KEY = import.meta.env.VITE_YOUTUBE_API_KEY || 'AIzaSyAzqsXjoQCFDi5c5Lf6Ilp9det-5lS5QCg';
const API_BASE_URL = "https://www.googleapis.com/youtube/v3";

// Types
export interface YouTubeVideo {
  id: string;
  title: string;
  thumbnail: string;
  channelTitle: string;
  publishedAt: string;
}

// Helper function to make API requests
const makeRequest = async (endpoint: string, params: Record<string, string>): Promise<any> => {
  const queryParams = new URLSearchParams({
    key: API_KEY as string,
    ...params,
  });

  try {
    const response = await fetch(`${API_BASE_URL}/${endpoint}?${queryParams.toString()}`);
    
    if (!response.ok) {
      throw new Error(`YouTube API error: ${response.status} ${response.statusText}`);
    }
    
    return await response.json();
  } catch (error) {
    console.error("YouTube API request failed:", error);
    throw error;
  }
};

// Search for videos
export const searchVideos = async (query: string, maxResults: number = 5): Promise<YouTubeVideo[]> => {
  try {
    const data = await makeRequest("search", {
      part: "snippet",
      type: "video",
      q: query,
      maxResults: maxResults.toString(),
    });
    
    return data.items.map((item: any) => ({
      id: item.id.videoId,
      title: item.snippet.title,
      thumbnail: item.snippet.thumbnails.medium.url,
      channelTitle: item.snippet.channelTitle,
      publishedAt: item.snippet.publishedAt,
    }));
  } catch (error) {
    console.error("Error searching for videos:", error);
    return [];
  }
};

// Get video by ID
export const getVideoById = async (videoId: string): Promise<YouTubeVideo | null> => {
  try {
    const data = await makeRequest("videos", {
      part: "snippet",
      id: videoId,
    });
    
    if (data.items.length === 0) {
      return null;
    }
    
    const item = data.items[0];
    return {
      id: item.id,
      title: item.snippet.title,
      thumbnail: item.snippet.thumbnails.medium.url,
      channelTitle: item.snippet.channelTitle,
      publishedAt: item.snippet.publishedAt,
    };
  } catch (error) {
    console.error("Error getting video by ID:", error);
    return null;
  }
};

// Search for music videos
export const searchMusicVideos = async (artist: string, track: string, maxResults: number = 3): Promise<YouTubeVideo[]> => {
  const query = `${artist} ${track} official music video`;
  return searchVideos(query, maxResults);
};

// Check if YouTube API key is available
export const isYouTubeApiKeyAvailable = (): boolean => {
  return !!API_KEY;
};

// Log availability for debugging
console.log("YouTube API Key available:", isYouTubeApiKeyAvailable());