import { useEffect } from "react";
import AIAssistant from "@/components/AIAssistant";
import { useAuth } from "@/contexts/AuthContext";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Music, AudioWaveform, Lightbulb, Disc, Radio } from "lucide-react";

export default function Assistant() {
  const { user } = useAuth();
  
  // Demo recommendations that would come from AI in a full version
  const recommendations = [
    {
      title: "Rahatlamak için Akustik",
      description: "Sakinleşmek ve rahatlamak için akustik şarkılar",
      icon: <AudioWaveform className="h-8 w-8 text-emerald-500" />,
    },
    {
      title: "Odaklanma Müziği",
      description: "Çalışırken veya okurken konsantrasyonunuzu artıracak parçalar",
      icon: <Lightbulb className="h-8 w-8 text-yellow-500" />,
    },
    {
      title: "2000'ler Nostalji",
      description: "2000'lerin en popüler Türkçe şarkıları",
      icon: <Disc className="h-8 w-8 text-pink-500" />,
    },
    {
      title: "Yeni Keşifler",
      description: "Dinleme alışkanlıklarınıza göre beğenebileceğiniz yeni sanatçılar",
      icon: <Radio className="h-8 w-8 text-blue-500" />,
    },
  ];

  return (
    <div className="p-4 md:p-8 pb-32">
      <div className="mb-8">
        <h1 className="text-2xl md:text-3xl font-bold mb-2">MüzikAI Asistanı</h1>
        <p className="text-muted-foreground">Müzik zevkinize göre kişiselleştirilmiş öneriler ve daha fazlası</p>
      </div>
      
      {/* AI Assistant - Full Screen */}
      <AIAssistant fullscreen={true} />
      
      {/* Recommendation Cards - Hidden in fullscreen mode */}
      <div className="hidden">
        <h2 className="text-xl font-bold mb-4 mt-8">Sizin İçin Öneriler</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {recommendations.map((recommendation, index) => (
            <Card key={index} className="hover:bg-muted/50 transition cursor-pointer">
              <CardContent className="p-6 flex items-start">
                <div className="mr-4 bg-background p-3 rounded-full">
                  {recommendation.icon}
                </div>
                <div>
                  <h3 className="text-lg font-medium mb-1">{recommendation.title}</h3>
                  <p className="text-muted-foreground text-sm">{recommendation.description}</p>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
}
