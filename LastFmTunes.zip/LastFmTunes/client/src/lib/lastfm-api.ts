import { API_REQUEST_THROTTLE, API_TIMEOUT, LASTFM_MOOD_MAPPING } from './constants';
import { throttle } from './utils';

const LASTFM_API_KEY = import.meta.env.VITE_LASTFM_API_KEY || 'your_lastfm_api_key';
const LASTFM_API_BASE = 'https://ws.audioscrobbler.com/2.0/';

interface LastFmTrack {
  name: string;
  artist: {
    name: string;
  } | string;
  url: string;
  image: Array<{
    '#text': string;
    size: string;
  }>;
  streamable: string | { '#text': string; fulltrack: string };
  listeners?: string;
  playcount?: string;
}

interface LastFmTaggedTrack {
  name: string;
  duration: string;
  mbid: string;
  url: string;
  streamable: {
    '#text': string;
    fulltrack: string;
  };
  artist: {
    name: string;
    mbid: string;
    url: string;
  };
  image: Array<{
    '#text': string;
    size: string;
  }>;
  '@attr': {
    rank: string;
  };
}

interface LastFmSimilarTrack {
  name: string;
  playcount: string;
  mbid: string;
  match: string;
  url: string;
  streamable: {
    '#text': string;
    fulltrack: string;
  };
  duration: string;
  artist: {
    name: string;
    mbid: string;
    url: string;
  };
  image: Array<{
    '#text': string;
    size: string;
  }>;
}

// Normalize LastFM track objects to a common format
export interface NormalizedTrack {
  name: string;
  artist: string;
  url: string;
  imageUrl: string;
  listeners?: number;
  playcount?: number;
  match?: number;
}

// Helper to get image URL of appropriate size
function getImageUrl(images: Array<{ '#text': string; size: string }>, preferredSize = 'large'): string {
  if (!images || images.length === 0) return '';
  
  const image = images.find(img => img.size === preferredSize);
  return image ? image['#text'] : images[images.length - 1]['#text'];
}

// Normalize LastFM track to our common format
function normalizeTrack(track: LastFmTrack | LastFmTaggedTrack | LastFmSimilarTrack): NormalizedTrack {
  return {
    name: track.name,
    artist: typeof track.artist === 'string' ? track.artist : track.artist.name,
    url: track.url,
    imageUrl: getImageUrl(track.image),
    listeners: track.listeners ? parseInt(track.listeners) : undefined,
    playcount: track.playcount ? parseInt(track.playcount) : undefined,
    match: 'match' in track ? parseFloat(track.match) : undefined
  };
}

// Basic LastFM API call with timeout and error handling
async function callLastFmApi(params: Record<string, string>): Promise<any> {
  const queryParams = new URLSearchParams({
    api_key: LASTFM_API_KEY,
    format: 'json',
    ...params
  });
  
  const url = `${LASTFM_API_BASE}?${queryParams.toString()}`;
  
  // Create a promise that rejects in <timeout> milliseconds
  const timeoutPromise = new Promise((_, reject) => {
    const id = setTimeout(() => {
      clearTimeout(id);
      reject(new Error(`LastFM API call timed out after ${API_TIMEOUT}ms`));
    }, API_TIMEOUT);
  });
  
  // Create fetch promise
  const fetchPromise = fetch(url)
    .then(response => {
      if (!response.ok) {
        throw new Error(`LastFM API error: ${response.status} ${response.statusText}`);
      }
      return response.json();
    })
    .then(data => {
      if (data.error) {
        throw new Error(`LastFM API error: ${data.error} - ${data.message}`);
      }
      return data;
    });
  
  // Race the promises
  return Promise.race([fetchPromise, timeoutPromise]);
}

// Throttle the API calls
const throttledApiCall = throttle(callLastFmApi, API_REQUEST_THROTTLE);

// Get top tracks by tag (mood/genre)
export async function getTopTracksByTag(tag: string, limit: number = 10): Promise<NormalizedTrack[]> {
  try {
    const data = await throttledApiCall({
      method: 'tag.gettoptracks',
      tag,
      limit: limit.toString()
    });
    
    if (!data.tracks || !data.tracks.track) {
      return [];
    }
    
    return Array.isArray(data.tracks.track) 
      ? data.tracks.track.map(normalizeTrack)
      : [normalizeTrack(data.tracks.track)];
  } catch (error) {
    console.error('Error fetching top tracks by tag:', error);
    return [];
  }
}

// Get similar tracks based on artist and track name
export async function getSimilarTracks(
  artist: string,
  track: string,
  limit: number = 10
): Promise<NormalizedTrack[]> {
  try {
    const data = await throttledApiCall({
      method: 'track.getsimilar',
      artist,
      track,
      limit: limit.toString(),
      autocorrect: '1' // Allow API to correct misspelled artist or track names
    });
    
    if (!data.similartracks || !data.similartracks.track) {
      return [];
    }
    
    return Array.isArray(data.similartracks.track)
      ? data.similartracks.track.map(normalizeTrack)
      : [normalizeTrack(data.similartracks.track)];
  } catch (error) {
    console.error('Error fetching similar tracks:', error);
    return [];
  }
}

// Search for tracks
export async function searchTracks(
  query: string,
  limit: number = 10
): Promise<NormalizedTrack[]> {
  try {
    const data = await throttledApiCall({
      method: 'track.search',
      track: query,
      limit: limit.toString()
    });
    
    if (!data.results || !data.results.trackmatches || !data.results.trackmatches.track) {
      return [];
    }
    
    return Array.isArray(data.results.trackmatches.track)
      ? data.results.trackmatches.track.map(normalizeTrack)
      : [normalizeTrack(data.results.trackmatches.track)];
  } catch (error) {
    console.error('Error searching tracks:', error);
    return [];
  }
}

// Helper to map our mood to LastFM tags
export function mapMoodToLastfmTag(mood: string): string {
  const tags = LASTFM_MOOD_MAPPING[mood as keyof typeof LASTFM_MOOD_MAPPING];
  if (!tags || tags.length === 0) {
    return mood; // Default to the original mood if no mapping
  }
  return tags[0]; // Return the first tag in the mapping
}

// Get top artists
export async function getTopArtists(limit: number = 10): Promise<{name: string, listeners: number, imageUrl: string}[]> {
  try {
    const data = await throttledApiCall({
      method: 'chart.gettopartists',
      limit: limit.toString()
    });
    
    if (!data.artists || !data.artists.artist) {
      return [];
    }
    
    return Array.isArray(data.artists.artist)
      ? data.artists.artist.map((artist: any) => ({
          name: artist.name,
          listeners: parseInt(artist.listeners),
          imageUrl: getImageUrl(artist.image)
        }))
      : [{
          name: data.artists.artist.name,
          listeners: parseInt(data.artists.artist.listeners),
          imageUrl: getImageUrl(data.artists.artist.image)
        }];
  } catch (error) {
    console.error('Error fetching top artists:', error);
    return [];
  }
}
