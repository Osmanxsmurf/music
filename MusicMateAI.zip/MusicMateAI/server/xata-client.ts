import { XataClient } from '@xata.io/client';

// Xata istemcisini oluştur
export const xata = new XataClient({
  apiKey: 'au_BJzzy94NsG0clOMuEXDC6747Qi2r07mJ0',
  databaseURL: 'https://Osman-zdo-an-s-workspace-rbheop.eu-central-1.xata.sh/db/music_assistant:main'
});

// Veritabanından sanatçı ve şarkı eşleşmelerini kontrol et
export async function checkAndValidateData() {
  try {
    // Sanatçıları getir
    const artists = await xata.db.artists.getAll();
    console.log(`Toplam ${artists.length} sanatçı bulundu`);
    
    // Şarkıları getir
    const songs = await xata.db.songs.getAll();
    console.log(`Toplam ${songs.length} şarkı bulundu`);
    
    // İlk 5 sanatçı ve şarkıyı kontrol et
    console.log("Sanatçı Örnekleri:");
    artists.slice(0, 5).forEach(artist => {
      console.log(`- ${artist.name} (${artist.genre})`);
    });
    
    console.log("Şarkı Örnekleri:");
    songs.slice(0, 5).forEach(song => {
      console.log(`- "${song.title}" by ${song.artist} (${song.year})`);
    });
    
    // Link kontrolü yap
    console.log("Albüm Kapağı Link Kontrolü:");
    const songsWithAlbumArt = songs.filter(song => song.albumArt);
    songsWithAlbumArt.slice(0, 5).forEach(song => {
      console.log(`- "${song.title}": ${song.albumArt}`);
    });
    
    return { success: true, artistCount: artists.length, songCount: songs.length };
  } catch (error) {
    console.error("Xata veri doğrulama hatası:", error);
    return { success: false, error };
  }
}

// Müzik önerileri getir
export async function getMusicRecommendations(genre: string, limit = 5) {
  try {
    // Genre'a göre filtrele
    const songs = await xata.db.songs
      .filter({ genre })
      .getAll();
    
    // Rastgele 5 tanesini seç
    const randomSongs = songs
      .sort(() => 0.5 - Math.random())
      .slice(0, limit);
    
    return randomSongs;
  } catch (error) {
    console.error("Öneri getirme hatası:", error);
    return [];
  }
}

// Sanatçıları türe göre getir
export async function getArtistsByGenre(genre: string, limit = 10) {
  try {
    // Genre'a göre filtrele
    const artists = await xata.db.artists
      .filter({ genre })
      .getAll();
    
    return artists.slice(0, limit);
  } catch (error) {
    console.error("Sanatçı getirme hatası:", error);
    return [];
  }
}

// Şarkı ara
export async function searchSongs(query: string, limit = 10) {
  try {
    // Başlık ve sanatçıda ara
    const songs = await xata.db.songs
      .search(query, { fuzziness: 1 })
      .getAll();
    
    return songs.slice(0, limit);
  } catch (error) {
    console.error("Şarkı arama hatası:", error);
    return [];
  }
}