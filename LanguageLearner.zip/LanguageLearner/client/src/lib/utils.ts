import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

// Format time in seconds to mm:ss format
export function formatTime(seconds: number): string {
  if (isNaN(seconds) || seconds < 0) return "0:00";
  
  const minutes = Math.floor(seconds / 60);
  const remainingSeconds = Math.floor(seconds % 60);
  
  return `${minutes}:${remainingSeconds.toString().padStart(2, "0")}`;
}

// Format duration in seconds to "X hours Y minutes" or "X minutes" format
export function formatDuration(seconds: number): string {
  if (isNaN(seconds) || seconds < 0) return "0 dakika";
  
  const hours = Math.floor(seconds / 3600);
  const minutes = Math.floor((seconds % 3600) / 60);
  
  if (hours > 0) {
    return `${hours} saat ${minutes > 0 ? `${minutes} dakika` : ""}`;
  }
  
  return `${minutes} dakika`;
}

// Generate random placeholder image
export function getPlaceholderImage(seed: string, width = 300, height = 300): string {
  return `https://placehold.co/${width}x${height}/333/FFF?text=${encodeURIComponent(seed)}`;
}

// Convert Turkish characters to their non-accented equivalents
export function normalizeText(text: string): string {
  return text
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/ı/g, "i")
    .replace(/ğ/g, "g")
    .replace(/ü/g, "u")
    .replace(/ş/g, "s")
    .replace(/ö/g, "o")
    .replace(/ç/g, "c")
    .replace(/İ/g, "I")
    .replace(/Ğ/g, "G")
    .replace(/Ü/g, "U")
    .replace(/Ş/g, "S")
    .replace(/Ö/g, "O")
    .replace(/Ç/g, "C");
}

// Extract initials from a full name
export function getInitials(fullName: string): string {
  if (!fullName) return "?";
  
  const names = fullName.split(" ");
  if (names.length === 1) return names[0].charAt(0).toUpperCase();
  
  return (names[0].charAt(0) + names[names.length - 1].charAt(0)).toUpperCase();
}

// Truncate text to a specific length and add ellipsis
export function truncateText(text: string, maxLength: number): string {
  if (!text || text.length <= maxLength) return text;
  return `${text.substring(0, maxLength)}...`;
}

// Format a number with thousand separators
export function formatNumber(num: number): string {
  return new Intl.NumberFormat("tr-TR").format(num);
}

// Check if device is mobile
export function isMobile(): boolean {
  return window.innerWidth < 768;
}

// Generate a random string
export function generateRandomString(length: number): string {
  const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
  let result = "";
  for (let i = 0; i < length; i++) {
    result += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return result;
}
