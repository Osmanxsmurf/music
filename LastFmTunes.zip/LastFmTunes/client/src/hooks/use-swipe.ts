import { useRef, useEffect, useState, useCallback } from 'react';

interface SwipeOptions {
  onSwipeLeft?: () => void;
  onSwipeRight?: () => void;
  onSwipeUp?: () => void;
  onSwipeDown?: () => void;
  threshold?: number;  // Minimum distance to trigger swipe
  preventScrollOnSwipeY?: boolean;  // Prevent scrolling when swiping vertically
}

interface SwipePosition {
  startX: number;
  startY: number;
  endX: number;
  endY: number;
  diffX: number;
  diffY: number;
}

export function useSwipe(
  ref: React.RefObject<HTMLElement>,
  options: SwipeOptions = {}
) {
  const {
    onSwipeLeft,
    onSwipeRight,
    onSwipeUp,
    onSwipeDown,
    threshold = 50,
    preventScrollOnSwipeY = false
  } = options;
  
  const [swiping, setSwiping] = useState(false);
  const [direction, setDirection] = useState<string | null>(null);
  
  const positionRef = useRef<SwipePosition>({
    startX: 0,
    startY: 0,
    endX: 0,
    endY: 0,
    diffX: 0,
    diffY: 0
  });
  
  const onTouchStart = useCallback((e: TouchEvent) => {
    const touch = e.touches[0];
    
    positionRef.current.startX = touch.clientX;
    positionRef.current.startY = touch.clientY;
    
    setSwiping(true);
    setDirection(null);
  }, []);
  
  const onTouchMove = useCallback((e: TouchEvent) => {
    if (!swiping) return;
    
    const touch = e.touches[0];
    
    positionRef.current.endX = touch.clientX;
    positionRef.current.endY = touch.clientY;
    
    positionRef.current.diffX = positionRef.current.startX - positionRef.current.endX;
    positionRef.current.diffY = positionRef.current.startY - positionRef.current.endY;
    
    // If we're in a vertical swipe and we want to prevent scrolling
    if (
      preventScrollOnSwipeY && 
      Math.abs(positionRef.current.diffY) > Math.abs(positionRef.current.diffX) &&
      Math.abs(positionRef.current.diffY) > threshold / 2
    ) {
      e.preventDefault();
    }
    
    // Determine dominant direction of swipe
    if (Math.abs(positionRef.current.diffX) > Math.abs(positionRef.current.diffY)) {
      // Horizontal swipe
      if (positionRef.current.diffX > 0) {
        setDirection('left');
      } else {
        setDirection('right');
      }
    } else {
      // Vertical swipe
      if (positionRef.current.diffY > 0) {
        setDirection('up');
      } else {
        setDirection('down');
      }
    }
  }, [swiping, preventScrollOnSwipeY, threshold]);
  
  const onTouchEnd = useCallback(() => {
    if (!swiping) return;
    
    const { diffX, diffY } = positionRef.current;
    
    // Only trigger if the swipe distance exceeds the threshold
    if (Math.abs(diffX) > threshold) {
      if (diffX > 0) {
        onSwipeLeft?.();
      } else {
        onSwipeRight?.();
      }
    }
    
    if (Math.abs(diffY) > threshold) {
      if (diffY > 0) {
        onSwipeUp?.();
      } else {
        onSwipeDown?.();
      }
    }
    
    // Reset state
    setSwiping(false);
    setDirection(null);
  }, [swiping, threshold, onSwipeLeft, onSwipeRight, onSwipeUp, onSwipeDown]);
  
  useEffect(() => {
    const element = ref.current;
    if (!element) return;
    
    element.addEventListener('touchstart', onTouchStart, { passive: true });
    element.addEventListener('touchmove', onTouchMove, { passive: !preventScrollOnSwipeY });
    element.addEventListener('touchend', onTouchEnd, { passive: true });
    
    return () => {
      element.removeEventListener('touchstart', onTouchStart);
      element.removeEventListener('touchmove', onTouchMove);
      element.removeEventListener('touchend', onTouchEnd);
    };
  }, [ref, onTouchStart, onTouchMove, onTouchEnd, preventScrollOnSwipeY]);
  
  return {
    swiping,
    direction
  };
}

// Simpler version for components that need only a single swipe direction
export function useSwipeDetection(
  ref: React.RefObject<HTMLElement>, 
  onSwipe: (direction: 'left' | 'right' | 'up' | 'down') => void,
  threshold: number = 50
) {
  useSwipe(ref, {
    onSwipeLeft: () => onSwipe('left'),
    onSwipeRight: () => onSwipe('right'),
    onSwipeUp: () => onSwipe('up'),
    onSwipeDown: () => onSwipe('down'),
    threshold
  });
}
