import React, { useState, useEffect } from 'react';
import { MoodSelector } from '@/components/MoodSelector';
import { SongCard } from '@/components/SongCard';
import { RecommendationEngine } from '@/components/RecommendationEngine';
import { MusicPlayerContext } from '@/components/Layout';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { fetchAllSongs, fetchLikedSongs, fetchRecentlyPlayed } from '@/lib/xata';
import { useToast } from '@/hooks/use-toast';
import { useMobile } from '@/hooks/use-mobile';
import { ChevronRight, Music2, TrendingUp, BarChart2, Headphones } from 'lucide-react';
import { Song } from '@shared/schema';
import { motion } from 'framer-motion';

export default function DiscoverPage() {
  const { playSong } = React.useContext(MusicPlayerContext);
  const { toast } = useToast();
  const isMobile = useMobile();
  
  const [selectedMood, setSelectedMood] = useState('');
  const [topSongs, setTopSongs] = useState<Song[]>([]);
  const [recentlyPlayed, setRecentlyPlayed] = useState<Song[]>([]);
  const [likedSongs, setLikedSongs] = useState<Song[]>([]);
  const [loading, setLoading] = useState(true);
  
  // Load data
  useEffect(() => {
    const loadData = async () => {
      setLoading(true);
      try {
        // Load all required data in parallel
        const [allSongs, recentSongs, liked] = await Promise.all([
          fetchAllSongs(),
          fetchRecentlyPlayed(1, 10),
          fetchLikedSongs(1)
        ]);
        
        // Get top songs (by play count)
        const sorted = [...allSongs].sort((a, b) => (b.playCount || 0) - (a.playCount || 0));
        setTopSongs(sorted.slice(0, 10));
        setRecentlyPlayed(recentSongs);
        setLikedSongs(liked);
      } catch (error) {
        console.error("Error loading data:", error);
        toast({
          title: "Veri Yükleme Hatası",
          description: "Müzik verileri yüklenirken bir sorun oluştu.",
          variant: "destructive"
        });
      } finally {
        setLoading(false);
      }
    };
    
    loadData();
  }, [toast]);
  
  return (
    <div className="py-6 px-4 md:px-6 space-y-8">
      {/* Hero/Featured Playlist */}
      <section>
        <div className="relative rounded-xl overflow-hidden group">
          <img 
            src="https://images.unsplash.com/photo-1470229722913-7c0e2dbbafd3?ixlib=rb-4.0.3&auto=format&fit=crop&w=1200&h=400" 
            alt="Müzik festivali sahnesi" 
            className="object-cover w-full h-48 md:h-56"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent">
            <div className="absolute bottom-0 left-0 p-4 w-full">
              <span className="text-sm text-white/80">HAFTANIN LİSTESİ</span>
              <h3 className="text-white text-2xl font-bold">Top 40 Türkiye</h3>
              <p className="text-white/80 text-sm mb-4">Bu haftanın en popüler 40 şarkısı</p>
              <div className="flex items-center gap-2">
                <Button className="bg-primary hover:bg-primary/90 text-white flex items-center gap-2 transition shadow-lg">
                  <Headphones className="h-4 w-4" />
                  Çal
                </Button>
                <Button variant="secondary" className="bg-white/20 hover:bg-white/30 text-white flex items-center gap-2 transition backdrop-blur-sm">
                  <BarChart2 className="h-4 w-4" />
                  347k dinleyici
                </Button>
              </div>
            </div>
          </div>
        </div>
      </section>
      
      {/* Mood selector */}
      <section>
        <MoodSelector
          selectedMood={selectedMood}
          onMoodSelect={setSelectedMood}
          showLabel={true}
        />
      </section>
      
      {/* Recommendation Engine */}
      <section>
        <RecommendationEngine 
          initialMood={selectedMood}
          recentlyPlayedSongs={recentlyPlayed}
          likedSongs={likedSongs}
          className="shadow-sm"
        />
      </section>
      
      {/* Top Charts */}
      <section className="space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-semibold flex items-center gap-2">
            <TrendingUp className="h-5 w-5 text-primary" />
            Popüler Listeler
          </h2>
          <Button variant="link" className="text-xs text-primary p-0 h-auto flex items-center gap-1">
            <span>Tümünü Gör</span>
            <ChevronRight className="h-4 w-4" />
          </Button>
        </div>
        
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {/* Top Songs Chart */}
          <Card className="bg-card hover:bg-muted/50 border transition-all overflow-hidden shadow-sm">
            <CardContent className="p-0">
              <div className="p-4">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="font-semibold">Bu Haftanın En İyileri</h3>
                  <span className="text-xs bg-primary/10 text-primary py-1 px-2 rounded-full">Pop</span>
                </div>
                
                <ul className="space-y-3">
                  {loading ? (
                    Array(3).fill(0).map((_, i) => (
                      <li key={i} className="flex items-center gap-3">
                        <span className="font-bold text-lg text-muted-foreground w-6">{i+1}</span>
                        <div className="flex-1 h-8 bg-muted rounded animate-pulse"></div>
                      </li>
                    ))
                  ) : (
                    topSongs.slice(0, 3).map((song, index) => (
                      <li key={song.id} className="flex items-center gap-3">
                        <span className="font-bold text-lg text-muted-foreground w-6">{index+1}</span>
                        <div className="flex-1 min-w-0">
                          <h4 className="font-medium text-sm truncate">{song.title}</h4>
                          <p className="text-xs text-muted-foreground truncate">{song.artist}</p>
                        </div>
                        <Button 
                          variant="ghost" 
                          size="icon" 
                          className="text-muted-foreground hover:text-primary transition p-1"
                          onClick={() => playSong(song)}
                        >
                          <Headphones className="h-4 w-4" />
                        </Button>
                      </li>
                    ))
                  )}
                </ul>
              </div>
              
              <div className="px-4 py-3 border-t border-muted">
                <Button variant="link" className="w-full text-sm text-primary">
                  Tümünü Gör
                </Button>
              </div>
            </CardContent>
          </Card>
          
          {/* Trending Electronic Chart */}
          <Card className="bg-card hover:bg-muted/50 border transition-all overflow-hidden shadow-sm">
            <CardContent className="p-0">
              <div className="p-4">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="font-semibold">Trend Elektronik</h3>
                  <span className="text-xs bg-primary/10 text-primary py-1 px-2 rounded-full">Elektronik</span>
                </div>
                
                <ul className="space-y-3">
                  {loading ? (
                    Array(3).fill(0).map((_, i) => (
                      <li key={i} className="flex items-center gap-3">
                        <span className="font-bold text-lg text-muted-foreground w-6">{i+1}</span>
                        <div className="flex-1 h-8 bg-muted rounded animate-pulse"></div>
                      </li>
                    ))
                  ) : (
                    topSongs.filter(song => song.genre === 'Electronic').slice(0, 3).map((song, index) => (
                      <li key={song.id} className="flex items-center gap-3">
                        <span className="font-bold text-lg text-muted-foreground w-6">{index+1}</span>
                        <div className="flex-1 min-w-0">
                          <h4 className="font-medium text-sm truncate">{song.title}</h4>
                          <p className="text-xs text-muted-foreground truncate">{song.artist}</p>
                        </div>
                        <Button 
                          variant="ghost" 
                          size="icon" 
                          className="text-muted-foreground hover:text-primary transition p-1"
                          onClick={() => playSong(song)}
                        >
                          <Headphones className="h-4 w-4" />
                        </Button>
                      </li>
                    ))
                  )}
                </ul>
              </div>
              
              <div className="px-4 py-3 border-t border-muted">
                <Button variant="link" className="w-full text-sm text-primary">
                  Tümünü Gör
                </Button>
              </div>
            </CardContent>
          </Card>
          
          {/* Classic Rock Chart */}
          <Card className="bg-card hover:bg-muted/50 border transition-all overflow-hidden shadow-sm">
            <CardContent className="p-0">
              <div className="p-4">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="font-semibold">Klasik Rock</h3>
                  <span className="text-xs bg-primary/10 text-primary py-1 px-2 rounded-full">Rock</span>
                </div>
                
                <ul className="space-y-3">
                  {loading ? (
                    Array(3).fill(0).map((_, i) => (
                      <li key={i} className="flex items-center gap-3">
                        <span className="font-bold text-lg text-muted-foreground w-6">{i+1}</span>
                        <div className="flex-1 h-8 bg-muted rounded animate-pulse"></div>
                      </li>
                    ))
                  ) : (
                    topSongs.filter(song => song.genre === 'Rock').slice(0, 3).map((song, index) => (
                      <li key={song.id} className="flex items-center gap-3">
                        <span className="font-bold text-lg text-muted-foreground w-6">{index+1}</span>
                        <div className="flex-1 min-w-0">
                          <h4 className="font-medium text-sm truncate">{song.title}</h4>
                          <p className="text-xs text-muted-foreground truncate">{song.artist}</p>
                        </div>
                        <Button 
                          variant="ghost" 
                          size="icon" 
                          className="text-muted-foreground hover:text-primary transition p-1"
                          onClick={() => playSong(song)}
                        >
                          <Headphones className="h-4 w-4" />
                        </Button>
                      </li>
                    ))
                  )}
                </ul>
              </div>
              
              <div className="px-4 py-3 border-t border-muted">
                <Button variant="link" className="w-full text-sm text-primary">
                  Tümünü Gör
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </section>
      
      {/* Recently Played */}
      {recentlyPlayed.length > 0 && (
        <section className="space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-semibold flex items-center gap-2">
              <Music2 className="h-5 w-5 text-primary" />
              Son Dinlenenler
            </h2>
            <Button variant="link" className="text-xs text-primary p-0 h-auto flex items-center gap-1">
              <span>Tümünü Gör</span>
              <ChevronRight className="h-4 w-4" />
            </Button>
          </div>
          
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
            {recentlyPlayed.slice(0, 5).map((song, index) => (
              <motion.div 
                key={song.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3, delay: index * 0.05 }}
              >
                <SongCard song={song} onPlay={playSong} />
              </motion.div>
            ))}
          </div>
        </section>
      )}
    </div>
  );
}
