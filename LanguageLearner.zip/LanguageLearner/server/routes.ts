import express, { type Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import session from "express-session";
import MemoryStore from "memorystore";
import passport from "passport";
import { Strategy as LocalStrategy } from "passport-local";
import bcrypt from "bcryptjs";
import { z } from "zod";
import { ZodError } from "zod-validation-error";

import { storage } from "./storage";
import {
  insertUserSchema,
  insertChatMessageSchema,
  insertPlaylistSchema,
  insertLikedTrackSchema,
  insertRecentlyPlayedSchema
} from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // Session setup
  const MemorySessionStore = MemoryStore(session);
  app.use(
    session({
      secret: process.env.SESSION_SECRET || "musik-ai-secret",
      resave: false,
      saveUninitialized: false,
      cookie: { secure: process.env.NODE_ENV === "production", maxAge: 24 * 60 * 60 * 1000 },
      store: new MemorySessionStore({
        checkPeriod: 24 * 60 * 60 * 1000,
      }),
    })
  );

  // Passport setup
  app.use(passport.initialize());
  app.use(passport.session());

  passport.use(
    new LocalStrategy(async (username, password, done) => {
      try {
        const user = await storage.getUserByUsername(username);
        if (!user) {
          return done(null, false, { message: "Kullanıcı adı bulunamadı" });
        }

        const isValidPassword = await bcrypt.compare(password, user.password);
        if (!isValidPassword) {
          return done(null, false, { message: "Geçersiz şifre" });
        }

        // Don't expose password
        const { password: _, ...userWithoutPassword } = user;
        return done(null, userWithoutPassword);
      } catch (error) {
        return done(error);
      }
    })
  );

  passport.serializeUser((user: any, done) => {
    done(null, user.id);
  });

  passport.deserializeUser(async (id: number, done) => {
    try {
      const user = await storage.getUser(id);
      if (!user) {
        return done(null, false);
      }
      // Don't expose password
      const { password: _, ...userWithoutPassword } = user;
      done(null, userWithoutPassword);
    } catch (error) {
      done(error);
    }
  });

  // Authentication middleware
  const ensureAuthenticated = (req: Request, res: Response, next: any) => {
    if (req.isAuthenticated()) {
      return next();
    }
    res.status(401).json({ message: "Giriş yapmanız gerekiyor" });
  };

  // API routes - prefixed with /api
  const apiRouter = express.Router();

  // Authentication routes
  apiRouter.post("/auth/register", async (req, res) => {
    try {
      const userData = insertUserSchema.parse(req.body);

      // Check if username already exists
      const existingUsername = await storage.getUserByUsername(userData.username);
      if (existingUsername) {
        return res.status(400).json({ message: "Bu kullanıcı adı zaten alınmış" });
      }

      // Check if email already exists
      const existingEmail = await storage.getUserByEmail(userData.email);
      if (existingEmail) {
        return res.status(400).json({ message: "Bu email adresi zaten kullanılıyor" });
      }

      // Hash password
      const hashedPassword = await bcrypt.hash(userData.password, 10);
      const user = await storage.createUser({
        ...userData,
        password: hashedPassword,
      });

      // Remove password from response
      const { password: _, ...userWithoutPassword } = user;
      res.status(201).json(userWithoutPassword);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Geçersiz kullanıcı bilgileri", errors: error.format() });
      }
      res.status(500).json({ message: "Kullanıcı kaydı sırasında bir hata oluştu" });
    }
  });

  apiRouter.post("/auth/login", (req, res, next) => {
    passport.authenticate("local", (err, user, info) => {
      if (err) {
        return next(err);
      }
      if (!user) {
        return res.status(401).json({ message: info.message || "Giriş başarısız" });
      }
      req.logIn(user, (loginErr) => {
        if (loginErr) {
          return next(loginErr);
        }
        return res.json(user);
      });
    })(req, res, next);
  });

  apiRouter.post("/auth/logout", (req, res, next) => {
    req.logout((err) => {
      if (err) {
        return next(err);
      }
      res.json({ message: "Başarıyla çıkış yapıldı" });
    });
  });

  apiRouter.get("/auth/user", ensureAuthenticated, (req, res) => {
    res.json(req.user);
  });

  // Music tracks routes
  apiRouter.get("/tracks/search", async (req, res) => {
    try {
      const query = req.query.q as string;
      if (!query || query.length < 2) {
        return res.status(400).json({ message: "En az 2 karakter girmelisiniz" });
      }

      const tracks = await storage.searchTracks(query);
      res.json(tracks);
    } catch (error) {
      res.status(500).json({ message: "Arama sırasında bir hata oluştu" });
    }
  });

  apiRouter.get("/tracks/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Geçersiz track ID" });
      }

      const track = await storage.getTrack(id);
      if (!track) {
        return res.status(404).json({ message: "Şarkı bulunamadı" });
      }

      res.json(track);
    } catch (error) {
      res.status(500).json({ message: "Şarkı bilgisi alınırken bir hata oluştu" });
    }
  });

  // Playlists routes
  apiRouter.get("/playlists", ensureAuthenticated, async (req, res) => {
    try {
      const userId = (req.user as any).id;
      const playlists = await storage.getUserPlaylists(userId);
      res.json(playlists);
    } catch (error) {
      res.status(500).json({ message: "Çalma listeleri alınırken bir hata oluştu" });
    }
  });

  apiRouter.post("/playlists", ensureAuthenticated, async (req, res) => {
    try {
      const userId = (req.user as any).id;
      const playlistData = insertPlaylistSchema.parse({
        ...req.body,
        userId
      });

      const playlist = await storage.createPlaylist(playlistData);
      res.status(201).json(playlist);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Geçersiz çalma listesi bilgileri", errors: error.format() });
      }
      res.status(500).json({ message: "Çalma listesi oluşturulurken bir hata oluştu" });
    }
  });

  apiRouter.get("/playlists/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Geçersiz playlist ID" });
      }

      const playlist = await storage.getPlaylist(id);
      if (!playlist) {
        return res.status(404).json({ message: "Çalma listesi bulunamadı" });
      }

      res.json(playlist);
    } catch (error) {
      res.status(500).json({ message: "Çalma listesi bilgisi alınırken bir hata oluştu" });
    }
  });

  apiRouter.get("/playlists/:id/tracks", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Geçersiz playlist ID" });
      }

      const playlist = await storage.getPlaylist(id);
      if (!playlist) {
        return res.status(404).json({ message: "Çalma listesi bulunamadı" });
      }

      const tracks = await storage.getPlaylistTracks(id);
      res.json(tracks);
    } catch (error) {
      res.status(500).json({ message: "Çalma listesi şarkıları alınırken bir hata oluştu" });
    }
  });

  apiRouter.post("/playlists/:id/tracks", ensureAuthenticated, async (req, res) => {
    try {
      const playlistId = parseInt(req.params.id);
      const trackId = parseInt(req.body.trackId);
      if (isNaN(playlistId) || isNaN(trackId)) {
        return res.status(400).json({ message: "Geçersiz ID" });
      }

      const playlist = await storage.getPlaylist(playlistId);
      if (!playlist) {
        return res.status(404).json({ message: "Çalma listesi bulunamadı" });
      }

      // Check if user owns the playlist
      const userId = (req.user as any).id;
      if (playlist.userId !== userId) {
        return res.status(403).json({ message: "Bu çalma listesine şarkı ekleme yetkiniz yok" });
      }

      const track = await storage.getTrack(trackId);
      if (!track) {
        return res.status(404).json({ message: "Şarkı bulunamadı" });
      }

      // Get current track count for position
      const currentTracks = await storage.getPlaylistTracks(playlistId);
      const position = currentTracks.length;

      const playlistTrack = await storage.addTrackToPlaylist({
        playlistId,
        trackId,
        position
      });

      res.status(201).json(playlistTrack);
    } catch (error) {
      res.status(500).json({ message: "Şarkı eklenirken bir hata oluştu" });
    }
  });

  // Liked tracks routes
  apiRouter.get("/tracks/liked", ensureAuthenticated, async (req, res) => {
    try {
      const userId = (req.user as any).id;
      const likedTracks = await storage.getLikedTracks(userId);
      res.json(likedTracks);
    } catch (error) {
      res.status(500).json({ message: "Beğenilen şarkılar alınırken bir hata oluştu" });
    }
  });

  apiRouter.post("/tracks/:id/like", ensureAuthenticated, async (req, res) => {
    try {
      const userId = (req.user as any).id;
      const trackId = parseInt(req.params.id);
      if (isNaN(trackId)) {
        return res.status(400).json({ message: "Geçersiz track ID" });
      }

      const track = await storage.getTrack(trackId);
      if (!track) {
        return res.status(404).json({ message: "Şarkı bulunamadı" });
      }

      const isLiked = await storage.isTrackLiked(userId, trackId);
      if (isLiked) {
        return res.status(400).json({ message: "Bu şarkı zaten beğenildi" });
      }

      const likedTrackData = insertLikedTrackSchema.parse({
        userId,
        trackId
      });

      const likedTrack = await storage.likeTrack(likedTrackData);
      res.status(201).json(likedTrack);
    } catch (error) {
      res.status(500).json({ message: "Şarkı beğenilirken bir hata oluştu" });
    }
  });

  apiRouter.delete("/tracks/:id/like", ensureAuthenticated, async (req, res) => {
    try {
      const userId = (req.user as any).id;
      const trackId = parseInt(req.params.id);
      if (isNaN(trackId)) {
        return res.status(400).json({ message: "Geçersiz track ID" });
      }

      const isUnliked = await storage.unlikeTrack(userId, trackId);
      if (!isUnliked) {
        return res.status(404).json({ message: "Beğenilen şarkı bulunamadı" });
      }

      res.json({ message: "Şarkı beğenisi kaldırıldı" });
    } catch (error) {
      res.status(500).json({ message: "Şarkı beğenisi kaldırılırken bir hata oluştu" });
    }
  });

  // Recently played routes
  apiRouter.get("/tracks/recent", ensureAuthenticated, async (req, res) => {
    try {
      const userId = (req.user as any).id;
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 10;
      const recentTracks = await storage.getRecentlyPlayed(userId, limit);
      res.json(recentTracks);
    } catch (error) {
      res.status(500).json({ message: "Son çalınan şarkılar alınırken bir hata oluştu" });
    }
  });

  apiRouter.post("/tracks/:id/played", ensureAuthenticated, async (req, res) => {
    try {
      const userId = (req.user as any).id;
      const trackId = parseInt(req.params.id);
      if (isNaN(trackId)) {
        return res.status(400).json({ message: "Geçersiz track ID" });
      }

      const track = await storage.getTrack(trackId);
      if (!track) {
        return res.status(404).json({ message: "Şarkı bulunamadı" });
      }

      const recentlyPlayedData = insertRecentlyPlayedSchema.parse({
        userId,
        trackId
      });

      const recentlyPlayed = await storage.addRecentlyPlayed(recentlyPlayedData);
      res.status(201).json(recentlyPlayed);
    } catch (error) {
      res.status(500).json({ message: "Şarkı çalma kaydı eklenirken bir hata oluştu" });
    }
  });

  // Chat routes
  apiRouter.get("/users/:userId/chat", async (req, res) => {
    try {
      const userId = req.params.userId;
      const messages = await storage.getUserChatMessages(userId);
      res.json(messages);
    } catch (error) {
      res.status(500).json({ message: "Sohbet mesajları alınırken bir hata oluştu" });
    }
  });

  apiRouter.post("/users/:userId/chat", async (req, res) => {
    try {
      const userId = req.params.userId;
      
      const chatMessageData = insertChatMessageSchema.parse({
        ...req.body,
        userId
      });

      // Önceki tüm sohbet mesajlarını temizle (test için)
      if (chatMessageData.content === "temizle" && chatMessageData.isUser) {
        // Kullanıcının tüm sohbet mesajlarını sil
        const allMessages = await storage.getUserChatMessages(userId);
        for (const msg of allMessages) {
          await storage.deleteChatMessage(msg.id);
        }
        return res.status(200).json({ message: "Tüm sohbet geçmişi temizlendi." });
      }

      // Kullanıcı mesajını kaydet
      const chatMessage = await storage.addChatMessage(chatMessageData);
      
      // Eğer kullanıcıdan gelen bir mesajsa, AI yanıtı oluştur
      if (chatMessageData.isUser) {
        try {
          // Kullanıcı mesajına göre AI yanıtı oluştur
          const aiResponse = generateAIResponse(chatMessageData.content);
          
          // AI yanıtını veritabanına kaydet
          const aiMessage = await storage.addChatMessage({
            userId,
            content: aiResponse,
            isUser: false
          });
          
          // Hem kullanıcı mesajını hem de AI yanıtını döndür
          return res.status(201).json({
            userMessage: chatMessage,
            aiMessage: aiMessage
          });
          
        } catch (responseError) {
          console.error("Error generating AI response:", responseError);
          return res.status(500).json({ message: "AI yanıtı oluşturulurken bir hata oluştu" });
        }
      }
      
      // Eğer AI mesajıysa, sadece kaydedilen mesajı döndür
      res.status(201).json(chatMessage);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Geçersiz sohbet mesajı", errors: { issues: error.errors } });
      }
      res.status(500).json({ message: "Sohbet mesajı gönderilirken bir hata oluştu" });
    }
  });

  // Mount API router
  app.use("/api", apiRouter);

  // Create HTTP server
  const httpServer = createServer(app);

  return httpServer;
}

// Helper function to generate AI responses with music suggestions
function generateAIResponse(userMessage: string): string {
  const lowerMsg = userMessage.toLowerCase();
  
  // Temel karşılama ve teşekkür mesajları
  if (lowerMsg.includes("merhaba") || lowerMsg.includes("selam")) {
    return "Merhaba! Size nasıl yardımcı olabilirim? Müzik önerileri için ruh halinizi veya sevdiğiniz sanatçıları paylaşabilirsiniz. Örneğin 'enerjik müzik öner' ya da 'rock tarzında şarkılar öner' diyebilirsiniz.";
  } else if (lowerMsg.includes("teşekkür") || lowerMsg.includes("sağol")) {
    return "Rica ederim! Müzik önerileriyle ilgili başka bir konuda yardımcı olabilir miyim? İstediğiniz bir tarz veya ruh haline göre öneriler sunabilirim.";
  }
  
  // Müzik türüne göre öneriler
  if (lowerMsg.includes("rock")) {
    return "Rock müzik için harika Türkçe önerilerim var:\n\n" +
           "1. Madrigal - Seni Dert Etmeler\n" +
           "2. maNga - Bir Kadın Çizeceksin\n" +
           "3. Mor ve Ötesi - Cambaz\n" +
           "4. Teoman - Ruhun Sarışın\n" +
           "5. Şebnem Ferah - Yağmurlar\n" +
           "6. Adamlar - Zombi\n\n" +
           "Bu şarkıları dinlemek ister misiniz? Ya da başka bir rock sanatçısı hakkında bilgi almak isterseniz söyleyin.";
  } else if (lowerMsg.includes("pop")) {
    return "Türkçe pop için popüler önerilerim şunlar:\n\n" +
           "1. Tarkan - Kuzu Kuzu\n" +
           "2. Sezen Aksu - Unuttun mu Beni\n" +
           "3. Sıla - Hediye\n" +
           "4. Murat Boz - Janti\n" +
           "5. Hadise - Mesajımı Almıştır O\n" +
           "6. Hande Yener - Bakıcaz Artık\n\n" +
           "Bu tarz şarkılar dinlemeyi seviyor musunuz? İsterseniz daha spesifik bir türde pop müzik önerebilirim.";
  } else if (lowerMsg.includes("rap") || lowerMsg.includes("hip hop")) {
    return "Türkçe rap/hip hop için dinleyebileceğiniz bazı parçalar:\n\n" +
           "1. Ezhel - İmkansızım\n" +
           "2. Ceza - Suspus\n" +
           "3. Şanışer - Ludovico\n" +
           "4. Sagopa Kajmer - Galiba\n" +
           "5. Norm Ender - Mekanın Sahibi\n" +
           "6. Ben Fero - Demet Akalın\n\n" +
           "Bu şarkılardan hangisini dinlemek istersiniz?";
  } else if (lowerMsg.includes("romantik") || lowerMsg.includes("aşk") || lowerMsg.includes("sevgili")) {
    return "Romantik anlarınız için mükemmel Türkçe şarkılar:\n\n" +
           "1. Sezen Aksu - Seni Kimler Aldı\n" +
           "2. Tarkan - Beni Çok Sev\n" +
           "3. Sıla - Yan Benimle\n" +
           "4. Mabel Matiz - Sarı Şarkı\n" +
           "5. Eylem Aktaş - Aşk Kaçınılmaz\n" +
           "6. Gripin - Durma Yağmur Durma\n\n" +
           "Bu romantik şarkılar duygusal anlarınıza eşlik edebilir. Başka tür romantik şarkılar da önerebilirim.";
  } else if (lowerMsg.includes("arabesk") || lowerMsg.includes("damar")) {
    return "Duygusal Türkçe arabesk şarkılar:\n\n" +
           "1. Müslüm Gürses - Nilüfer\n" +
           "2. Bergen - Acıların Kadını\n" +
           "3. Ferdi Tayfur - Huzurum Kalmadı\n" +
           "4. İbrahim Tatlıses - Mutlu Ol Yeter\n" +
           "5. Orhan Gencebay - Bir Teselli Ver\n" +
           "6. Gülden Karaböcek - Adını Anmayacağım\n\n" +
           "Bu şarkılar Türk arabesk müziğinin en sevilen örnekleri. Daha farklı arabesk sanatçıları da önerebilirim.";
  }
  
  // Ruh haline göre öneriler
  else if (lowerMsg.includes("enerjik") || lowerMsg.includes("enerji") || lowerMsg.includes("hareketli")) {
    return "Enerjinizi yükseltecek hareketli şarkılar şunlar:\n\n" +
           "1. Athena - Skalonga\n" +
           "2. maNga - Dünyanın Sonuna Doğmuşum\n" +
           "3. Tarkan - Şımarık\n" +
           "4. Kenan Doğulu - Aşk ile Yap\n" +
           "5. Gülşen - Bangır Bangır\n" +
           "6. Edis - Arıyorum\n\n" +
           "Bu şarkılar size enerji verecektir! Özel bir etkinlik için mi müzik arıyorsunuz?";
  } else if (lowerMsg.includes("sakin") || lowerMsg.includes("rahatlatıcı") || lowerMsg.includes("dinlendirici")) {
    return "Sakinleşmek ve rahatlamak için dinleyebileceğiniz akustik parçalar:\n\n" +
           "1. Yüksek Sadakat - Belki Üstümüzden Bir Kuş Geçer\n" +
           "2. Melike Şahin - Deli Kan\n" +
           "3. Ceylan Ertem - Zalım\n" +
           "4. Kalben - Sadece\n" +
           "5. Can Ozan - Sen Bunları Duyma\n" +
           "6. Mabel Matiz - Sarmaşık\n\n" +
           "Rahatlama için başka tür bir müzik tercih ederseniz söyleyin, size uygun öneriler sunabilirim.";
  } else if (lowerMsg.includes("motivasyon") || lowerMsg.includes("motive")) {
    return "Motivasyonunuzu artıracak güçlü şarkılar:\n\n" +
           "1. Manga - We Could Be The Same\n" +
           "2. Şebnem Ferah - Güçlüyüm\n" +
           "3. Emre Aydın - Bu Kez Anladım\n" +
           "4. Tarkan - Yolla\n" +
           "5. Nil Karaibrahimgil - Vay\n" +
           "6. Göksel - Depresyondayım\n\n" +
           "Bu şarkılar motivasyonunuzu yükseltecektir! Özel bir amaç için mi motivasyon arıyorsunuz?";
  } else if (lowerMsg.includes("hüzünlü") || lowerMsg.includes("duygusal") || lowerMsg.includes("melankolik")) {
    return "Duygusal ve hüzünlü anlarınıza eşlik edecek Türkçe şarkılar:\n\n" +
           "1. Sezen Aksu - Gülümse\n" +
           "2. Duman - Bu Akşam\n" +
           "3. Adamlar - Rüyalarda Buruşmuşum\n" +
           "4. Kalben - Gil\n" +
           "5. Cem Adrian - Mutlu Yıllar\n" +
           "6. Mor ve Ötesi - Oyunbozan\n\n" +
           "Bu şarkılar duygularınıza tercüman olabilir. Farklı bir duygu durumu için öneriler ister misiniz?";
  }
  
  // Aktivitelere göre öneriler
  else if (lowerMsg.includes("spor") || lowerMsg.includes("fitness") || lowerMsg.includes("egzersiz")) {
    return "Spor yaparken dinleyebileceğiniz yüksek tempolu şarkılar:\n\n" +
           "1. Mahmut Orhan - Feel\n" +
           "2. Tarkan - Dudu\n" +
           "3. Model - Değmesin Ellerimiz\n" +
           "4. Yalın - Yeniden\n" +
           "5. Simge - Miş Miş\n" +
           "6. Hadise - Düm Tek Tek\n\n" +
           "Bu şarkılar spor performansınızı artırabilir. Hangi tür antrenman yapıyorsunuz?";
  } else if (lowerMsg.includes("çalışmak") || lowerMsg.includes("çalışırken") || lowerMsg.includes("ders")) {
    return "Çalışırken odaklanmanıza yardımcı olacak sakin ve ritmik müzikler:\n\n" +
           "1. Ludovico Einaudi - Experience\n" +
           "2. Can Ozan - Bir Bahar Akşamı\n" +
           "3. Ferhat Göçer - Kalbe Kiralık Aşk (Akustik)\n" +
           "4. Sıla - Vaziyetler\n" +
           "5. Mor ve Ötesi - Cambaz (Akustik)\n" +
           "6. Candan Erçetin - Meğer\n\n" +
           "Bu tür müzikler odaklanmanıza yardımcı olacaktır. Ne üzerine çalışıyorsunuz?";
  } else if (lowerMsg.includes("parti") || lowerMsg.includes("eğlence")) {
    return "Parti için enerji verecek popüler dans şarkıları:\n\n" +
           "1. Edis - Çok Çok\n" +
           "2. Aleyna Tilki - Cevapsız Çınlama\n" +
           "3. Tarkan - Cuppa\n" +
           "4. Mahmut Orhan - Game Of Thrones\n" +
           "5. Kenan Doğulu - Baş Harfi Ben\n" +
           "6. Hadise - Düm Tek Tek\n\n" +
           "Bu şarkılar partinizi hareketlendirecektir! Ne tür bir parti düzenliyorsunuz?";
  } else if (lowerMsg.includes("yolculuk") || lowerMsg.includes("seyahat") || lowerMsg.includes("araba")) {
    return "Yolculuk sırasında dinleyebileceğiniz keyifli Türkçe şarkılar:\n\n" +
           "1. Barış Manço - Dağlar Dağlar\n" +
           "2. Sertab Erener - Kumsalda\n" +
           "3. Duman - Ela Gözlüm\n" +
           "4. Mavi Gri - Uzunlar\n" +
           "5. Mabel Matiz - Karakol\n" +
           "6. MFÖ - Peki Peki Anladık\n\n" +
           "Bu şarkılar yol boyunca size eşlik edebilir. Uzun bir yolculuk mu planlıyorsunuz?";
  }
  
  // Dönem/Nostalji önerileri
  else if (lowerMsg.includes("90") || lowerMsg.includes("90lar")) {
    return "90'ların efsane Türkçe şarkıları:\n\n" +
           "1. Mirkelam - Her Gece\n" +
           "2. Sezen Aksu - Hadi Bakalım\n" +
           "3. Tarkan - Şımarık\n" +
           "4. Nazan Öncel - Erkekler de Yanar\n" +
           "5. Teoman - Papatya\n" +
           "6. Kenan Doğulu - Kandırdım\n\n" +
           "90'lar müziğini mi özlediniz? Başka bir döneme ait müzikler dinlemek ister misiniz?";
  } else if (lowerMsg.includes("2000") || lowerMsg.includes("2000ler")) {
    return "2000'lerin nostaljik Türkçe hit şarkıları:\n\n" +
           "1. Gülşen - Of Of\n" +
           "2. Mustafa Sandal - Aya Benzer\n" +
           "3. Nil Karaibrahimgil - XL\n" +
           "4. Hande Yener - Acele Etme\n" +
           "5. Murat Boz - Uçurum\n" +
           "6. Kenan Doğulu - Çakkıdı\n\n" +
           "2000'ler müziğini seviyorsanız, bu liste tam size göre! Başka bir dönem müziği dinlemek ister misiniz?";
  } else if (lowerMsg.includes("eski") || lowerMsg.includes("klasik") || lowerMsg.includes("nostaljik")) {
    return "Türk müziğinin unutulmaz klasikleri:\n\n" +
           "1. Zeki Müren - Şimdi Uzaklardasın\n" +
           "2. Cem Karaca - Resimdeki Gözyaşları\n" +
           "3. Ajda Pekkan - Bambaşka Biri\n" +
           "4. Barış Manço - Gülpembe\n" +
           "5. Erkin Koray - Sevince\n" +
           "6. Selçuk Alagöz - Zaman Zaman\n\n" +
           "Bu klasik parçalar Türk müzik tarihinin önemli eserleri. Hangi dönem Türk müziğini daha çok seviyorsunuz?";
  }
  
  // Sanatçılara göre öneriler
  else if (lowerMsg.includes("tarkan")) {
    return "Tarkan'ın en sevilen şarkıları:\n\n" +
           "1. Kuzu Kuzu\n" +
           "2. Şımarık\n" +
           "3. Dudu\n" +
           "4. Yolla\n" +
           "5. Öp\n" +
           "6. Cuppa\n\n" +
           "Tarkan'ın başka hangi şarkılarını seviyorsunuz? Benzer tarzda başka sanatçılar da önerebilirim.";
  } else if (lowerMsg.includes("sezen") || lowerMsg.includes("aksu")) {
    return "Sezen Aksu'nun en güzel şarkıları:\n\n" +
           "1. Gülümse\n" +
           "2. Unuttun mu Beni\n" +
           "3. Seni Kimler Aldı\n" +
           "4. Firuze\n" +
           "5. Kutlama\n" +
           "6. Kaybolan Yıllar\n\n" +
           "Sezen Aksu Türk pop müziğinin mihenk taşlarından biridir. Minik Serçe'nin başka şarkılarını da dinlemek ister misiniz?";
  } else if (lowerMsg.includes("duman")) {
    return "Duman grubunun en iyi şarkıları:\n\n" +
           "1. Bu Akşam\n" +
           "2. Yanıyor Hayat\n" +
           "3. Melankoli\n" +
           "4. Dibine Kadar\n" +
           "5. Helal Olsun\n" +
           "6. Aman Aman\n\n" +
           "Duman, Türk rock müziğinde çok önemli bir yere sahip. Bu gruptan başka hangi şarkıları seviyorsunuz?";
  } else if (lowerMsg.includes("dua lipa") || lowerMsg.includes("dualipa")) {
    return "Dua Lipa'nın en popüler şarkıları:\n\n" +
           "1. Don't Start Now\n" +
           "2. Levitating\n" +
           "3. New Rules\n" +
           "4. Physical\n" +
           "5. One Kiss (with Calvin Harris)\n" +
           "6. Break My Heart\n\n" +
           "Dua Lipa 2017'den beri popüler bir İngiliz şarkıcı. Türkçe müzik önerileri dışında uluslararası sanatçılar hakkında da bilgi verebilirim. Başka bir sanatçı hakkında bilgi ister misiniz?";
  } else if (lowerMsg.includes("mabel matiz")) {
    return "Mabel Matiz'in en sevilen şarkıları:\n\n" +
           "1. Öyle Kolaysa\n" +
           "2. Sarmaşık\n" +
           "3. Filler ve Çimen\n" +
           "4. Karakol\n" +
           "5. Kırılma Noktası\n" +
           "6. Boyalı Da Saçların\n\n" +
           "Mabel Matiz, alternatif müzik tarzıyla Türk müziğinde farklı bir ses getiren önemli bir sanatçıdır. Hangi şarkısını en çok seviyorsunuz?";
  }
  
  // Genel öneri istekleri
  else if (lowerMsg.includes("öneri") || lowerMsg.includes("öner") || lowerMsg.includes("tavsiye")) {
    return "Size özel müzik önerileri için tarzınızı, ruh halinizi veya sevdiğiniz sanatçıları belirtmeniz bana daha iyi öneriler sunmamda yardımcı olacaktır. Örneğin:\n\n" +
           "- Enerjik rock müzikleri öner\n" +
           "- Spor yaparken dinlemek için müzik öner\n" +
           "- 90'lar Türkçe pop şarkıları öner\n" +
           "- Çalışırken odaklanmak için sakin müzikler öner\n\n" +
           "Nasıl bir müzik türü sizi şu an daha çok ilgilendiriyor?";
  } 
  
  // Sohbet yanıtları için
  else if (lowerMsg.includes("nasılsın") || lowerMsg.includes("naber") || lowerMsg.includes("ne haber")) {
    return "Teşekkür ederim, ben iyiyim! Müzik önerileri sunarak insanlara yardımcı olmak beni mutlu ediyor. Peki ya siz nasılsınız? Bugün nasıl bir müzik dinlemek istiyorsunuz?";
  } else if (lowerMsg.includes("teşekkür") || lowerMsg.includes("sağol")) {
    return "Rica ederim! Size yardımcı olabildiysem ne mutlu bana. Başka bir müzik önerisi isterseniz veya farklı bir sanatçı hakkında bilgi almak isterseniz sormaktan çekinmeyin. Keyifli dinlemeler dilerim!";
  } else if (lowerMsg.includes("kimsin") || lowerMsg.includes("adın ne")) {
    return "Ben MüzikAI, sizin kişisel müzik asistanınızım. Türkçe ve yabancı müzik önerileri sunmak, sanatçılar hakkında bilgi vermek ve müzik zevkinize uygun şarkılar bulmak için buradayım. Size nasıl yardımcı olabilirim?";
  } else if (lowerMsg.includes("evet") && lowerMsg.length < 10) {
    return "Harika! O zaman size yardımcı olmak için biraz daha bilgiye ihtiyacım var. Ne tür bir müzik arıyorsunuz? Rock, pop, arabesk ya da elektronik gibi bir tür belirtebilir veya bir sanatçı ismi söyleyebilirsiniz. Ya da belki şu anki ruh halinize uygun bir şeyler mi dinlemek istersiniz?";
  } else if (lowerMsg.includes("hayır") && lowerMsg.length < 10) {
    return "Anladım. Başka nasıl yardımcı olabilirim? Belki farklı bir müzik türü veya sanatçı önerisi istersiniz? Ya da belirli bir ruh haline uygun şarkılar mı arıyorsunuz?";
  } else if (lowerMsg.includes("seviyorum") || lowerMsg.includes("severim")) {
    return "Müzik zevkiniz çok güzel! Bu tarz müzikleri dinlemekten keyif almanız harika. Size benzer veya biraz daha farklı öneriler sunmak isterim. Önerileri beğendiniz mi? Başka ne tür müzikler keşfetmek istersiniz?";
  } else if (lowerMsg.includes("çal") || lowerMsg.includes("oynat")) {
    return "Seçtiğiniz müziği şu anda çalmak için çalışıyorum. Ancak seçilen şarkıyı çalabilmek için müzik hizmetleriyle entegrasyon gerekiyor. Şimdilik size bu şarkıyla ilgili bilgiler verebilir veya benzer başka şarkılar önerebilirim. Ne dersiniz?";
  }
  // Bilinmeyen sorgular için genel yanıt
  else {
    const responses = [
      "Bu konuda size yardımcı olmak isterim. Daha spesifik bir müzik tarzı, sanatçı veya ruh halinizden bahsederseniz size özel öneriler sunabilirim. Örneğin 'Türkçe pop öner' ya da 'Tarkan'ın en iyi şarkıları neler?' gibi sorular sorabilirsiniz.",
      
      "Müzik dünyasında kaybolmak çok kolay! Size yardımcı olmam için hangi tür müzik (rock, pop, elektronik) veya hangi sanatçı hakkında bilgi almak istediğinizi söyleyebilir misiniz? Ruh halinize göre de öneriler sunabilirim.",
      
      "Müzik zevkiniz hakkında biraz daha bilgi almak isterim. En sevdiğiniz sanatçılar kimler? Ya da genellikle hangi müzik türlerini dinlersiniz? Bu sayede size daha kişiselleştirilmiş öneriler sunabilirim.",
      
      "Müzik önerileri için buradayım! 'Enerjik şarkılar öner', 'Romantik Türkçe şarkılar', '90'lar pop müziği' veya 'Sezen Aksu şarkıları' gibi istekler belirtirseniz size özel listeler sunabilirim."
    ];
    
    // Rastgele bir cevap seç - sohbeti daha doğal hale getirmek için
    const randomIndex = Math.floor(Math.random() * responses.length);
    return responses[randomIndex];
  }
}
