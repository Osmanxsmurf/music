import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { getStoredData, setStoredData, getStorageUsage } from '@/lib/localStorage';
import { LOCAL_STORAGE_KEYS } from '@/lib/constants';
import { useOffline } from '@/hooks/use-offline';
import { useTheme } from '@/components/ThemeProvider';
import { isAppInstalled, showInstallPrompt, clearCache } from '@/lib/service-worker';
import { useToast } from '@/hooks/use-toast';
import { 
  User, 
  Settings, 
  Moon, 
  Sun, 
  LogOut, 
  Download, 
  Trash2, 
  CloudOff, 
  Save, 
  RefreshCw,
  Database,
  Music 
} from 'lucide-react';
import { motion } from 'framer-motion';

export default function ProfilePage() {
  const { toast } = useToast();
  const { theme, setTheme } = useTheme();
  const { isOffline, offlineMode, toggleOfflineMode, prefetchOfflineData } = useOffline();
  
  const [dataSaver, setDataSaver] = useState(false);
  const [isPWAInstalled, setIsPWAInstalled] = useState(false);
  const [storageUsage, setStorageUsage] = useState({ used: 0, total: 0, percentage: 0 });
  
  // Load user preferences
  useEffect(() => {
    // Load data saver preference
    getStoredData<boolean>('dataSaver', true).then(setDataSaver);
    
    // Check if PWA is installed
    setIsPWAInstalled(isAppInstalled());
    
    // Get storage usage
    setStorageUsage(getStorageUsage());
  }, []);
  
  // Format bytes to human readable format
  const formatBytes = (bytes: number) => {
    if (bytes === 0) return '0 Bytes';
    
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };
  
  // Toggle data saver
  const handleToggleDataSaver = async () => {
    const newMode = !dataSaver;
    setDataSaver(newMode);
    await setStoredData('dataSaver', newMode);
    
    toast({
      title: newMode ? "Veri Tasarrufu Aktif" : "Veri Tasarrufu Devre Dışı",
      description: newMode 
        ? "Daha düşük kalitede ses ve görüntü kullanılacak." 
        : "Yüksek kalitede içerik kullanılacak.",
    });
  };
  
  // Clear cache
  const handleClearCache = async () => {
    const success = await clearCache();
    
    if (success) {
      toast({
        title: "Önbellek Temizlendi",
        description: "Uygulama önbelleği başarıyla temizlendi.",
      });
      
      // Update storage usage
      setStorageUsage(getStorageUsage());
    } else {
      toast({
        title: "Hata",
        description: "Önbellek temizlenirken bir sorun oluştu.",
        variant: "destructive",
      });
    }
  };
  
  // Install PWA
  const handleInstallPWA = async () => {
    const installed = await showInstallPrompt();
    
    if (installed) {
      setIsPWAInstalled(true);
      toast({
        title: "Uygulama Kuruldu",
        description: "MüzikAI başarıyla cihazınıza kuruldu!",
      });
    }
  };
  
  return (
    <div className="py-6 px-4 md:px-6 space-y-8">
      <motion.div 
        className="space-y-8"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        {/* Profile Card */}
        <Card className="shadow-sm">
          <CardHeader className="pb-4">
            <div className="flex items-center gap-4">
              <Avatar className="h-16 w-16 border-2 border-primary">
                <AvatarFallback className="bg-primary/20 text-primary">
                  <User className="h-8 w-8" />
                </AvatarFallback>
              </Avatar>
              
              <div>
                <CardTitle className="text-xl">Misafir Kullanıcı</CardTitle>
                <CardDescription>
                  <Badge className="mt-1">Ücretsiz</Badge>
                </CardDescription>
              </div>
            </div>
          </CardHeader>
          
          <CardContent className="pb-6">
            <div className="space-y-1">
              <div className="flex items-center justify-between text-sm">
                <span className="text-muted-foreground">Beğenilen Şarkılar</span>
                <span>12</span>
              </div>
              
              <div className="flex items-center justify-between text-sm">
                <span className="text-muted-foreground">Çalma Listeleri</span>
                <span>3</span>
              </div>
              
              <div className="flex items-center justify-between text-sm">
                <span className="text-muted-foreground">Dinleme Süresi</span>
                <span>5 saat 23 dakika</span>
              </div>
            </div>
          </CardContent>
        </Card>
        
        {/* Settings */}
        <div className="space-y-4">
          <div className="flex items-center gap-2">
            <Settings className="h-5 w-5 text-primary" />
            <h2 className="text-xl font-semibold">Ayarlar</h2>
          </div>
          
          <Card className="shadow-sm">
            <CardContent className="p-6 space-y-6">
              {/* Appearance */}
              <div className="space-y-4">
                <h3 className="text-sm font-medium text-muted-foreground">Görünüm</h3>
                
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    {theme === 'dark' ? <Moon className="h-4 w-4" /> : <Sun className="h-4 w-4" />}
                    <span>Karanlık Tema</span>
                  </div>
                  <Switch
                    checked={theme === 'dark'}
                    onCheckedChange={checked => setTheme(checked ? 'dark' : 'light')}
                  />
                </div>
              </div>
              
              {/* Data & Storage */}
              <div className="space-y-4">
                <h3 className="text-sm font-medium text-muted-foreground">Veri & Depolama</h3>
                
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <CloudOff className="h-4 w-4" />
                    <span>Çevrimdışı Mod</span>
                  </div>
                  <Switch
                    checked={offlineMode}
                    onCheckedChange={toggleOfflineMode}
                  />
                </div>
                
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Save className="h-4 w-4" />
                    <span>Veri Tasarrufu</span>
                  </div>
                  <Switch
                    checked={dataSaver}
                    onCheckedChange={handleToggleDataSaver}
                  />
                </div>
                
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Database className="h-4 w-4" />
                      <span>Depolama Kullanımı</span>
                    </div>
                    <span className="text-sm">{formatBytes(storageUsage.used)} / {formatBytes(storageUsage.total)}</span>
                  </div>
                  
                  <div className="w-full bg-muted h-2 rounded-full overflow-hidden">
                    <div 
                      className="bg-primary h-full" 
                      style={{ width: `${storageUsage.percentage}%` }}
                    />
                  </div>
                </div>
                
                <div className="flex gap-2">
                  <Button 
                    variant="outline" 
                    size="sm" 
                    className="text-xs"
                    onClick={prefetchOfflineData}
                  >
                    <Download className="h-3 w-3 mr-1" />
                    Çevrimdışı İçerik İndir
                  </Button>
                  
                  <Button 
                    variant="outline" 
                    size="sm" 
                    className="text-xs text-destructive hover:text-destructive"
                    onClick={handleClearCache}
                  >
                    <Trash2 className="h-3 w-3 mr-1" />
                    Önbelleği Temizle
                  </Button>
                </div>
              </div>
              
              {/* Application */}
              <div className="space-y-4">
                <h3 className="text-sm font-medium text-muted-foreground">Uygulama</h3>
                
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Music className="h-4 w-4" />
                    <span>Uygulama Versiyonu</span>
                  </div>
                  <span className="text-sm">1.0.0</span>
                </div>
                
                {!isPWAInstalled && (
                  <Button 
                    variant="default" 
                    className="w-full"
                    onClick={handleInstallPWA}
                  >
                    <Download className="h-4 w-4 mr-2" />
                    Ana Ekrana Ekle
                  </Button>
                )}
                
                <Button 
                  variant="outline" 
                  className="w-full text-destructive hover:text-destructive"
                >
                  <LogOut className="h-4 w-4 mr-2" />
                  Çıkış Yap
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </motion.div>
    </div>
  );
}
