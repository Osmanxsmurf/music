// Last.fm API ile veritabanı kontrolü 
import fetch from 'node-fetch';
import fs from 'fs';

// Last.fm API anahtarı
const LASTFM_API_KEY = process.env.LASTFM_API_KEY;
const LASTFM_BASE_URL = 'http://ws.audioscrobbler.com/2.0/';

// Xata veritabanını simüle eden test verileri - gerçek projenizde veritabanından çekilecek
const testData = {
  artists: [
    { name: 'Tarkan', genre: 'Pop' },
    { name: 'Duman', genre: 'Rock' },
    { name: 'Barış Manço', genre: 'Anadolu Rock' },
    { name: 'Sezen Aksu', genre: 'Pop' },
    { name: 'Müslüm Gürses', genre: 'Arabesk' },
    { name: 'Mor ve Ötesi', genre: 'Rock' },
    { name: 'Manga', genre: 'Rock' },
    { name: 'Ceza', genre: 'Hip-Hop' },
    { name: 'Teoman', genre: 'Rock' },
    { name: 'Metallica', genre: 'Metal' } // Test için yabancı sanatçı
  ],
  songs: [
    { title: 'Kuzu Kuzu', artist: 'Tarkan', albumArt: 'https://i.scdn.co/image/ab67616d0000b2737d214af8499aa95ad220f573' },
    { title: 'Seni Kendime Sakladım', artist: 'Duman', albumArt: 'https://i.scdn.co/image/ab67616d0000b273ebec4eed6303e0252465e9e5' },
    { title: 'Gülpembe', artist: 'Barış Manço', albumArt: 'https://i.scdn.co/image/ab67616d0000b273a2c0e4c2793f776c46b2ef12' },
    { title: 'Firuze', artist: 'Sezen Aksu', albumArt: 'https://i.scdn.co/image/ab67616d0000b273b3919e1d2bac71d1c33b2a5e' },
    { title: 'Nilüfer', artist: 'Müslüm Gürses', albumArt: 'https://i.scdn.co/image/ab67616d0000b273eadfe01bb0c14ba3f860a63a' },
    { title: 'Bir Derdim Var', artist: 'Mor ve Ötesi', albumArt: 'https://i.scdn.co/image/ab67616d0000b2737a4b35c303311e721e539b0c' },
    { title: 'Bir Kadın Çizeceksin', artist: 'Manga', albumArt: 'https://i.scdn.co/image/ab67616d0000b273a02b4da9519130e135837950' },
    { title: 'Suspus', artist: 'Ceza', albumArt: 'https://i.scdn.co/image/ab67616d0000b27363def56f26eb1abe0f897e09' },
    { title: 'Papatya', artist: 'Teoman', albumArt: 'https://i.scdn.co/image/ab67616d0000b273eb8ceca7c71d93e3c51d5799' },
    { title: 'Master of Puppets', artist: 'Metallica', albumArt: 'https://i.scdn.co/image/ab67616d0000b273668e3aca3167e6e569a9aa20' }
  ]
};

// Last.fm API'den sanatçı bilgisi almak için fonksiyon
async function getArtistInfo(artist) {
  try {
    const url = `${LASTFM_BASE_URL}?method=artist.getinfo&artist=${encodeURIComponent(artist)}&api_key=${LASTFM_API_KEY}&format=json`;
    const response = await fetch(url);
    
    if (!response.ok) {
      throw new Error(`Last.fm API hatası: ${response.status} - ${response.statusText}`);
    }
    
    const data = await response.json();
    
    if (data.error) {
      throw new Error(`Last.fm API hatası: ${data.message}`);
    }
    
    return data;
  } catch (error) {
    console.error(`${artist} için bilgi alınırken hata oluştu:`, error.message);
    return null;
  }
}

// Last.fm API'den şarkı bilgisi almak için fonksiyon
async function getTrackInfo(track, artist) {
  try {
    const url = `${LASTFM_BASE_URL}?method=track.getInfo&track=${encodeURIComponent(track)}&artist=${encodeURIComponent(artist)}&api_key=${LASTFM_API_KEY}&format=json`;
    const response = await fetch(url);
    
    if (!response.ok) {
      throw new Error(`Last.fm API hatası: ${response.status} - ${response.statusText}`);
    }
    
    const data = await response.json();
    
    if (data.error) {
      throw new Error(`Last.fm API hatası: ${data.message}`);
    }
    
    return data;
  } catch (error) {
    console.error(`${track} - ${artist} için bilgi alınırken hata oluştu:`, error.message);
    return null;
  }
}

// Sanatçıların doğrulamasını yap
async function validateArtists() {
  console.log("SANATÇI DOĞRULAMA RAPORU");
  console.log("------------------------");
  
  const results = [];
  
  for (const artist of testData.artists) {
    const info = await getArtistInfo(artist.name);
    
    if (!info || !info.artist) {
      results.push({
        name: artist.name,
        verified: false,
        message: "Last.fm'de bulunamadı",
        detail: null
      });
      continue;
    }
    
    // Sanatçı bilgilerini al
    const { name, url, bio, tags, stats, similar } = info.artist;
    
    // Tür (genre) eşleştirme kontrolü
    const tagNames = tags?.tag?.map(t => t.name.toLowerCase()) || [];
    const genreMatch = tagNames.some(tag => 
      tag.includes(artist.genre.toLowerCase()) || 
      artist.genre.toLowerCase().includes(tag)
    );
    
    results.push({
      name: artist.name,
      verified: true,
      message: genreMatch ? "Tür doğrulandı" : "Tür doğrulanamadı, Last.fm'de farklı tür bilgisi var",
      detail: {
        url,
        listeners: stats?.listeners,
        playcount: stats?.playcount,
        tags: tagNames.slice(0, 5),
        bio: bio?.summary?.substring(0, 100) + "..."
      }
    });
    
    // API limitlerini aşmamak için kısa bekleme
    await new Promise(resolve => setTimeout(resolve, 250));
  }
  
  // Sonuçları ekrana yazdır
  for (const result of results) {
    console.log(`✓ ${result.name}: ${result.verified ? 'DOĞRULANDI' : 'DOĞRULANAMADI'}`);
    console.log(`  → ${result.message}`);
    
    if (result.detail) {
      console.log(`  → Dinleyici: ${result.detail.listeners || 'Bilinmiyor'}`);
      console.log(`  → Etiketler: ${result.detail.tags.join(', ') || 'Bilinmiyor'}`);
      console.log(`  → Bio: ${result.detail.bio || 'Bilinmiyor'}`);
    }
    console.log("  -----------------");
  }
  
  return results;
}

// Şarkıların doğrulamasını yap
async function validateSongs() {
  console.log("\nŞARKI DOĞRULAMA RAPORU");
  console.log("------------------------");
  
  const results = [];
  
  for (const song of testData.songs) {
    const info = await getTrackInfo(song.title, song.artist);
    
    if (!info || !info.track) {
      results.push({
        title: song.title,
        artist: song.artist,
        verified: false,
        message: "Last.fm'de bulunamadı",
        detail: null
      });
      continue;
    }
    
    // Şarkı bilgilerini al
    const { name, artist: trackArtist, album, url, playcount, listeners } = info.track;
    
    // Sanatçı eşleştirme kontrolü
    const artistMatch = trackArtist.name.toLowerCase() === song.artist.toLowerCase();
    
    // Albüm kapağı kontrolü
    let albumArtMatch = false;
    let lastfmAlbumArt = null;
    
    if (album && album.image && Array.isArray(album.image)) {
      const largeImage = album.image.find(img => img.size === "large");
      if (largeImage && largeImage["#text"]) {
        lastfmAlbumArt = largeImage["#text"];
      }
    }
    
    if (lastfmAlbumArt && song.albumArt) {
      // Tam eşleşme olmayabilir, bu yüzden sadece var olup olmadığını kontrol ediyoruz
      albumArtMatch = Boolean(lastfmAlbumArt);
    }
    
    results.push({
      title: song.title,
      artist: song.artist,
      verified: artistMatch,
      message: artistMatch 
        ? "Sanatçı eşleşmesi doğrulandı" 
        : `Sanatçı eşleşmesi doğrulanamadı. Last.fm'de: ${trackArtist.name}`,
      detail: {
        url,
        playcount,
        listeners,
        album: album?.title || "Bilinmiyor",
        albumArt: lastfmAlbumArt,
        albumArtMatch
      }
    });
    
    // API limitlerini aşmamak için kısa bekleme
    await new Promise(resolve => setTimeout(resolve, 250));
  }
  
  // Sonuçları ekrana yazdır
  for (const result of results) {
    console.log(`✓ ${result.title} - ${result.artist}: ${result.verified ? 'DOĞRULANDI' : 'DOĞRULANAMADI'}`);
    console.log(`  → ${result.message}`);
    
    if (result.detail) {
      console.log(`  → Albüm: ${result.detail.album}`);
      console.log(`  → Çalma sayısı: ${result.detail.playcount || 'Bilinmiyor'}`);
      console.log(`  → Dinleyici: ${result.detail.listeners || 'Bilinmiyor'}`);
      
      if (result.detail.albumArt) {
        console.log(`  → Albüm kapağı: ${result.detail.albumArt}`);
        console.log(`  → Kapak eşleşmesi: ${result.detail.albumArtMatch ? 'EVET' : 'HAYIR'}`);
      } else {
        console.log(`  → Albüm kapağı: Bulunamadı`);
      }
    }
    console.log("  -----------------");
  }
  
  return results;
}

// Sonuçları dosyaya yazdırma fonksiyonu
function saveResultsToFile(artistResults, songResults) {
  const results = {
    verification_date: new Date().toISOString(),
    artists: artistResults,
    songs: songResults
  };
  
  fs.writeFileSync('verification_results.json', JSON.stringify(results, null, 2), 'utf8');
  console.log("\nSonuçlar 'verification_results.json' dosyasına kaydedildi.");
}

// Tüm doğrulama sürecini başlat ve çalıştır
async function runVerification() {
  console.log("Müzik veritabanı doğrulama işlemi başlatılıyor...");
  console.log(`Last.fm API kullanılıyor (API Anahtarı: ${LASTFM_API_KEY ? 'MEVCUT' : 'EKSİK'})`);
  console.log("=======================================================\n");
  
  // Sanatçı doğrulama
  const artistResults = await validateArtists();
  
  // Şarkı doğrulama
  const songResults = await validateSongs();
  
  // Sonuçları dosyaya kaydet
  saveResultsToFile(artistResults, songResults);
  
  // Özet istatistik
  const verifiedArtists = artistResults.filter(r => r.verified).length;
  const verifiedSongs = songResults.filter(r => r.verified).length;
  
  console.log("\nDOĞRULAMA ÖZETİ");
  console.log("------------------------");
  console.log(`Toplam sanatçı: ${artistResults.length}, Doğrulanan: ${verifiedArtists}, Oran: ${Math.round(verifiedArtists/artistResults.length*100)}%`);
  console.log(`Toplam şarkı: ${songResults.length}, Doğrulanan: ${verifiedSongs}, Oran: ${Math.round(verifiedSongs/songResults.length*100)}%`);
  console.log("\nDoğrulama işlemi tamamlandı.");
}

// Programı çalıştır
runVerification().catch(error => {
  console.error("Doğrulama sırasında bir hata oluştu:", error);
  process.exit(1);
});