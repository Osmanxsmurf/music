import { apiRequest } from "./queryClient";

// Types for authentication
export interface LoginCredentials {
  username: string;
  password: string;
}

export interface RegisterData {
  username: string;
  fullName: string;
  email: string;
  password: string;
}

export interface User {
  id: number;
  username: string;
  fullName: string;
  email: string;
  profilePicture: string | null;
}

// Login a user
export const loginUser = async (credentials: LoginCredentials): Promise<User> => {
  try {
    const response = await apiRequest("POST", "/api/auth/login", credentials);
    const data = await response.json();
    return data;
  } catch (error) {
    console.error("Login failed:", error);
    throw error;
  }
};

// Register a new user
export const registerUser = async (userData: RegisterData): Promise<User> => {
  try {
    const response = await apiRequest("POST", "/api/auth/register", userData);
    const data = await response.json();
    return data;
  } catch (error) {
    console.error("Registration failed:", error);
    throw error;
  }
};

// Logout the current user
export const logoutUser = async (): Promise<void> => {
  try {
    await apiRequest("POST", "/api/auth/logout", {});
  } catch (error) {
    console.error("Logout failed:", error);
    throw error;
  }
};

// Get the current authenticated user
export const getCurrentUser = async (): Promise<User | null> => {
  try {
    const response = await apiRequest("GET", "/api/auth/user", undefined);
    const data = await response.json();
    return data;
  } catch (error) {
    // Not authenticated or other error
    return null;
  }
};

// Check if a user is authenticated
export const isAuthenticated = async (): Promise<boolean> => {
  const user = await getCurrentUser();
  return !!user;
};

// Password validation
export const validatePassword = (password: string): { isValid: boolean; message?: string } => {
  if (password.length < 6) {
    return { isValid: false, message: "Şifre en az 6 karakter olmalıdır" };
  }
  
  return { isValid: true };
};

// Username validation
export const validateUsername = (username: string): { isValid: boolean; message?: string } => {
  if (username.length < 3) {
    return { isValid: false, message: "Kullanıcı adı en az 3 karakter olmalıdır" };
  }
  
  // Only allow alphanumeric characters and underscores
  if (!/^[a-zA-Z0-9_]+$/.test(username)) {
    return { isValid: false, message: "Kullanıcı adı sadece harf, rakam ve alt çizgi içerebilir" };
  }
  
  return { isValid: true };
};
