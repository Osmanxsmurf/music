import { useRef, useState, useEffect, useCallback } from 'react';

interface PullToRefreshOptions {
  onRefresh: () => Promise<void>;
  pullDownThreshold?: number;
  maxPullDownDistance?: number;
  refreshIndicatorHeight?: number;
}

export function usePullToRefresh(
  options: PullToRefreshOptions
) {
  const {
    onRefresh,
    pullDownThreshold = 80,
    maxPullDownDistance = 120,
    refreshIndicatorHeight = 60
  } = options;

  const [isPulling, setIsPulling] = useState(false);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [pullDistance, setPullDistance] = useState(0);
  
  const containerRef = useRef<HTMLDivElement>(null);
  const pullStartY = useRef<number | null>(null);
  const touchIdentifier = useRef<number | null>(null);

  const handleTouchStart = useCallback((e: TouchEvent) => {
    // Only handle pull to refresh if at the top of the container
    if (!containerRef.current || containerRef.current.scrollTop > 0) return;
    
    // Store the starting touch position
    pullStartY.current = e.touches[0].clientY;
    touchIdentifier.current = e.touches[0].identifier;
    setIsPulling(true);
  }, []);

  const handleTouchMove = useCallback((e: TouchEvent) => {
    // Exit if not pulling or pull start not set
    if (!isPulling || pullStartY.current === null || touchIdentifier.current === null) return;
    
    // Find the right touch by identifier
    let touchIndex = -1;
    for (let i = 0; i < e.changedTouches.length; i++) {
      if (e.changedTouches[i].identifier === touchIdentifier.current) {
        touchIndex = i;
        break;
      }
    }
    
    // Exit if touch not found
    if (touchIndex === -1) return;
    
    // Calculate pull distance
    const touchY = e.changedTouches[touchIndex].clientY;
    const pullDistance = Math.max(0, touchY - pullStartY.current);
    
    // Apply resistance to the pull (diminishing returns)
    const resistedPull = Math.min(
      maxPullDownDistance,
      pullDistance * 0.5
    );
    
    // Update state with current pull distance
    setPullDistance(resistedPull);
    
    // Prevent default scrolling if pulling
    if (resistedPull > 0) {
      e.preventDefault();
    }
  }, [isPulling, maxPullDownDistance]);

  const handleTouchEnd = useCallback(async () => {
    // Reset touch tracking
    pullStartY.current = null;
    touchIdentifier.current = null;
    
    // Check if we've pulled far enough to trigger refresh
    if (pullDistance >= pullDownThreshold) {
      setIsRefreshing(true);
      setPullDistance(refreshIndicatorHeight); // Keep showing the refresh indicator
      
      try {
        await onRefresh();
      } catch (error) {
        console.error('Pull to refresh error:', error);
      } finally {
        setIsRefreshing(false);
        setPullDistance(0);
      }
    } else {
      // Not pulled far enough, reset
      setPullDistance(0);
    }
    
    setIsPulling(false);
  }, [onRefresh, pullDistance, pullDownThreshold, refreshIndicatorHeight]);

  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;
    
    container.addEventListener('touchstart', handleTouchStart, { passive: true });
    container.addEventListener('touchmove', handleTouchMove, { passive: false });
    container.addEventListener('touchend', handleTouchEnd);
    container.addEventListener('touchcancel', handleTouchEnd);
    
    return () => {
      container.removeEventListener('touchstart', handleTouchStart);
      container.removeEventListener('touchmove', handleTouchMove);
      container.removeEventListener('touchend', handleTouchEnd);
      container.removeEventListener('touchcancel', handleTouchEnd);
    };
  }, [handleTouchStart, handleTouchMove, handleTouchEnd]);

  return {
    containerRef,
    pullDistance,
    isRefreshing,
    isPulling
  };
}
