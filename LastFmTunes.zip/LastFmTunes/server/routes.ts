import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { 
  insertSongSchema, 
  insertPlaylistSchema, 
  insertPlaylistSongSchema,
  insertUserLikedSongSchema,
  insertUserRecentlyPlayedSchema,
  insertAiMessageSchema
} from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // API Routes
  const apiRouter = app.route('/api');
  
  // Songs API
  app.get('/api/songs', async (req: Request, res: Response) => {
    try {
      const songs = await storage.getAllSongs();
      res.json(songs);
    } catch (error) {
      res.status(500).json({ message: 'Error fetching songs' });
    }
  });
  
  app.get('/api/songs/:id', async (req: Request, res: Response) => {
    try {
      const songId = parseInt(req.params.id);
      const song = await storage.getSong(songId);
      
      if (!song) {
        return res.status(404).json({ message: 'Song not found' });
      }
      
      res.json(song);
    } catch (error) {
      res.status(500).json({ message: 'Error fetching song' });
    }
  });
  
  app.get('/api/songs/mood/:mood', async (req: Request, res: Response) => {
    try {
      const mood = req.params.mood;
      const songs = await storage.getSongsByMood(mood);
      res.json(songs);
    } catch (error) {
      res.status(500).json({ message: 'Error fetching songs by mood' });
    }
  });
  
  // Playlists API
  app.get('/api/playlists/user/:userId', async (req: Request, res: Response) => {
    try {
      const userId = parseInt(req.params.userId);
      const playlists = await storage.getUserPlaylists(userId);
      res.json(playlists);
    } catch (error) {
      res.status(500).json({ message: 'Error fetching user playlists' });
    }
  });
  
  app.get('/api/playlists/:id', async (req: Request, res: Response) => {
    try {
      const playlistId = parseInt(req.params.id);
      const playlist = await storage.getPlaylist(playlistId);
      
      if (!playlist) {
        return res.status(404).json({ message: 'Playlist not found' });
      }
      
      const songs = await storage.getPlaylistSongs(playlistId);
      
      res.json({
        playlist,
        songs
      });
    } catch (error) {
      res.status(500).json({ message: 'Error fetching playlist' });
    }
  });
  
  app.post('/api/playlists', async (req: Request, res: Response) => {
    try {
      const validateResult = insertPlaylistSchema.safeParse(req.body);
      
      if (!validateResult.success) {
        return res.status(400).json({ message: 'Invalid playlist data', errors: validateResult.error });
      }
      
      const playlist = await storage.createPlaylist(validateResult.data);
      res.status(201).json(playlist);
    } catch (error) {
      res.status(500).json({ message: 'Error creating playlist' });
    }
  });
  
  app.post('/api/playlists/:id/songs', async (req: Request, res: Response) => {
    try {
      const playlistId = parseInt(req.params.id);
      
      const playlist = await storage.getPlaylist(playlistId);
      if (!playlist) {
        return res.status(404).json({ message: 'Playlist not found' });
      }
      
      const validateResult = insertPlaylistSongSchema.safeParse({ 
        ...req.body,
        playlistId
      });
      
      if (!validateResult.success) {
        return res.status(400).json({ message: 'Invalid playlist song data', errors: validateResult.error });
      }
      
      const playlistSong = await storage.addSongToPlaylist(validateResult.data);
      res.status(201).json(playlistSong);
    } catch (error) {
      res.status(500).json({ message: 'Error adding song to playlist' });
    }
  });
  
  app.delete('/api/playlists/:playlistId/songs/:songId', async (req: Request, res: Response) => {
    try {
      const playlistId = parseInt(req.params.playlistId);
      const songId = parseInt(req.params.songId);
      
      await storage.removeSongFromPlaylist(playlistId, songId);
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: 'Error removing song from playlist' });
    }
  });
  
  // Liked Songs API
  app.get('/api/users/:userId/liked-songs', async (req: Request, res: Response) => {
    try {
      const userId = parseInt(req.params.userId);
      const likedSongs = await storage.getLikedSongs(userId);
      res.json(likedSongs);
    } catch (error) {
      res.status(500).json({ message: 'Error fetching liked songs' });
    }
  });
  
  app.post('/api/users/:userId/liked-songs', async (req: Request, res: Response) => {
    try {
      const userId = parseInt(req.params.userId);
      
      const validateResult = insertUserLikedSongSchema.safeParse({
        ...req.body,
        userId
      });
      
      if (!validateResult.success) {
        return res.status(400).json({ message: 'Invalid liked song data', errors: validateResult.error });
      }
      
      const likedSong = await storage.likeSong(validateResult.data);
      res.status(201).json(likedSong);
    } catch (error) {
      res.status(500).json({ message: 'Error liking song' });
    }
  });
  
  app.delete('/api/users/:userId/liked-songs/:songId', async (req: Request, res: Response) => {
    try {
      const userId = parseInt(req.params.userId);
      const songId = parseInt(req.params.songId);
      
      await storage.unlikeSong(userId, songId);
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: 'Error unliking song' });
    }
  });
  
  // Recently Played API
  app.get('/api/users/:userId/recently-played', async (req: Request, res: Response) => {
    try {
      const userId = parseInt(req.params.userId);
      const limit = req.query.limit ? parseInt(req.query.limit as string) : undefined;
      
      const recentlyPlayed = await storage.getRecentlyPlayed(userId, limit);
      res.json(recentlyPlayed);
    } catch (error) {
      res.status(500).json({ message: 'Error fetching recently played songs' });
    }
  });
  
  app.post('/api/users/:userId/recently-played', async (req: Request, res: Response) => {
    try {
      const userId = parseInt(req.params.userId);
      
      const validateResult = insertUserRecentlyPlayedSchema.safeParse({
        ...req.body,
        userId
      });
      
      if (!validateResult.success) {
        return res.status(400).json({ message: 'Invalid recently played data', errors: validateResult.error });
      }
      
      const recentlyPlayed = await storage.addRecentlyPlayed(validateResult.data);
      res.status(201).json(recentlyPlayed);
    } catch (error) {
      res.status(500).json({ message: 'Error adding recently played' });
    }
  });
  
  // AI Chat API
  app.get('/api/users/:userId/chat-history', async (req: Request, res: Response) => {
    try {
      const userId = parseInt(req.params.userId);
      const limit = req.query.limit ? parseInt(req.query.limit as string) : undefined;
      
      const chatHistory = await storage.getChatHistory(userId, limit);
      res.json(chatHistory);
    } catch (error) {
      res.status(500).json({ message: 'Error fetching chat history' });
    }
  });
  
  app.post('/api/users/:userId/chat', async (req: Request, res: Response) => {
    try {
      const userId = parseInt(req.params.userId);
      
      // Validate the user message
      const validateUserMsg = insertAiMessageSchema.safeParse({
        userId,
        role: 'user',
        content: req.body.message
      });
      
      if (!validateUserMsg.success) {
        return res.status(400).json({ message: 'Invalid chat message', errors: validateUserMsg.error });
      }
      
      // Store the user message
      const userMessage = await storage.addChatMessage(validateUserMsg.data);
      
      // Get chat history for context
      const chatHistory = await storage.getChatHistory(userId);
      
      // Generate AI response (simulated here, but would connect to an AI service)
      const responseText = generateAIResponse(req.body.message, chatHistory);
      
      // Get song recommendations based on the message content
      const relatedSongs = await getRecommendedSongs(req.body.message);
      
      // Store the AI response
      const validateAiMsg = insertAiMessageSchema.safeParse({
        userId,
        role: 'assistant',
        content: responseText
      });
      
      if (!validateAiMsg.success) {
        return res.status(500).json({ message: 'Error generating AI response' });
      }
      
      const assistantMessage = await storage.addChatMessage(validateAiMsg.data);
      
      // Return the AI response and recommendations
      res.json({
        message: assistantMessage,
        recommendations: relatedSongs
      });
    } catch (error) {
      res.status(500).json({ message: 'Error processing chat message' });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}

// Simple AI response generator (would be replaced with a real AI service)
function generateAIResponse(message: string, chatHistory: any[]): string {
  // Simple keyword matching
  const messageLC = message.toLowerCase();
  
  if (messageLC.includes('hello') || messageLC.includes('hi')) {
    return "Hello! How can I help you with music today?";
  }
  
  if (messageLC.includes('recommend') || messageLC.includes('suggest')) {
    if (messageLC.includes('pop')) {
      return "I'd recommend some popular pop songs like 'Blinding Lights' by The Weeknd or 'Don't Start Now' by Dua Lipa.";
    }
    if (messageLC.includes('rock')) {
      return "For rock music, you might enjoy 'Sweet Child O' Mine' by Guns N' Roses or 'Bohemian Rhapsody' by Queen.";
    }
    if (messageLC.includes('chill') || messageLC.includes('relax')) {
      return "For a relaxing mood, try 'The Less I Know The Better' by Tame Impala or some ambient music by Brian Eno.";
    }
    return "I'd be happy to recommend some music! Could you tell me what genre or mood you're looking for?";
  }
  
  if (messageLC.includes('sad') || messageLC.includes('depress')) {
    return "I understand you might be feeling down. Music can help - maybe try 'lovely' by Billie Eilish and Khalid, which many find comforting during difficult times.";
  }
  
  if (messageLC.includes('energetic') || messageLC.includes('workout') || messageLC.includes('exercise')) {
    return "For an energy boost, I recommend upbeat tracks like 'Physical' by Dua Lipa or 'Blinding Lights' by The Weeknd.";
  }
  
  if (messageLC.includes('focus') || messageLC.includes('study') || messageLC.includes('work')) {
    return "For focusing, I suggest ambient or instrumental music. Try the 'Deep Focus' playlist with artists like Brian Eno.";
  }
  
  // Default response if no keywords match
  return "I'm your music assistant! I can recommend songs based on your mood, help you discover new music, or create playlists. What would you like to know?";
}

// Get song recommendations based on message content
async function getRecommendedSongs(message: string): Promise<any[]> {
  const messageLC = message.toLowerCase();
  const allSongs = await storage.getAllSongs();
  
  // Match by mood or genre keywords
  if (messageLC.includes('happy') || messageLC.includes('energetic') || messageLC.includes('upbeat')) {
    return allSongs.filter(song => 
      song.mood?.includes('energetic') || 
      song.mood?.includes('happy') || 
      song.mood?.includes('upbeat')
    ).slice(0, 5);
  }
  
  if (messageLC.includes('sad') || messageLC.includes('emotional')) {
    return allSongs.filter(song => 
      song.mood?.includes('sad') || 
      song.mood?.includes('emotional')
    ).slice(0, 5);
  }
  
  if (messageLC.includes('chill') || messageLC.includes('relax')) {
    return allSongs.filter(song => 
      song.mood?.includes('chill') || 
      song.mood?.includes('calm')
    ).slice(0, 5);
  }
  
  if (messageLC.includes('focus') || messageLC.includes('study')) {
    return allSongs.filter(song => 
      song.mood?.includes('focused') || 
      song.genre === 'Ambient'
    ).slice(0, 5);
  }
  
  // Match by genre
  if (messageLC.includes('rock')) {
    return allSongs.filter(song => song.genre === 'Rock').slice(0, 5);
  }
  
  if (messageLC.includes('pop')) {
    return allSongs.filter(song => song.genre === 'Pop').slice(0, 5);
  }
  
  // If no specific keywords, return a random selection
  return allSongs
    .sort(() => 0.5 - Math.random())
    .slice(0, 5);
}
