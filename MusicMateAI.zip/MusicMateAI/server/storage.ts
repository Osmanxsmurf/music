import { 
  users, 
  favorites, 
  playHistory, 
  searches, 
  aiChats,
  type User, 
  type InsertUser, 
  type Favorite, 
  type InsertFavorite,
  type PlayHistory,
  type InsertPlayHistory,
  type Search,
  type InsertSearch,
  type AiChat,
  type InsertAiChat
} from "@shared/schema";

// Storage interface
export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Favorite methods
  getFavorites(userId: number): Promise<Favorite[]>;
  addFavorite(favorite: InsertFavorite): Promise<Favorite>;
  removeFavorite(userId: number, trackId: string): Promise<boolean>;
  isFavorite(userId: number, trackId: string): Promise<boolean>;

  // Play History methods
  getPlayHistory(userId: number, limit?: number): Promise<PlayHistory[]>;
  addPlayHistory(history: InsertPlayHistory): Promise<PlayHistory>;

  // Search methods
  getRecentSearches(userId: number, limit?: number): Promise<Search[]>;
  addSearch(search: InsertSearch): Promise<Search>;

  // AI Chat methods
  getAiChats(userId: number): Promise<AiChat[]>;
  getAiChat(chatId: number): Promise<AiChat | undefined>;
  createAiChat(chat: InsertAiChat): Promise<AiChat>;
  updateAiChat(chatId: number, messages: any[]): Promise<AiChat | undefined>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private favorites: Map<number, Favorite[]>;
  private playHistories: Map<number, PlayHistory[]>;
  private searches: Map<number, Search[]>;
  private aiChats: Map<number, AiChat[]>;
  private currentUserId: number;
  private currentFavoriteId: number;
  private currentPlayHistoryId: number;
  private currentSearchId: number;
  private currentAiChatId: number;

  constructor() {
    this.users = new Map();
    this.favorites = new Map();
    this.playHistories = new Map();
    this.searches = new Map();
    this.aiChats = new Map();
    this.currentUserId = 1;
    this.currentFavoriteId = 1;
    this.currentPlayHistoryId = 1;
    this.currentSearchId = 1;
    this.currentAiChatId = 1;
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username
    );
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.email === email
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const timestamp = new Date();
    const user: User = { 
      ...insertUser, 
      id, 
      createdAt: timestamp
    };
    this.users.set(id, user);
    this.favorites.set(id, []);
    this.playHistories.set(id, []);
    this.searches.set(id, []);
    this.aiChats.set(id, []);
    return user;
  }

  // Favorite methods
  async getFavorites(userId: number): Promise<Favorite[]> {
    return this.favorites.get(userId) || [];
  }

  async addFavorite(insertFavorite: InsertFavorite): Promise<Favorite> {
    const id = this.currentFavoriteId++;
    const timestamp = new Date();
    const favorite: Favorite = { 
      ...insertFavorite, 
      id, 
      createdAt: timestamp 
    };
    const userFavorites = this.favorites.get(insertFavorite.userId) || [];
    userFavorites.push(favorite);
    this.favorites.set(insertFavorite.userId, userFavorites);
    return favorite;
  }

  async removeFavorite(userId: number, trackId: string): Promise<boolean> {
    const userFavorites = this.favorites.get(userId) || [];
    const initialLength = userFavorites.length;
    const filteredFavorites = userFavorites.filter(f => f.trackId !== trackId);
    this.favorites.set(userId, filteredFavorites);
    return filteredFavorites.length < initialLength;
  }

  async isFavorite(userId: number, trackId: string): Promise<boolean> {
    const userFavorites = this.favorites.get(userId) || [];
    return userFavorites.some(f => f.trackId === trackId);
  }

  // Play History methods
  async getPlayHistory(userId: number, limit = 10): Promise<PlayHistory[]> {
    const userHistory = this.playHistories.get(userId) || [];
    return userHistory
      .sort((a, b) => b.playedAt.getTime() - a.playedAt.getTime())
      .slice(0, limit);
  }

  async addPlayHistory(insertHistory: InsertPlayHistory): Promise<PlayHistory> {
    const id = this.currentPlayHistoryId++;
    const timestamp = new Date();
    const history: PlayHistory = { 
      ...insertHistory, 
      id, 
      playedAt: timestamp 
    };
    const userHistory = this.playHistories.get(insertHistory.userId) || [];
    userHistory.push(history);
    this.playHistories.set(insertHistory.userId, userHistory);
    return history;
  }

  // Search methods
  async getRecentSearches(userId: number, limit = 5): Promise<Search[]> {
    const userSearches = this.searches.get(userId) || [];
    return userSearches
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime())
      .slice(0, limit);
  }

  async addSearch(insertSearch: InsertSearch): Promise<Search> {
    const id = this.currentSearchId++;
    const timestamp = new Date();
    const search: Search = { 
      ...insertSearch, 
      id, 
      createdAt: timestamp 
    };
    const userSearches = this.searches.get(insertSearch.userId) || [];
    userSearches.push(search);
    this.searches.set(insertSearch.userId, userSearches);
    return search;
  }

  // AI Chat methods
  async getAiChats(userId: number): Promise<AiChat[]> {
    return this.aiChats.get(userId) || [];
  }

  async getAiChat(chatId: number): Promise<AiChat | undefined> {
    for (const chats of this.aiChats.values()) {
      const chat = chats.find(c => c.id === chatId);
      if (chat) return chat;
    }
    return undefined;
  }

  async createAiChat(insertChat: InsertAiChat): Promise<AiChat> {
    const id = this.currentAiChatId++;
    const timestamp = new Date();
    const chat: AiChat = { 
      ...insertChat, 
      id, 
      createdAt: timestamp 
    };
    const userChats = this.aiChats.get(insertChat.userId) || [];
    userChats.push(chat);
    this.aiChats.set(insertChat.userId, userChats);
    return chat;
  }

  async updateAiChat(chatId: number, messages: any[]): Promise<AiChat | undefined> {
    for (const [userId, chats] of this.aiChats.entries()) {
      const chatIndex = chats.findIndex(c => c.id === chatId);
      if (chatIndex !== -1) {
        chats[chatIndex].messages = messages;
        return chats[chatIndex];
      }
    }
    return undefined;
  }
}

export const storage = new MemStorage();
