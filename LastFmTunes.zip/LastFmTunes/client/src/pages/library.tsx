import React, { useState, useEffect } from 'react';
import { useLocation } from 'wouter';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { SongCard } from '@/components/SongCard';
import { MusicPlayerContext } from '@/components/Layout';
import { fetchLikedSongs, fetchRecentlyPlayed } from '@/lib/xata';
import { useToast } from '@/hooks/use-toast';
import { usePullToRefresh } from '@/hooks/use-pull-to-refresh';
import { Loader2, Heart, History, PlaySquare, FolderPlus, Search } from 'lucide-react';
import { Song } from '@shared/schema';
import { motion } from 'framer-motion';

export default function LibraryPage() {
  const [location] = useLocation();
  const { playSong } = React.useContext(MusicPlayerContext);
  const { toast } = useToast();
  
  const [activeTab, setActiveTab] = useState('liked');
  const [likedSongs, setLikedSongs] = useState<Song[]>([]);
  const [recentlyPlayed, setRecentlyPlayed] = useState<Song[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  
  // Determine which tab to show based on URL
  useEffect(() => {
    if (location.includes('/liked')) {
      setActiveTab('liked');
    } else if (location.includes('/recent')) {
      setActiveTab('recent');
    } else if (location.includes('/playlists')) {
      setActiveTab('playlists');
    }
  }, [location]);
  
  // Load data
  const fetchData = async () => {
    setLoading(true);
    try {
      const [liked, recent] = await Promise.all([
        fetchLikedSongs(1),
        fetchRecentlyPlayed(1, 20)
      ]);
      
      setLikedSongs(liked);
      setRecentlyPlayed(recent);
    } catch (error) {
      console.error("Error loading library data:", error);
      toast({
        title: "Veri Yükleme Hatası",
        description: "Kitaplık verileri yüklenirken bir sorun oluştu.",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };
  
  // Load data on mount
  useEffect(() => {
    fetchData();
  }, []);
  
  // Pull to refresh
  const { containerRef, pullDistance, isRefreshing } = usePullToRefresh({
    onRefresh: fetchData
  });
  
  // Filter songs based on search
  const filterSongs = (songs: Song[]) => {
    if (!searchQuery.trim()) return songs;
    
    const query = searchQuery.toLowerCase();
    return songs.filter(song => 
      song.title.toLowerCase().includes(query) ||
      song.artist.toLowerCase().includes(query) ||
      (song.album && song.album.toLowerCase().includes(query)) ||
      (song.genre && song.genre.toLowerCase().includes(query))
    );
  };
  
  const filteredLikedSongs = filterSongs(likedSongs);
  const filteredRecentlyPlayed = filterSongs(recentlyPlayed);
  
  // Refresh indicator styles
  const refreshIndicatorStyles = {
    height: `${pullDistance}px`,
    opacity: pullDistance > 0 ? 1 : 0,
  };
  
  return (
    <div 
      ref={containerRef}
      className="py-6 px-4 md:px-6 space-y-8 overflow-auto h-full"
    >
      {/* Pull to refresh indicator */}
      <div 
        className="flex justify-center items-center absolute top-0 left-0 right-0 z-10 overflow-hidden"
        style={refreshIndicatorStyles}
      >
        {isRefreshing ? (
          <Loader2 className="animate-spin text-primary h-6 w-6" />
        ) : (
          <div className="text-primary text-xs">↓ Yenilemek için çekin</div>
        )}
      </div>
      
      <div className="space-y-6">
        <h2 className="text-2xl font-bold">Kitaplık</h2>
        
        {/* Search */}
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
          <Input
            placeholder="Kitaplığınızda arayın..."
            className="pl-9"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
        
        {/* Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid grid-cols-3 mb-4">
            <TabsTrigger value="liked" className="flex items-center gap-1">
              <Heart className="h-4 w-4" />
              <span>Beğendiklerim</span>
            </TabsTrigger>
            <TabsTrigger value="recent" className="flex items-center gap-1">
              <History className="h-4 w-4" />
              <span>Son Çalınanlar</span>
            </TabsTrigger>
            <TabsTrigger value="playlists" className="flex items-center gap-1">
              <PlaySquare className="h-4 w-4" />
              <span>Listelerim</span>
            </TabsTrigger>
          </TabsList>
          
          {/* Liked Songs */}
          <TabsContent value="liked" className="space-y-4">
            {loading ? (
              <div className="flex justify-center py-12">
                <Loader2 className="h-8 w-8 animate-spin text-primary" />
              </div>
            ) : filteredLikedSongs.length > 0 ? (
              <motion.div 
                className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4"
                variants={{
                  hidden: { opacity: 0 },
                  show: {
                    opacity: 1,
                    transition: {
                      staggerChildren: 0.05
                    }
                  }
                }}
                initial="hidden"
                animate="show"
              >
                {filteredLikedSongs.map((song, index) => (
                  <motion.div
                    key={song.id}
                    variants={{
                      hidden: { opacity: 0, y: 20 },
                      show: { opacity: 1, y: 0 }
                    }}
                  >
                    <SongCard 
                      song={song} 
                      onPlay={playSong}
                      isLiked={true}
                      onLike={() => {}}
                    />
                  </motion.div>
                ))}
              </motion.div>
            ) : searchQuery ? (
              <div className="text-center py-12">
                <p className="text-muted-foreground">"{searchQuery}" için sonuç bulunamadı.</p>
              </div>
            ) : (
              <div className="text-center py-12 space-y-4">
                <Heart className="h-16 w-16 mx-auto text-muted-foreground/50" />
                <h3 className="text-xl font-semibold">Henüz beğenilen şarkı yok</h3>
                <p className="text-muted-foreground">
                  Beğendiğiniz şarkılar burada görünecek.
                </p>
                <Button className="mt-4">Keşfetmeye Başla</Button>
              </div>
            )}
          </TabsContent>
          
          {/* Recently Played */}
          <TabsContent value="recent" className="space-y-4">
            {loading ? (
              <div className="flex justify-center py-12">
                <Loader2 className="h-8 w-8 animate-spin text-primary" />
              </div>
            ) : filteredRecentlyPlayed.length > 0 ? (
              <motion.div 
                className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4"
                variants={{
                  hidden: { opacity: 0 },
                  show: {
                    opacity: 1,
                    transition: {
                      staggerChildren: 0.05
                    }
                  }
                }}
                initial="hidden"
                animate="show"
              >
                {filteredRecentlyPlayed.map((song) => (
                  <motion.div
                    key={song.id}
                    variants={{
                      hidden: { opacity: 0, y: 20 },
                      show: { opacity: 1, y: 0 }
                    }}
                  >
                    <SongCard 
                      song={song} 
                      onPlay={playSong} 
                    />
                  </motion.div>
                ))}
              </motion.div>
            ) : searchQuery ? (
              <div className="text-center py-12">
                <p className="text-muted-foreground">"{searchQuery}" için sonuç bulunamadı.</p>
              </div>
            ) : (
              <div className="text-center py-12 space-y-4">
                <History className="h-16 w-16 mx-auto text-muted-foreground/50" />
                <h3 className="text-xl font-semibold">Henüz dinlenen şarkı yok</h3>
                <p className="text-muted-foreground">
                  Son dinlediğiniz şarkılar burada görünecek.
                </p>
                <Button className="mt-4">Keşfetmeye Başla</Button>
              </div>
            )}
          </TabsContent>
          
          {/* Playlists */}
          <TabsContent value="playlists" className="space-y-4">
            <div className="text-center py-12 space-y-4">
              <FolderPlus className="h-16 w-16 mx-auto text-muted-foreground/50" />
              <h3 className="text-xl font-semibold">Henüz çalma listeniz yok</h3>
              <p className="text-muted-foreground">
                Sevdiğiniz şarkıları bir araya getirmek için çalma listeleri oluşturun.
              </p>
              <Button className="mt-4">Çalma Listesi Oluştur</Button>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
