// Xata veritabanı verilerini kontrol etmek için test betiği
import { checkAndValidateData } from './xata-client.js';

// Veritabanı verilerini kontrol et
async function main() {
  console.log("Xata veritabanı veri doğrulama başlatılıyor...");
  
  try {
    const result = await checkAndValidateData();
    
    if (result.success) {
      console.log("\n✅ Veri doğrulama başarılı");
      console.log(`Toplam sanatçı sayısı: ${result.artistCount}`);
      console.log(`Toplam şarkı sayısı: ${result.songCount}`);
      
      // Sanatçı örnekleri
      if (result.artists && result.artists.length > 0) {
        console.log("\nSanatçı Örnekleri:");
        result.artists.forEach(artist => {
          console.log(`- ${artist.name} (${artist.genre})`);
        });
      }
      
      // Şarkı örnekleri
      if (result.songs && result.songs.length > 0) {
        console.log("\nŞarkı Örnekleri:");
        result.songs.forEach(song => {
          console.log(`- "${song.title}" - ${song.artist} (${song.genre})`);
        });
      }
    } else {
      console.error("❌ Veri doğrulama başarısız:", result.error);
    }
  } catch (error) {
    console.error("Hata oluştu:", error);
  }
}

// Betiği çalıştır
main().catch(error => {
  console.error("Hata oluştu:", error);
});