# MusicAI - Duygu Tabanlı Müzik Asistanı

MusicAI, kullanıcıların duygularına göre müzik önerileri sunan, Türk müzik kültürüne odaklanan ve yapay zeka asistanıyla zenginleştirilmiş bir müzik uygulamasıdır.

## Özellikler

- **Duygu Tabanlı Müzik Önerileri**: Kullanıcıların duygu durumlarına göre özelleştirilmiş müzik önerileri
- **Türk Sanatçı Vitrini**: Popüler Türk sanatçılarını ve şarkılarını keşfetme imkanı 
- **Makam Keşif**: Türk müziğinin zengin makam dünyasını interaktif bir şekilde keşfetme
- **Müzik Yapay Zeka Sohbeti**: Müzik tercihleri ve duygusal duruma göre önerilerde bulunan AI sohbet asistanı
- **Müzik Haberleri**: Güncel müzik haberlerini takip etme
- **Türk Müziği Kültür Rehberi**: Türk müziği hakkında kapsamlı bilgiler

## Teknolojiler

- **Frontend**: React, Tailwind CSS, Shadcn/UI
- **Backend**: Express.js, Node.js
- **API Entegrasyonları**: YouTube API, Last.fm API, Xata veritabanı
- **Yapay Zeka**: 5 milyon satırlık özel eğitilmiş duygu analizi ve müzik öneri modeli

## Nasıl Kullanılır

1. Ana sayfada popüler türleri ve Türk sanatçılarını görüntüleyin
2. "AI Sohbet" sayfasında duygu durumunuzu belirterek size uygun müzik önerileri alın
3. Makam Keşif bölümünde Türk müziğinin zengin makam dünyasını keşfedin
4. Müzik haberlerini takip edin ve en güncel gelişmelerden haberdar olun

## Kurulum

```bash
# Repo'yu klonlayın
git clone [repo-url]

# Gerekli paketleri yükleyin
npm install

# Uygulamayı başlatın
npm run dev
```

## Gerekli API Anahtarları

Uygulamayı tam fonksiyonel kullanmak için aşağıdaki API anahtarlarını `.env` dosyasına eklemeniz gerekir:

- `YOUTUBE_API_KEY`: YouTube API için
- `LASTFM_API_KEY`: Last.fm API için
- `XATA_API_KEY`: Xata veritabanı için

## Katkıda Bulunanlar

- Müzik Asistanı AI Modeli: 5 milyon satırlık veriyle eğitilmiş özel model
- Türk Müzik Kültürü İçeriği: Makam, usul ve geleneksel müzik formları hakkında kapsamlı bilgiler
- Duygu Analizi Motoru: Kullanıcıların duygusal durumlarını analiz ederek müzik önerileri sunan algoritma

---

Bu proje, Türk müzik kültürünü modern teknolojilerle buluşturmak, yapay zeka destekli müzik önerileri sunmak ve kullanıcıların duygusal durumlarına göre kişiselleştirilmiş müzik deneyimi sunmak amacıyla geliştirilmiştir.