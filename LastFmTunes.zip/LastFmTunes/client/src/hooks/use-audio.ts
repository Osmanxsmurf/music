import { useState, useEffect, useRef, useCallback } from 'react';
import { DEFAULT_VOLUME, SKIP_TIME, LOCAL_STORAGE_KEYS } from '@/lib/constants';
import { getStoredData, setStoredData } from '@/lib/localStorage';
import { Song } from '@shared/schema';

type PlayerState = 'playing' | 'paused' | 'loading' | 'error' | 'ended';

export function useAudio() {
  // State
  const [currentSong, setCurrentSong] = useState<Song | null>(null);
  const [playerState, setPlayerState] = useState<PlayerState>('paused');
  const [duration, setDuration] = useState(0);
  const [currentTime, setCurrentTime] = useState(0);
  const [volume, setVolume] = useState(DEFAULT_VOLUME);
  
  // Refs
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const animationRef = useRef<number | null>(null);
  
  // Initialize audio element and volume
  useEffect(() => {
    const audio = new Audio();
    audioRef.current = audio;
    
    // Load saved volume
    getStoredData<number>(LOCAL_STORAGE_KEYS.VOLUME, DEFAULT_VOLUME)
      .then(savedVolume => {
        setVolume(savedVolume);
        if (audio) {
          audio.volume = savedVolume;
        }
      });
    
    // Set up event listeners
    audio.addEventListener('timeupdate', updateProgress);
    audio.addEventListener('loadedmetadata', () => {
      setDuration(audio.duration);
    });
    audio.addEventListener('play', () => setPlayerState('playing'));
    audio.addEventListener('pause', () => setPlayerState('paused'));
    audio.addEventListener('waiting', () => setPlayerState('loading'));
    audio.addEventListener('error', () => setPlayerState('error'));
    audio.addEventListener('ended', () => setPlayerState('ended'));
    
    return () => {
      // Clean up event listeners
      cancelAnimationFrame(animationRef.current!);
      audio.removeEventListener('timeupdate', updateProgress);
      audio.removeEventListener('loadedmetadata', () => {});
      audio.removeEventListener('play', () => {});
      audio.removeEventListener('pause', () => {});
      audio.removeEventListener('waiting', () => {});
      audio.removeEventListener('error', () => {});
      audio.removeEventListener('ended', () => {});
      
      // Stop audio
      audio.pause();
      audio.src = '';
    };
  }, []);
  
  // Update audio volume when volume state changes
  useEffect(() => {
    if (audioRef.current) {
      audioRef.current.volume = volume;
      setStoredData(LOCAL_STORAGE_KEYS.VOLUME, volume);
    }
  }, [volume]);
  
  // Update progress indicator
  const updateProgress = useCallback(() => {
    if (audioRef.current) {
      setCurrentTime(audioRef.current.currentTime);
      animationRef.current = requestAnimationFrame(updateProgress);
    }
  }, []);
  
  // Play a song
  const playSong = useCallback(async (song: Song) => {
    if (!audioRef.current) return;
    
    try {
      // Stop current song if playing
      audioRef.current.pause();
      
      // Set new song
      setCurrentSong(song);
      audioRef.current.src = song.audioUrl || '';
      
      // Update media session metadata
      if ('mediaSession' in navigator) {
        navigator.mediaSession.metadata = new MediaMetadata({
          title: song.title,
          artist: song.artist,
          album: song.album || '',
          artwork: [
            { src: song.coverImage || '', sizes: '512x512', type: 'image/jpeg' }
          ]
        });
      }
      
      // Start playing
      const playPromise = audioRef.current.play();
      
      if (playPromise !== undefined) {
        playPromise
          .then(() => {
            setPlayerState('playing');
            animationRef.current = requestAnimationFrame(updateProgress);
          })
          .catch(error => {
            console.error('Error playing audio:', error);
            setPlayerState('error');
          });
      }
    } catch (error) {
      console.error('Error setting up audio playback:', error);
      setPlayerState('error');
    }
  }, [updateProgress]);
  
  // Pause playback
  const pauseSong = useCallback(() => {
    if (!audioRef.current) return;
    
    audioRef.current.pause();
    setPlayerState('paused');
    cancelAnimationFrame(animationRef.current!);
  }, []);
  
  // Resume playback
  const resumeSong = useCallback(() => {
    if (!audioRef.current || playerState === 'error') return;
    
    const playPromise = audioRef.current.play();
    
    if (playPromise !== undefined) {
      playPromise
        .then(() => {
          setPlayerState('playing');
          animationRef.current = requestAnimationFrame(updateProgress);
        })
        .catch(error => {
          console.error('Error resuming audio:', error);
          setPlayerState('error');
        });
    }
  }, [playerState, updateProgress]);
  
  // Toggle play/pause
  const togglePlayPause = useCallback(() => {
    if (playerState === 'playing') {
      pauseSong();
    } else {
      resumeSong();
    }
  }, [playerState, pauseSong, resumeSong]);
  
  // Seek to a specific time
  const seekTo = useCallback((time: number) => {
    if (!audioRef.current) return;
    
    audioRef.current.currentTime = time;
    setCurrentTime(time);
  }, []);
  
  // Skip forward
  const skipForward = useCallback(() => {
    if (!audioRef.current) return;
    
    const newTime = Math.min(audioRef.current.currentTime + SKIP_TIME, audioRef.current.duration);
    audioRef.current.currentTime = newTime;
    setCurrentTime(newTime);
  }, []);
  
  // Skip backward
  const skipBackward = useCallback(() => {
    if (!audioRef.current) return;
    
    const newTime = Math.max(audioRef.current.currentTime - SKIP_TIME, 0);
    audioRef.current.currentTime = newTime;
    setCurrentTime(newTime);
  }, []);
  
  // Change volume
  const changeVolume = useCallback((newVolume: number) => {
    if (newVolume < 0 || newVolume > 1) return;
    
    setVolume(newVolume);
    if (audioRef.current) {
      audioRef.current.volume = newVolume;
    }
    
    setStoredData(LOCAL_STORAGE_KEYS.VOLUME, newVolume);
  }, []);
  
  // Mute/unmute
  const toggleMute = useCallback(() => {
    if (!audioRef.current) return;
    
    const newMuted = !audioRef.current.muted;
    audioRef.current.muted = newMuted;
  }, []);
  
  // Set up media session controls
  useEffect(() => {
    if ('mediaSession' in navigator) {
      navigator.mediaSession.setActionHandler('play', () => resumeSong());
      navigator.mediaSession.setActionHandler('pause', () => pauseSong());
      navigator.mediaSession.setActionHandler('seekbackward', () => skipBackward());
      navigator.mediaSession.setActionHandler('seekforward', () => skipForward());
      navigator.mediaSession.setActionHandler('seekto', (details) => {
        if (details.seekTime) {
          seekTo(details.seekTime);
        }
      });
    }
  }, [resumeSong, pauseSong, skipBackward, skipForward, seekTo]);
  
  return {
    currentSong,
    playerState,
    duration,
    currentTime,
    volume,
    playSong,
    pauseSong,
    resumeSong,
    togglePlayPause,
    seekTo,
    skipForward,
    skipBackward,
    changeVolume,
    toggleMute
  };
}
