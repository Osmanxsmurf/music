// Service Worker for MüzikAI
const CACHE_NAME = 'muzikai-cache-v1';

// Resources to cache immediately on install
const PRECACHE_RESOURCES = [
  '/',
  '/index.html',
  '/offline.html',
  '/manifest.json',
  '/icon-192x192.png',
  '/icon-512x512.png'
];

// Install event - pre-cache critical resources
self.addEventListener('install', event => {
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then(cache => {
        console.log('Pre-caching resources');
        return cache.addAll(PRECACHE_RESOURCES);
      })
      .then(() => self.skipWaiting()) // Force the service worker to become active
  );
});

// Activate event - clean up old caches
self.addEventListener('activate', event => {
  event.waitUntil(
    caches.keys().then(cacheNames => {
      return Promise.all(
        cacheNames
          .filter(cacheName => cacheName !== CACHE_NAME)
          .map(cacheName => caches.delete(cacheName))
      );
    }).then(() => self.clients.claim()) // Take control of all clients
  );
});

// Helper function to determine if a request is for an API
const isApiRequest = request => {
  const url = new URL(request.url);
  return url.pathname.startsWith('/api/');
};

// Helper function to check if a request is for an HTML page
const isHTMLRequest = request => {
  const url = new URL(request.url);
  const path = url.pathname;
  return request.mode === 'navigate' || 
         (request.headers.get('accept')?.includes('text/html') && 
         (!path.includes('.') || path.endsWith('.html')));
};

// Helper function to check if browser is online
const isOnline = () => {
  return self.navigator.onLine;
};

// Fetch event - network first, fallback to cache, then offline page
self.addEventListener('fetch', event => {
  const request = event.request;
  
  // Skip cross-origin requests
  if (!request.url.startsWith(self.location.origin)) {
    return;
  }
  
  // API requests - network only when online, fallback to cached API responses if offline
  if (isApiRequest(request)) {
    if (isOnline()) {
      // Online - Try network first, cache successful responses
      event.respondWith(
        fetch(request)
          .then(response => {
            // Cache a copy of the response
            const clonedResponse = response.clone();
            caches.open(CACHE_NAME).then(cache => {
              cache.put(request, clonedResponse);
            });
            return response;
          })
          .catch(() => {
            // If network fails, try the cache
            return caches.match(request);
          })
      );
    } else {
      // Offline - Try cache, if no cached API response, return JSON error
      event.respondWith(
        caches.match(request)
          .then(cachedResponse => {
            if (cachedResponse) {
              return cachedResponse;
            }
            // Return a JSON error for API requests when offline and not cached
            return new Response(
              JSON.stringify({ 
                error: true, 
                message: 'You are offline and this data is not cached' 
              }),
              { 
                status: 503,
                headers: { 'Content-Type': 'application/json' }
              }
            );
          })
      );
    }
    return;
  }
  
  // HTML requests - network first, fallback to offline page
  if (isHTMLRequest(request)) {
    event.respondWith(
      fetch(request)
        .then(response => {
          // Cache the latest version
          const clonedResponse = response.clone();
          caches.open(CACHE_NAME).then(cache => {
            cache.put(request, clonedResponse);
          });
          return response;
        })
        .catch(() => {
          // Try cached version
          return caches.match(request)
            .then(cachedResponse => {
              if (cachedResponse) {
                return cachedResponse;
              }
              // If not in cache, show offline page
              return caches.match('/offline.html');
            });
        })
    );
    return;
  }
  
  // For other assets (JS, CSS, images) - cache first, network as fallback
  event.respondWith(
    caches.match(request)
      .then(cachedResponse => {
        // Return cached response if available
        if (cachedResponse) {
          // Also update the cache in the background (for non-API requests)
          if (isOnline() && request.method === 'GET') {
            fetch(request).then(freshResponse => {
              caches.open(CACHE_NAME).then(cache => {
                cache.put(request, freshResponse.clone());
              });
            }).catch(() => {});
          }
          return cachedResponse;
        }
        
        // If not in cache, get from network
        return fetch(request)
          .then(response => {
            // Cache the new response for future
            const clonedResponse = response.clone();
            caches.open(CACHE_NAME).then(cache => {
              cache.put(request, clonedResponse);
            });
            return response;
          })
          .catch(error => {
            // Special handling for image requests
            if (request.url.match(/\.(jpg|jpeg|png|gif|svg|webp)$/)) {
              return new Response(
                '<svg xmlns="http://www.w3.org/2000/svg" width="200" height="200" viewBox="0 0 200 200">' +
                '<rect width="100%" height="100%" fill="#f0f0f0"/>' +
                '<text x="50%" y="50%" dominant-baseline="middle" text-anchor="middle" font-family="sans-serif" font-size="14" fill="#888">Image Unavailable</text>' +
                '</svg>',
                { headers: { 'Content-Type': 'image/svg+xml' } }
              );
            }
            throw error;
          });
      })
  );
});

// Listen for messages from the client
self.addEventListener('message', event => {
  if (event.data && event.data.type === 'CLEAR_CACHE') {
    event.waitUntil(
      caches.keys().then(cacheNames => {
        return Promise.all(
          cacheNames.map(cacheName => caches.delete(cacheName))
        ).then(() => {
          // Notify client that cache is cleared
          if (event.source) {
            event.source.postMessage({
              type: 'CACHE_CLEARED',
              success: true
            });
          }
          
          // Re-cache critical resources
          return caches.open(CACHE_NAME).then(cache => {
            return cache.addAll(PRECACHE_RESOURCES);
          });
        });
      })
    );
  }
});

// Background sync for offline actions
self.addEventListener('sync', event => {
  if (event.tag === 'sync-liked-songs') {
    event.waitUntil(syncLikedSongs());
  } else if (event.tag === 'sync-recently-played') {
    event.waitUntil(syncRecentlyPlayed());
  }
});

// Function to sync liked songs when back online
async function syncLikedSongs() {
  try {
    // Get pending likes from IndexedDB
    const pendingLikes = await getPendingData('pendingLikes');
    
    if (!pendingLikes || pendingLikes.length === 0) {
      return;
    }
    
    // Process each pending like
    const syncPromises = pendingLikes.map(async item => {
      try {
        const response = await fetch(`/api/users/1/liked-songs`, {
          method: item.action === 'like' ? 'POST' : 'DELETE',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ songId: item.songId })
        });
        
        if (response.ok) {
          // Remove from pending queue
          return removePendingItem('pendingLikes', item.id);
        }
      } catch (error) {
        console.error('Error syncing like:', error);
      }
    });
    
    await Promise.all(syncPromises);
  } catch (error) {
    console.error('Error in syncLikedSongs:', error);
  }
}

// Function to sync recently played when back online
async function syncRecentlyPlayed() {
  try {
    // Implementation would be similar to syncLikedSongs
    // but for recently played songs
  } catch (error) {
    console.error('Error in syncRecentlyPlayed:', error);
  }
}

// These functions would interact with IndexedDB
// Simplified placeholders for now
async function getPendingData(storeName) {
  return [];
}

async function removePendingItem(storeName, id) {
  return true;
}
